    const String hexDigits = "0123456789abcdef";
    uint8_t hex[2] = "";

    hex[0] = hexDigits[ (int)line.charAt(i) / 16 ];
    hex[1] = hexDigits[ (int)line.charAt(i) % 16 ];
