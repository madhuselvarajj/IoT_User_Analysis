    # pragma mark - JailbrokenSerialDelegate
    - (void) JailbrokenSerialReceived:(char)ch {
        
        //NSLog(@"Received %c", ch);
        [text appendFormat:@"%c", ch];
        //[text stringByAppendingFormat:@"%c",ch];
        NSLog(@"Received %@",text);
        
        if ([text isEqual: @"{valve_open}"]) {
            _lblValveState.text = @"Valve Opened.";
            [text setString:@""];
        }
        
        if ([text isEqual: @"{valve_close}"]) {
            _lblValveState.text =@"Valve Closed.";
            [text setString:@""];
        }
        
    }
