    void loop()
    {
        int chars = mySerial.available();
     int i;
     char *myString;
       if (chars>0)
        {
            myString = malloc(chars+1);
            for(i=0;i<chars;i++)
      {
       myString[i] = mySerial.read();
       //test for EOF
       if((myString[i] == '\n') ||(myString[i] == '\r'))
       {
        myString[i]=0;//strip carriage - return line feed(or skip)
        break;
       }
      }
      if(strstr(myString, "GPGGA") == NULL)
      {
       Serial.println("Not a GPGGA string"); 
      }
      else
      {
       //else, you have your string
      }
        }
     //free(myString) //somewhere when you are done with it
    }
