    bool checkForCorrectCommand(String cmd) {  

      if(inputString == cmd) { 
        // for match case, the string is consumed from the buffer
        inputString = "";
        stringComplete = false;
        return true;
      } 
      else {
        // for the non-match case, leave the buffer for further Rx or further tests
        return false;
      }
