    #define PLACES 3

    void extract(double x, int *a, int *b, int *n)
    {
     char buf[PLACES+10];
    
     sprintf(buf, "%.*f", PLACES, x);
     sscanf(buf, "%d.%d", a, b);
    
     *n = (int) pow(10, PLACES);
    
        // integer part is a, fractional part b / n
    }
