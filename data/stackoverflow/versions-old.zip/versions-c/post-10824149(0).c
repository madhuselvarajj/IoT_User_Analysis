    //Define a structure to store multistep sequences.
    template<int n>
    struct Command 
    {
        // n = Number of steps in the seq
        int StepCount; //must be set to -1
        int Seq[n][NUMSERVOS + 1];
    };
