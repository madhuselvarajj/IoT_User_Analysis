    typedef struct serial_port_s serial_port;
    typedef void (*serial_on_recived_proc)(serial_port* p);
    typedef struct serial_port_s{
     bool timeoutFlag;
     bool receiveFlag;
     void* context;
     serial_on_recived_proc response_handler;
    };
    
    void send_serial(serial_port* p, char* message)
    {
     //SendMsg?
    }
    void receive_serial(serial_port* p, char* response)
    {
     //receiveMsg?
    }
    
    bool has_data(serial_port* p)
    {
     return p->receiveFlag;
    }
    
    bool has_timed_out(serial_port* p)
    {
     return p->timeoutFlag;
    }
    bool is_serial_finished(serial_port* p)
    {
     return has_data(p) || has_timed_out(p); 
    }
    
    bool serial_check(serial_port* p)
    {
     if(is_serial_finished(p) && p->response_handler != NULL)
     {
      p->response_handler(p)
     }
    }
    
    void send(serial_port* p, char* message, char* response)
    {
     p->response_handler=NULL;
     send_serial(p, message);
     while(!is_serial_finished(p));
     receive_serial(p, response);
    }
    
    void sendAsync(serial_port* p, char* message, serial_on_recived_proc handler, void* context)
    {
     p->response_handler = handler;
     p->context = context;
     send_serial(p, message);
    }
    
    void pow_response(serial_port* p)
    {
     // could pass a pointer to a struct, or anything depending on what you want to do
     char* r = (char*)p->context;  
     receive_serial(p, r);
     // do stuff with the pow response
    }
    
    void myFunc();
    {
     char response[100];
     char pow[100];
     serial_port p; //
     // whatever you need to do to set the serial port

        // sends and blocks till a response/timeout
     send(&p, "Hello", response);
        // do what you like with the response

        // alternately, lets do an async send...
     sendAsync(&p, "Pow", pow_response, pow);
    
     while(true)
     {
      // non block check, will process the response when it arrives
      serial_check(p);
      // do other stuff you want to do in parallel
     }
    };
