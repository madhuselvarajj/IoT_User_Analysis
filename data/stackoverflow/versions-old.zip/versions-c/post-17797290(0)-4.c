    /* filename: .\Arduino\beacon\beacon2.ino */
    
    typedef enum State{ // <-- the us of typedef is optional.
      menu,
      output_on,
      val_edit
    };
    
    State state; // <-- the actual instance
    
    void setup()
    {
      // put your setup code here, to run once:
      state = menu;
    }
    
    void loop()
    {
      // put your main code here, to run repeatedly:
      state = val_edit;
    }
