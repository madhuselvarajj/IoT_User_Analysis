    int length = 8;
    char * buf = malloc(length);
    int total_read = 0;
    
    total_read = Serial.readBytesUntil(character, buf, length);
    while(length == total_read) {
        length *= 2;
        buf = realloc(buf, length);
        // Bug in this line:
        // total_read += Serial.readBytesUntil(character, buf+total_read, length);
        // Should be
        total_read += Serial.readBytesUntil(character, buf+total_read, length-total_read);
    }
