    typedef struct s_PWM {
      uint8_t muxmode;
      char *name;
      char *path;
    } PWM;
    
    typedef struct s_PIN {
      char *name;
      uint8_t gpio;
      char *mux;
      uint8_t eeprom;
      PWM *pwm;
    } PIN;

    ...
    extern PIN * P8_19;
