    /*** Cord Slatton
     * date 12-28-2012 **/
    
    //IR includes
    //info: http://www.zbotic.com/index.php/download/
    //download: http://www.zbotic.com/index.php/download_file/view/12/118/
    #include "PCInterrupt.h"
    #include "Device.h"
    #include "irController.h"
    
    #define RFID_ENABLE 8 //to RFID ENABLE
    #define CODE_LEN 10 //Max length of RFID tag
    #define START_BYTE 0x0A
    #define STOP_BYTE 0x0D
    #define MOTOR_RUN_LENGTH 1000 //time, in ms, to run door motor
     
    char tag[CODE_LEN];
    int pwm_b = 11; //PWM control for motor outputs 3 and 4 is on digital pin 11
    int dir_b = 13; //direction control for motor outputs 3 and 4 is on digital pin 13
    int door_status = 1; // 1 == closed, 0 == open
    int manual_mode = 1; // 1 == auto, 0 == manual
    //PIR sensor
    const int sensorPIR = A0;
    //IR init
    int manualModePin = 10; //led pin for indication of manual mode
    IRController irController;
    
    unsigned long rfidHitTime = 0; //when did we get last rfid hit?
    unsigned long pirHitTime = 0; //when did we get last PIR hit?
    unsigned long pirClose = 0;
    unsigned long rfidClose = 0;
     
    void setup() {
      Serial.begin(2400); //parallax rfid reader seems to only like serial 2400  
      Serial.println("RoboFeeder Online");
      //rfid
      pinMode(RFID_ENABLE,OUTPUT);
      //motor
      pinMode(pwm_b, OUTPUT);
      pinMode(dir_b, OUTPUT);
      //PIR
      pinMode(sensorPIR, INPUT);
      digitalWrite(sensorPIR, LOW);
      Serial.println("Warming up PIR...");
      delay(10000);
      Serial.println("PIR ready");
      //IR remote
      pinMode(manualModePin, OUTPUT);
      digitalWrite(manualModePin, LOW);
      int res = irController.begin(IR_PIN, OTHER_DEVICE);
      if (res != SUCCESS) {
        Serial.println("error=");
        Serial.println(res);
      }
      Serial.println("IR Remote enabled");
      
      Serial.println("RoboFeeder startup test: Door");
      openDoor();
      delay(2500);
      closeDoor();
      Serial.println("RoboFeeder door test complete");
    }
     
    void loop() {
      delay(1500);
      enableRFID(); 
      getRFIDTag(); //waiting function, till gets any tag
      
      disableRFID();
      openDoor();
      sendCode();
        
      Serial.flush();
      clearCode();
    }
     
    /*** Clears out the memory space for the tag to 0s. */
    void clearCode() {
      for(int i=0; i<CODE_LEN; i++) {
        tag[i] = 0; 
      }
    }
     
    /*** Sends the tag to the computer. */
    void sendCode() {
        Serial.print("TAG:");
        for(int i=0; i<CODE_LEN; i++) {
          Serial.print(tag[i]); 
        }
        Serial.println("\r"); 
    }
    
    /**************************************************************/
    /********************   RFID Functions  ***********************/
    /**************************************************************/
     
    void enableRFID() {
       digitalWrite(RFID_ENABLE, LOW);    
    }
     
    void disableRFID() {
       digitalWrite(RFID_ENABLE, HIGH);  
    }
    
    /*** Blocking function, waits for and gets the RFID tag. */
    void getRFIDTag() {
      byte next_byte; 
      while(Serial.available() <= 0) {
        if(door_status == 0){ //open
          pirDetection(); 
          rfidClose = millis() - rfidHitTime;
          pirClose =  millis() - pirHitTime;
          Serial.print("RFID Close: ");
          Serial.print(rfidClose);
          Serial.print(" - PIR Close: ");
          Serial.println(pirClose);
          //if door has been open for more than a certain amount of time with no rfid hit and PIR no hit for certain time
          if( (rfidClose > 40000) && (pirClose > 15000) ){
            closeDoor();     
          }
        }    
        IRRemote(); 
        if(manual_mode == 0)
          manualMode();   
      }
      //PIR set to current loop time to keep it from freaking out
      pirHitTime = millis();
      
      if((next_byte = Serial.read()) == START_BYTE) {      
        byte bytesread = 0; 
        while(bytesread < CODE_LEN) {
          if(Serial.available() > 0) { //wait for the next byte
              if((next_byte = Serial.read()) == STOP_BYTE) break;       
              tag[bytesread++] = next_byte;         
          }
        }
        rfidHitTime = millis(); //keep track of when last rfid hit was    
      }
    }
    
    /**************************************************************/
    /********************   Motor Functions  ***********************/
    /**************************************************************/
    
    void openDoor() {
      if(door_status == 1){      
        motorRun(150);
        digitalWrite(dir_b, HIGH);  //Set motor direction, 1 low, 2 high
        Serial.println("Door opening");
        delay(MOTOR_RUN_LENGTH);
        motorStop();
        door_status = 1 - door_status;
      }
    }
    
    void closeDoor() {
      if(door_status == 0){    
        motorRun(150);
        digitalWrite(dir_b, LOW);  //Reverse motor direction, 1 high, 2 low
        Serial.println("Door closing");
        delay(MOTOR_RUN_LENGTH);
        motorStop();
        door_status = 1 - door_status; 
      }     
    }
    
    void motorRun(int speed) {
      analogWrite(pwm_b, speed);  //set motor to run at speed variable value
    }
    void motorStop() {
      analogWrite(pwm_b, 0);  //set motor to run at 0
    }
    
    /**************************************************************/
    /********************   PIR Functions  ***********************/
    /**************************************************************/
    
    boolean pirDetection() {
      //returns true if PIR analog reading has been rising for more than 10 cycles, 
      //false if has been falling
      int counter = 0;
      int pirSensorReading[10];
      int avgReading = 0;
      while(counter < 10){
        pirSensorReading[counter] = analogRead(sensorPIR);
        avgReading += pirSensorReading[counter];  
        counter++;
        delay(300);
      }
      avgReading = avgReading/10;
      Serial.print("Avg. PIR: ");
      Serial.print(avgReading);
      Serial.print(" - Last PIR: ");
      Serial.println( pirSensorReading[9] );
      
      if( (pirSensorReading[9] > avgReading+1) || (analogRead(sensorPIR) > 700) ){
        pirHitTime = millis(); //keep track of when last PIR hit was
        return true;
      }
      else if(pirSensorReading[9] <= avgReading){
        return false;
      }
    }
    
    /**************************************************************/
    /********************   IR Remote Functions  ***********************/
    /**************************************************************/
    
    void IRRemote(){ 
      int val = irController.read(); // Returns negative value if no new command rcvd  
      if (val >=0){
        Serial.print("Key: ");
        Serial.println(val);
        if(val == 100){
          manual_mode = 1 - manual_mode;
        }    
        else if( (val >= 0) && (manual_mode == 0) ){
          if(door_status == 1)
            openDoor();
          else
            closeDoor();
        }
      }
      delay(500); 
    }
    
    //blocking function that won't let you leave till you turn off manual mode
    void manualMode(){
      disableRFID();
      Serial.println("Manual Mode on");
      digitalWrite(manualModePin, HIGH);
      while(manual_mode == 0){
        IRRemote();
      }
      Serial.println("Manual Mode exiting");
      digitalWrite(manualModePin, LOW);
      //set sensors to count from now, esentially zero them out
      pirHitTime = millis();
      rfidHitTime = millis();
      enableRFID();
    }
