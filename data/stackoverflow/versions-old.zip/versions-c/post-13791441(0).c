    // put all your preconstructed items in some array.....
    // you'd make this a global typically

    boolean glyphs[2][6][5] = {
     {
      {0,0,1,0,0},
      {0,0,0,1,0},
      {0,0,1,0,0},
      {0,1,0,0,0},
      {1,0,0,0,0},
      {1,1,1,1,1}
     },
     {
      {1,1,1,1,1},
      {1,0,0,1,1},
      {1,0,1,0,1},
      {1,1,0,0,1},
      {1,0,0,0,1},
      {1,1,1,1,1}
     }
    };

    // then whereever you want to change the framebuffer in your code...
    // copy second into framebuffer..
    memcpy(framebuffer, glyphs[1], sizeof(boolean)*6*5);
