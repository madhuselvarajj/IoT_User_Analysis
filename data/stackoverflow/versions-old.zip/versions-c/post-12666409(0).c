    void loop() {
    char data[10];
    int i=0;
    float value;

        if(Serial.available() > 0) {
            while (i<10 & data[i-1]!=13) { 
                data[i] = Serial.read();
                i++;
            }
            strtof(data,value);           
        }
    }
