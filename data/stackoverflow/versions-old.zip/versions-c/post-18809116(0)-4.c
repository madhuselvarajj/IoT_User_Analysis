    LedControl lc; // not ready to use until attach pins
    
    void setup() {
      lc.attach(11, 13, 12);// data, clock, latch;
      ...
    }
