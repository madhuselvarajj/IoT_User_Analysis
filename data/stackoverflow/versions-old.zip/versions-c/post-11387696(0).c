    #import <IOKit/serial/ioss.h>
    #import <sys/ioctl.h>
    
    - (int)serialInit:(const char*)path baud:(int)baud;
    {
        struct termios options;
    
        // open the serial like POSIX C
        int serialFileDescriptor = open(path, O_RDWR | O_NOCTTY | O_NONBLOCK);
    
        // block non-root users from using this port
        ioctl(serialFileDescriptor, TIOCEXCL);
    
        // clear the O_NONBLOCK flag, so that read() will
        //   block and wait for data.
        fcntl(serialFileDescriptor, F_SETFL, 0);
    
        // grab the options for the serial port
        tcgetattr(serialFileDescriptor, &options);
    
        // setting raw-mode allows the use of tcsetattr() and ioctl()
        cfmakeraw(&options);
    
        // specify any arbitrary baud rate
        ioctl(serialFileDescriptor, IOSSIOSPEED, &baud);
    
        return serialFileDescriptor;
    }
