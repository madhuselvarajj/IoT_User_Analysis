    String txtMsg = "";  
    char s;
    
    void loop()
    {
      
     
      while (serial.available() > 0) {
    
           s=(char)serial.read();
          if (s == '\n') {
           if(txtMsg=="HIGH") {  digitalWrite(13, HIGH);  }
           if(txtMsg=="LOW")  {  digitalWrite(13, LOW);   }
          // Serial.println(txtMsg); 
           txtMsg = "";  
           
          } else {  txtMsg +=s; }
          
      
      }
    }
