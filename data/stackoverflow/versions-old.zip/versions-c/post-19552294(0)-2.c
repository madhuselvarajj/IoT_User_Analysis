    #define NO_PROBLEM
    #ifdef NO_PROBLEM
      #include "Arduino.h"
    void setup();
    void loop();
    char charBuf[16];
      unsigned int numBuf;
    #endif

    void setup() {
    }
    void loop() {
    }
