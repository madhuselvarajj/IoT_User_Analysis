    #include <stdio.h>

    float input[3];

    int main(int argc, const char* argv[]) {
        FILE *port;
        port=fopen("/dev/tty.usbmodem1411", "r"); //fopen instead, in order to use formatted I/O functions
        if (port==NULL) {
            printf("Unable to open serial port.");
            return 1; //MUST terminate execution here!
        }
        for (int i = 0; i < 10; i++) {
            fscanf(, "%f %f %f", &input[0], &input[1], &input[2]);
            printf("%.2f %.2f %.2f\n", input[0], input[1], input[2]);
        }
        fclose(port);
        return 0;
    
    }
