    for(x=0; x<sizeof(colom)/sizeof(int); x++) {
      if (colom[x]>2) {
        colom[x] = 0;
      }
    }
