void waitButton( bool state )
    {
        int debounce = 0 ;

        usleep(1000) ;

        while( debounce < 10 )
        {
            if( bcm2835_gpio_lev(PIN) == state )
            {
                debounce++ ;
            }
            else
            {
                debounce = 0 ; 
            }
        }
    }
