        int i;
        for(i = 0; i < sizeof(receive_buffer); i++) {
             i = 
             printf("%i", (int)receive_buffer[i]);
        }
