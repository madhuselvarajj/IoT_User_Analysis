    boolean MAX3421E::reset()
    {
      byte tmp = 0;
        regWr( rUSBCTL, bmCHIPRES );                        //Chip reset. This stops the oscillator
        regWr( rUSBCTL, 0x00 );                             //Remove the reset
        while(!(regRd( rUSBIRQ ) & bmOSCOKIRQ )) {          //wait until the PLL is stable
            tmp++;                                          //timeout after 256 attempts
            if( tmp == 0 ) {
                return( false );
            }
        }
        return( true );
    }
