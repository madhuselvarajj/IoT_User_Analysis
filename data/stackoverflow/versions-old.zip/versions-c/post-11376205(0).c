    char buffer[1024];
    while(fgets(buffer, sizeof(buffer), theFile))
    {
        printf("Buffer: %s", buffer);
    }
