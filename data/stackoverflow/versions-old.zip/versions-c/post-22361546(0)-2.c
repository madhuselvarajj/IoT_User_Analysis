    #include <stdlib.h>
    #include <stdio.h>

    typedef signed char byte;

    struct something {
        byte (*getPatternType)();
        byte (*update)(int i);
    };

    int main(void) {
        struct something mCols[20];
        int i;
        int m=3;

        for (i=0; i<20; i++) {
                byte patternValue=getPatternValue(mCols[i].getPatternType(), mCols[i].update(m));
                printf("%d\n", patternValue);
        }
        exit(0);
    }
