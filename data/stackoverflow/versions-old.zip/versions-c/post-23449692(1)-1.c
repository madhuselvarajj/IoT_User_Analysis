    for (i=0; i<50; i++) {

       fcntl(open_port(), F_SETFL, FNDELAY);

       bytes_read = read(open_port(), buf, nbytes);

    }
