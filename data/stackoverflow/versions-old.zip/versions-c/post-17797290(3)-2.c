    /* filename: .\Arduino\beacon\beacon.ino */
    #include <beacon.h>
    State state; // <-- the actual instance
    void setup()
    {
      state = menu; 
    }
    
    void loop()
    {
      state = val_edit;
    }
