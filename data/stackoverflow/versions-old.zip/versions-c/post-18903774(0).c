    boolean check(int key, boolean* prev_key_high, char c){
      if (key == LOW) {
        if ( *prev_key_high){
          *prev_key_high = false;
          Serial.println(c);
        return true;
        }
       }

        else {
          *prev_key_high = true;
          return false;
        }
      }
