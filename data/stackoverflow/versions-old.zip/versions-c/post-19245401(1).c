    if ( !strcmp(packetBuffer, "command1") ) {
    
    else if ( !strcmp(packetBuffer, "command2") ) { 

    } else {

    }
