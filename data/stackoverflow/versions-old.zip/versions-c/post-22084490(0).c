    gpsfile="gps.log"
    l=0
    
    def scan1():
        global l
        gps=open(gpsfile,"r")
        for l in gps.readlines():
            lsplit=l.split(",")
            if "$GPGGA" not in lsplit:
                pass
            else:
                print l.rstrip()
    print""
    scan1()
