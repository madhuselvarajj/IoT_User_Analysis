    #ifdef __cplusplus
    extern "C" {
    #endif

    void readArms(void);

    #ifdef __cplusplus
    }
    #endif
