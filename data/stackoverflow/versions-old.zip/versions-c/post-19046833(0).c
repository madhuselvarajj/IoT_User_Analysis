    char n[20];
    char *adminName[] = {"Jane", "Joe", "James"};
    int  i;
    
    i = 0;
    while (admminName[i] != NULL)
     {
        if ((strcmp(n, adminName[i])) == 0)
          return (true); 
        i++;
     }
    return (false);
