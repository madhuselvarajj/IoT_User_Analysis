    #include <bcm2835.h>
    // Blinks on RPi Plug P1 pin 11 (which is GPIO pin 17)
    #define PIN RPI_GPIO_P1_11
    uint8_t status = LOW;
    int SetLed()
    {
        // Inizialize the library
        if (!bcm2835_init())
            return 1;
        // Set the pin to be an output
        bcm2835_gpio_fsel(PIN, BCM2835_GPIO_FSEL_OUTP);
        // Set the Led:
        bcm2835_gpio_write(PIN, status);
        status=!status;
        /*
        I fetched a flip-flop variable, problably does not work without integer variable, so replace the up line with
        if (status == HIGH)
           status = LOW;
        else
           status = HIGH;
        */
        //Clean-up and return success.
        bcm2835_close();
        return 0;
    }
