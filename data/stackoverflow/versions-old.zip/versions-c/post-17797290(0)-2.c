    /* filename: .\Arduino\beacon\beacon.ino */
    #include <beacon.h>
    State state;
    void setup()
    {
      // put your setup code here, to run once:
      state = menu;
    }
    
    void loop()
    {
      // put your main code here, to run repeatedly:
      state = val_edit;
    }
