    int r;
    char c;
    r = Wire.read();
    if (r != -1) {
        c = char(r);
    }
