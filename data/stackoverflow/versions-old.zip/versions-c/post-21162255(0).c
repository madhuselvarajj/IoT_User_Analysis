    #include <unistd.h>
    
    // first open the new output path
    int new_out = open("/path/to/output", flags_as_needed);
    
    // next, move the standard output path
    int save_out = dup(STDOUT_FILENO);
    close(STDOUT_FILENO);
    
    // now copy the new output path to the standard output position
    dup2(STDOUT_FILENO, new_out);
