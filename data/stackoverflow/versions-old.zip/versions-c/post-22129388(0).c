    byte dog[8] = {0,0,1,1,1,1,1,0};
    byte cat;
    int i = 0;
    
    BitWriteBeginning:    
    bitWrite(cat, i, dog[7-i]);
    i++
    if (i < 8)
       goto BitWriteBeginning;
