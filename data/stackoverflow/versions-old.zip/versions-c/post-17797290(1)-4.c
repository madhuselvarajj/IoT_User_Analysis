    /* filename: .\Arduino\beacon\beacon2.ino */
    
    typedef enum State{ // <-- the use of typedef is optional.
      menu,
      output_on,
      val_edit
    };
    
    State state; // <-- the actual instance
    
    void setup()
    {
      state = menu;
    }
    
    void loop()
    {
      state = val_edit;
    }
