            uint8_t response[64];
            
            uint8_t responseLength = sizeof(response);
            
            if (nfc.inDataExchange(message, sizeof(message), response, &responseLength)) {

                String respBuffer;

                for (int i = 0; i < 16; i++) {
                    if (response[i] < 0x10) respBuffer = respBuffer + "0";
                    respBuffer = respBuffer + String(response[i], HEX);                        
                }
                
                Serial.println(respBuffer);
                
            }
