    void getGyroValues () {
      int MSB, LSB;
    
      MSB = readI2C(0x29);
      LSB = readI2C(0x28);
      x = ((MSB << 8) | LSB);
    
      MSB = readI2C(0x2B);
      LSB = readI2C(0x2A);
      y = ((MSB << 8) | LSB);
    
      MSB = readI2C(0x2D);
      LSB = readI2C(0x2C);
      z = ((MSB << 8) | LSB);
    }
