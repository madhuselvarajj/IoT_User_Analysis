    int CCONV TagHandler(CPhidgetRFIDHandle RFID, void *usrptr, char *TagVal, CPhidgetRFID_Protocol proto)
    {
        return add_event(RFID, proto, RFID_TAG_READ, TagVal, usrptr);
    }

    int CCONV TagLostHandler(CPhidgetRFIDHandle RFID, void *usrptr, char *TagVal, CPhidgetRFID_Protocol proto)
    {
        return add_event(RFID, proto, RFID_TAG_LOST, TagVal, usrptr);
    }
