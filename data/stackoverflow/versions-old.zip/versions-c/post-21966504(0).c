    #include<string.h>
    #include<stdlib.h>
    #include<stdio.h>
    #include<errno.h>
    #include<unistd.h>
    #include<fcntl.h>
    #include<termios.h>
    
    #define bufLen 81
    
    int main() {    
    
        char buf[bufLen];
        struct termios tty;
        FILE * f;
        int fd=open("/dev/ttyACM0",O_RDWR | O_NOCTTY);
        if(fd == -1) {
                perror("Unable to open /dev/ttyACM1\n");
                return -1;
        } else {
            if(tcgetattr(fd, &tty)!=0) {perror("tcgetatt() error"); return -1;}
            else {
                cfsetospeed(&tty, B9600);
                cfsetispeed(&tty, B9600);
    
                tty.c_cflag &= ~PARENB;
                tty.c_cflag &= ~CSTOPB;
                tty.c_cflag &= ~CSIZE;
                tty.c_cflag |= CS8;
                tty.c_cflag &= ~CRTSCTS; 
                tty.c_cflag |= CLOCAL | CREAD;
    
                tty.c_iflag |= IGNPAR | IGNCR;
                tty.c_iflag &= ~(IXON | IXOFF | IXANY);
                tty.c_lflag |= ICANON;
                tty.c_oflag &= ~OPOST;
                tcsetattr(fd, TCSANOW, &tty);
    
                if (!(f = fdopen(fd, "r+t"))) {perror("fdopen() error"); return -1;}
    
                while (1) {
                    fgets(buf,bufLen,f);
                    printf("%s--\n",buf);
                }   
            }
        }
        close(fd);
        return 0;
    }
