    union Data
    {
       char  data[36];
       float f[9];
    };


    union Data data;
    data.data[0] = 0;
    data.data[1] = 0;
    data.data[2] = 0;
    data.data[3] = 0;

    fprintf(stdout,"float is %f\n",data.float[0]);
