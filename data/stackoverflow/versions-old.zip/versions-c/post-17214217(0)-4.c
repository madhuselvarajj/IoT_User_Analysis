    void handle_steering(int steering) {
        if (steering > NN)
            turn_left(steering);
        elif (steering < NN)
            turn_right(steering);
        else
            keep_straight();
    }

and change the loop() to :

    void loop() {
        int throttle = read_throttle();
        int steering = read_steering();
        delay(5);
        handle_throttle(throttle);
        handle_steering(steering);
    }
