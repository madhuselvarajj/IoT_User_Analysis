    const int buttonA = 2;
    boolean wasAPressed = false;
    boolean isAPressed  = false;

    // ...
    
    loop() {
    
        isAPressed = (digitalRead(buttonA) == LOW);
        if(!wasAPressed && isAPressed) {
            wasAPressed = true;
            Serial.write('A');
        } else if(wasPressed && !isAPressed){
            wasAPressed = false;
        }
        
        // ...
    }
