    void loop(){
    
      rotateDeg(360, 1); 
      ....
      ....
      rotate(1600, .5); 
      ... 
      rotate(-1600, .25); //reverse
      delay(1000); 
    }
