    #define __STDC_LIMIT_MACROS 1
    #include <inttypes.h>

    // ...

    char ifStatement[13];
    sprintf(ifStatement, "if (%" PRIu8 " == 1) {", stat[0]);
    client.println(ifStatement);

    client.println("// JavaScript code to execute if stat[0] == 1");

    client.println("}");
