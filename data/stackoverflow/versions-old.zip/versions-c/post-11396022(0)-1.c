    import serial, time

    #open the serial port
    s = serial.Serial(port='/dev/tty.usbserial-A5006HGR', baudrate=9600)

    #disable DTR
    s.setDTR(level=False)

    #wait for 2 seconds
    time.sleep(2)

    #send the data
    s.write("7")
