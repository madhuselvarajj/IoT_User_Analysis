    yourfunction( long a , long* b )
    {    
        *b = a + 10;
        //more code

    return a;
    }

    a = yourfunction(a , &b );
