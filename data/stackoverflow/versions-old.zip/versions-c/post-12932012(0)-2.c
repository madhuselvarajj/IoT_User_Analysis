    for (size_t i = 0; i < sizeof(data_sets) / sizeof(data_sets[0]); i++)
    {
        const char** data_set = data_sets[i];
        printf("data_set[%u]\n", i);
        for (size_t j = 0; data_set[j]; j++)
        {
            printf("  [%s]\n", data_set[j]);
        }
    }
