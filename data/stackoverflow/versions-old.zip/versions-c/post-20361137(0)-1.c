    for (;;) {
        consocket = accept(mysocket, (struct sockaddr *)&dest, &socksize);
        if(consocket < 0) // might return if the connection has already gone away.
            continue;
        if (!sendGreeting(consocket)) {
            // sendGreeting should return -1 if it was unable to send, 0 if successful
            while (!readLoop(consocket, recvBuf, MAXRCVLEN))
                ;
        }
        close(consocket);
    }
