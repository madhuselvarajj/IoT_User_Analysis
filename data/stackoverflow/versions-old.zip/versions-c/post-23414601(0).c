    bool tripped = false;
    
    void setup(){
        //setup stuff here
    }
    
    void loop() {
        if ( analogRead(sensor1) == 0 ) 
        {     
            timer.start ();
            tStop = false;
    
            if ( tripped == false ) 
            {
                Serial.println ("Start Time = 0");
                tripped = true;
            }
        }
    }
