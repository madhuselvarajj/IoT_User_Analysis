    void loop()
    {
        int chars = mySerial.available();
     int i;
     char *myString;
       if (chars>0)
        {
            myString = malloc(chars+1);
            for(i=0;i<chars;i++)
      {
       myString[i] = mySerial.read();
      }
      if(strstr(myString, "GPGGA") == NULL)
      {
       Serial.println("Not a GPGGA string"); 
      }
        }
     //free(myString) //somewhere when you are done with it
    }
