    String read() {
     while (!Serial.available()); //wait for user input
     //there is something in the buffer now
     String str = "";
     while (Serial.available()) {
      str += (char) Serial.read();
      delay(1); //wait for the next byte, if after this nothing has arrived it means the text was not part of the same stream entered by the user
     }
     return str;
    }
