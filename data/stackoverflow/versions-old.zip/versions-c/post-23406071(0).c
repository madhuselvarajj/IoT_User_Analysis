    if (analogRead(sensor1) == 0) {
      timer.start ();
      tStop = false;
    
    while (i == 1) {
      Serial.println ("Start Time = 0");
      i++;
     }    
    }
