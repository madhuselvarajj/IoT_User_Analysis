    /* filename: .\Arduino\libraries\beacon\beacon.h */
    enum State{
      menu,
      output_on,
      val_edit
    };
