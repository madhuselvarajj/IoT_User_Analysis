    #include <bcm2835.h>
    #include <stdio.h>
    #define PIN RPI_GPIO_P1_11

    // A decent value for the number of checks varies with how "clean" your button is, how 
    // responsive you need the system to be, and how often you call the helper function. That
    // last one depends on how fast your CPU is and how much other stuff is going on in your
    // loop. Don't pick a value above UINT_MAX (in limits.h)
    #define BUTTON_DEBOUNCE_CHECKS 100

    int ButtonPress()
    {
        static unsigned int buttonState = 0;
        static char buttonPressEnabled = 1;

        if(bcm2835_gpio_lev(PIN))
        {
            if(buttonState < BUTTON_DEBOUNCE_CHECKS)
            {
                buttonState++;
            }
            else if(buttonPressEnabled)
            {
                buttonPressEnabled = 0;
                return 1;
            }
        }
        else if(buttonState > 0 )
        {
            buttonState--;
            // alternatively you can set buttonState to 0 here, but I prefer this way
        }
        else
        {
            buttonPressEnabled = 1;
        }

        return 0;
    }
    
    int main()
    {
        if(!bcm2835_init())
            return 1;
    
        bcm2835_gpio_fsel(PIN, BCM2835_GPIO_FSEL_INPT);
    
        while(1)
        {
            if(ButtonPress())
            {
                printf("The button has been pressed\n");
            }

            // the rest of your main loop code
        }
    
        bcm2835_close();
        return 0;
    }
