    // given: String command
    int data[MAX_ARGS];
    int numArgs = 0;

    int beginIdx = 0;
    int idx = command.indexOf(",");

    while (idx != -1)
    {
        // add error handling for atoi:
        data[numArgs++] = atoi(command.substring(beginIdx, idx));
        beginIdx = idx + 1;
        idx = command.indexOf(",", beginIdx);
    }

    data[numArgs++] = command.substring(beginIdx);
