      while(Serial.available() > 0) //Don't read unless you know there is data
      {
        if(index < 19) //One less than the size of the array
        {
          inChar = Serial.read(); //Read a character
          ...
        }
      }
