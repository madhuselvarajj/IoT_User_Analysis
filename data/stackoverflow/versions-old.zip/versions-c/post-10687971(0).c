    void sortNumbers()
    {
      ...
      int check = 1;
      if( check != 0 )
      {
        ...
        sortNumbers();
      }
    }
