    std::ostringstream str;
    str < < "MyText: Hello SO!";
    cv::putText(image, cv::Point(20,20), str.str(), CV_FONT_HERSHEY_PLAIN, CV_RGB(0,0,250));
