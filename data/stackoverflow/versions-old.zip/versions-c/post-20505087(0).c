    int w = 12;

    Serial.Print ("my number is: ");

    Serial.Print (w);

    Serial.Println (" - which is to be used in calculation!"
