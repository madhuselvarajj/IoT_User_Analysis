int PWM;
int minute_ctr;

loop()
{
   if (minute_ctr > 1000)
   {
      minute_ctr = 0;
      check HTML page for 1/0
   }

   if (page == 1)
      PWM++;
      
      set PWM for LED (analogWrite) change direction when PWM = 0 or 255


   else 

      set LED off

   end if

   delay(10)  

   minute_ctr += 10;

}
