    void loop()
    {
        int chars = mySerial.available();
     int i;
     char *myString;
       if (chars>0)
        {
            myString = malloc(chars+1);
            for(i=0;i<chars;i++)
      {
       myString[i] = mySerial.read();
       //test for end of input
       if((myString[i] == '\n') ||(myString[i] == '\r'))
       {
        //leave loop 
       }
      }
      if(strstr(myString, "GPGGA") == NULL)
      {
       Serial.println("Not a GPGGA string"); 
      }
        }
     //free(myString) //somewhere when you are done with it
    }
