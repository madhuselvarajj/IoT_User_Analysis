import struct
    ...
    
    data = my_port.read(9)
    num, = struct.unpack('dx', data)
