#include <unistd.h>
    #define DEBOUNCE_MILLISEC 20
    
    void waitButtonRelease()
    {
        int debounce = 0 ;

        usleep(1000) ;

        while( debounce < 10 )
        {
            if( bcm2835_gpio_lev(PIN) )
            {
                debounce = 0 ;
            }
            else
            {
                debounce++ ; 
            }
        }
    }
