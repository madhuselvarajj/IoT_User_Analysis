    #include <stdio.h>
    
    int comb(unsigned char msb, unsigned char lsb) {
            long t = ((long)msb << 8) | lsb;
            if (t >= 32768)
                    t -= 65536;
            return t;
    }
    
    int comb2(unsigned char msb, unsigned char lsb) {
            unsigned long t = ((unsigned long)msb << 8) | lsb;
            t ^= 0x8000UL;
            return (int)((long)t - (long)0x8000);
    }
    
    int main(void) {
            printf("%6s %6s\n", "comb", "comb2");
            printf("%6d %6d\n", comb(0, 0), comb2(0, 0));
            printf("%6d %6d\n", comb(127, 255), comb2(127, 255));
            printf("%6d %6d\n", comb(128, 0), comb2(128, 0));
            printf("%6d %6d\n", comb(255, 255), comb2(255, 255));
            return 0;
    }
