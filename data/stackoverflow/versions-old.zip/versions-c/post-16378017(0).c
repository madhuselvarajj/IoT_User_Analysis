    void LedBar()
    {
        int potValue = analogRead(potPin) /4;
        if(on == 1)
            for (int i=0;i<=8;i++)
                if (potValue > M[i])
                   digitalWrite(i+2, HIGH);
        else
            for (int i=0;i<=8;i++)
                digitalWrite(M[i+2], LOW);
    }
