    // you will pass two arguments the pot you want to read and the servo you want to write to
    void moveServo( potPin, servo ) 
    {
        val = analogRead(potPin);
        val = map(val, 0, 1023, 0, 179);
        servo.write(val);
    } 
    
    // calling the function
    
    moveServo( potpin1, indexF );
