    namespace trick17 {};
    //#define NO_PROBLEM
    #ifdef NO_PROBLEM
      char charBuf[16];
      unsigned int numBuf;
    #endif

    void setup() {
    }
    void loop() {
    }
