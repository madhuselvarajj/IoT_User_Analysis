    while(inChar=client.read())
    {         
        currentLine[index++] = inChar; //read in all characters of count
    }
    currentLine[index] = '\0';
       
    if(strcmp(currentLine,lastCount)!=0) //no
