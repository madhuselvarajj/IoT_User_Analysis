    #define PLACES 3
    
    void extract(double x)
    {
            char buf[PLACES+10];
            int a, b;
    
            sprintf(buf, "%.*f", PLACES, x);
            sscanf(buf, "%d.%d", &a, &b);
    
            int n = (int) pow(10, PLACES);

            // Integer is a, fractional part is b / n
    }
