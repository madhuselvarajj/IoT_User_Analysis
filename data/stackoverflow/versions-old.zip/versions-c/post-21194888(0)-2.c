    unsigned long ulForceSensorResistance1;
    ...
    ulForceSensorConductance1 = conductanceFunction(ulForceSensorResistance1, iForceSensorVoltage1);
    ...
    int conductanceFunction(long x, long y)
    {long result;
     x = 5000 - y; // fsrVoltage is in millivolts so 5V = 5000mV
