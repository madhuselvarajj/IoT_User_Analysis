    for(i = 0; i <= 0xFF; i++)
 rgb = 0xFF0000 | i<<8;
 
    for(i = 0xFF; i >= 0; i--)
 rgb = 0x00FF00 | i<<16;
 
    for(i = 0; i <= 0xFF; i++)
 rgb = 0x00FF00 | i;
 
    for(i = 0xFF; i >= 0; i--)
 rgb = 0x0000FF | i<<8;
 
    for(i = 0; i <= 0xFF; i++)
 rgb = 0x0000FF | i<<16;
 
    for(i = 0xFF; i >= 0; i--)
 rgb = 0xFF0000 | i;
