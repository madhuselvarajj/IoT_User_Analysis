    char ctrld_pressed = 0;
    
    void ctrld(int sig)
    {
      ctrld_pressed = 1;
    }

    int main()
    {
        signal(SIGINT, ctrld);
        while (!ctrld_pressed)
        {

        }
    }
