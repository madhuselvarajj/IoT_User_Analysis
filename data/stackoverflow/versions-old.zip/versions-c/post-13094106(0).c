    /**
     * Alternative to PROGMEM storage class
     * 
     * Same effect as PROGMEM storage class, but avoiding erroneous warning by
     * GCC.
     * 
     * \see http://gcc.gnu.org/bugzilla/show_bug.cgi?id=34734
     */
    #define PROGMEM_ __attribute__((section(".progmem.data")))
