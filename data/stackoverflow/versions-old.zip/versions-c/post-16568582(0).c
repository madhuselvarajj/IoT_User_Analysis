    strncat(cc,o,20);  
    strncat(cc,"|",20);
    strncat(cc,m,20);  
    strncat(cc,"|",20);
    strncat(cc,n,20);
