                if(socket != null) {
                    socket.close();
                }
                if(dataOutputStream != null) {
                    dataOutputStream.close();
                }
