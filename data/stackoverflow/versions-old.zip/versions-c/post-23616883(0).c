      int n = 0;  // unsigned might be better here
      for (i = 0; i < 10; i++) {
        n = (n << 1) | (analogRead(A0) & 1);
        delay(50);
      }
