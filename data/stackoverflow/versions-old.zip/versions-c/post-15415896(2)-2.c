    long Conv(double num, long& b) {
      long a;
      a = floor(num);
      b = num * pow(10,6) - a * pow(10,6);

      return a;
    }
