    int value= ...;

    if (value>=0 && value<=250 {
        // some code 0..250
    }
    else 
    if (value>250 && value<=500) {
        // some code 251..500
    }
    else 
    if (value>500 && value<=1000) {
        // etc.
    }
    else {
        // all other values (less than zero or 1001...)
    }
