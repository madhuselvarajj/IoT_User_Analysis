    int length = 8;
    char * buf = malloc(length);
    int total_read = 0;
    
    total_read = Serial.readBytesUntil(character, buf, length);
    while(length == total_read) {
        length *= 2;
        buf = realloc(buf, length);
        total_read += Serial.readBytesUntil(character, buf+total_read, length);
    }
