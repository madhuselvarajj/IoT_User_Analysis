    /* filename: .\Arduino\beacon\beacon.ino */
    
    typedef enum State{
      menu,
      output_on,
      val_edit
    } state;
    
    void setup()
    {
      // put your setup code here, to run once:
      state = menu;
    }
    
    void loop()
    {
      // put your main code here, to run repeatedly:
      state = val_edit;
    }
