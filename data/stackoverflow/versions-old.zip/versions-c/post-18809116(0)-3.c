    class LedControl {
      void attach(uint8_t pin1, uint8_t pin2, uint8_t pin3);
    };

    void LedControl::attach(uint8_t pin1, uint8_t pin2, uint8_t pin3) {
      this.pin1 = pin1;
      this.pin2 = pin2;
      this.pin3 = pin3;
      // do other setup type operations
      return;
    }
