    int Bytes2Short(unsigned char msb, unsigned char lsb)
    {
      long t = msb * 0x100L + lsb;
      if (t >= 32768)
        t -= 65536;
      return (int)t;
    }
