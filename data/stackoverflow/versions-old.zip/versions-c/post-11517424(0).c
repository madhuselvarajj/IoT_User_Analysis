    int gpio_init (void)
    {
      int      fd ;
    
      if ((fd = open ("/dev/mem", O_RDWR) ) < 0)
      {
        fprintf (stderr, "gpio_init: unable to open /dev/mem: %s\n", strerror (errno)) ;
        return -1 ;
      }
    
      gpio = mmap(NULL, BLOCK_SIZE, PROT_READ|PROT_WRITE, MAP_SHARED, fd, GPIO_BASE) ;
    
      if (gpio == MAP_FAILED)
      {
        fprintf (stderr, "gpio_init: mmap failed: %s\n", strerror (errno)) ;
        close(fd);
        return -1 ;
      }
    
      close(fd);
      return 0 ;
    }
