    void setup() {
        for (uint8_t pin=0; pin<20; ++pin) {
            pinMode(pin, OUTPUT);
        }
    }
    
    void blink(const uint8_t pos) {
        digitalWrite(pos, HIGH);
        delay(200);
        digitalWrite(pos, LOW);
    }
    
    void loop() {
        for (uint8_t pos=0; pos<19; ++pos) {
            blink(pos);
        }
        for (uint8_t pos=19; pos>0; --pos) {
            blink(pos);
        }
    }
