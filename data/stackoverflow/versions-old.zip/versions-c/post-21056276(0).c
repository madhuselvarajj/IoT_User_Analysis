    union sig_union
    {
        struct
        {
            unsigned unit   :2;
            unsigned channel:2;
            unsigned status :1;
            unsigned group  :1;
            unsigned remote :26;
        } d;                       /* Note the name here. */
        unsigned long data;
    } signal;
    typedef union sig_union Signal;
