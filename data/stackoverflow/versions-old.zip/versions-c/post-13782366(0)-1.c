    /*
     * assuming the pin is muxed as a gpio output, set its value.
     */
    int at91_set_gpio_value(unsigned pin, int value)
    {
            void __iomem    *pio = pin_to_controller(pin);
            unsigned        mask = pin_to_mask(pin);
    
            if (!pio)
                    return -EINVAL;
            __raw_writel(mask, pio + (value ? PIO_SODR : PIO_CODR));
            return 0;
    }
    EXPORT_SYMBOL(at91_set_gpio_value);
