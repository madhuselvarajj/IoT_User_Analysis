    void reverse(char *s)                // reverse a string in place
    {
        char *e = s + strlen(s) - 1;     // find the end of the string
        char tmp;
        while (s < e)                    // loop to swap characters and move pointers
        {                                // towards the middle of the string
            tmp = *e;
            *e-- = *s;
            *s++ = tmp;    
        }
    }
    
    char digit(int x)        // turn an integer into a single digit
    {
        if (x < 10)
            return '0' + x;       // 0-9
        else
            return 'a' + x - 10;  // a, b, c, d, e, f, g....
    }
    
    void tobase(char *s, int x, int base) // convert an integer into a string in
    {                                     // the given base
        int r;
        char *p = s;
        while (x)
        {
            r = x % base;    // extract current digit
            x = x / base;    // divide to get lined up for next digit
            *p++ = digit(r); // convert current digit to character
        }
        *p = '\0';           // null terminate the string
        reverse(s);          // and reverse it, since we generated the digits 
    }                        // backwards
