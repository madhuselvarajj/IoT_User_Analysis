    #include <unistd.h> 
    #include <sys/stat.h> 
    #include <fcntl.h> 
    #include <stdlib.h> 
    
    int main() 
    { 
      char block[1024]; //buffer of data
      int out; //file deccriptor
      int nread; //size of data
      out = open("file.out", O_WRONLY|O_CREAT, S_IRUSR|S_IWUSR); 
      write(out,block,nread); 
      exit(0); 
    }
