    int Comp(char* input) {
      //Internal variables
      int i = 0;
    
      int curr = 0;
      while(Serial.available() > 0) //Don't read unless you know there is data
      {
        if(index < 19) //One less than the size of the array
        {
          inChar = Serial.read(); //Read a character
          if(input[curr] == '\0') return 0; // Input ended, but data is still there.
          if(input[curr++] != inChar) return 0; // Data doesn't match.
        }
        else return 1;  // Data matches.
       }
    
       return 1;  // Data matches.
    }
