    char buffer[100];               // needs to be large enough.
    int c = 33;
    sprintf (buff, "hello %d", c);  // nicer formatting with space
    // Now do something with buff.
