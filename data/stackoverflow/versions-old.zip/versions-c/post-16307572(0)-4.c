while(1)
        {
            waitButton( true )
            printf("The button has been pressed\n");

            waitButton( false ) ;
        }
