    int i, iMax;
    int maxValue=INT_MIN;
    for(i=0;i<16;i++) {
      if(x[i] > maxValue) {
        maxValue = x[i];
        iMax = i;
      }  
    }
