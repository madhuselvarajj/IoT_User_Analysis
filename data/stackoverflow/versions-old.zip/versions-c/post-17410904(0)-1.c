    #include <unistd.h>

    /* For the example main(): */
    #include <sys/types.h>
    #include <sys/wait.h>
    #include <string.h>
    #include <stdio.h>
    #include <errno.h>

    /* Try executing a command in a child process.
     * Returns the PID of the child process,
     * but does not tell whether the execution was
     * successful or not.
     * Returns (pid_t)-1 with errno set if fork() fails.
    */
    pid_t run(char *const command[])
    {
        pid_t   child;

        child = fork();
        if (child == (pid_t)-1)
            return (pid_t)-1;

        if (!child) {
            execvp(command[0], command);
            _exit(127);
        }

        return child;
    }

    int main(int argc, char *argv[])
    {
        pid_t child, p;
        int   status;

        if (argc < 2 || !strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
            fprintf(stderr, "\n");
            fprintf(stderr, "Usage: %s [ -h | --help ]\n", argv[0]);
            fprintf(stderr, "       %s COMMAND [ ARGUMENTS .. ]\n", argv[0]);
            fprintf(stderr, "\n");
            return 1;
        }

        child = run(argv + 1);
        if (child == (pid_t)-1) {
            fprintf(stderr, "%s: %s.\n", argv[1], strerror(errno));
            return 1;
        }

        fprintf(stderr, "(%s: PID %d)\n", argv[1], (int)child);
        fflush(stderr);

        do {
            p = waitpid(child, &status, 0);
            if (p == (pid_t)-1 && errno == EINTR)
                continue;
        } while (p != child && p != (pid_t)-1);
        if (p == (pid_t)-1) {
            fprintf(stderr, "(%s: %s.)\n", argv[1], strerror(errno));
            return 1;
        }

        if (WIFEXITED(status)) {
            if (WEXITSTATUS(status) == 127)
                fprintf(stderr, "(%s: Could not execute command.)\n", argv[1]);
            else
            if (WEXITSTATUS(status) == 0)
                fprintf(stderr, "(%s: Exited successfully.)\n", argv[1]);
            else
                fprintf(stderr, "(%s: Exited with error %d.)\n", argv[1], WEXITSTATUS(status));
        } else
        if (WIFSIGNALED(status))
            fprintf(stderr, "(%s: Killed by %s.)\n", argv[1], strsignal(WTERMSIG(status)));
        else
            fprintf(stderr, "(%s: Died from unknown causes.)\n", argv[1]);

        return status;
    }
