    FILE *fp;
    char results[50]
    
    /* check if file could be opened */
    if((fp=fopen("test.txt", "w")) == NULL) { // or use "a" instead of "w" to create the file if it doesn't exist
        printf("Cannot open file.\n");
        exit(1);
    }
    /* put your results into results[] */
     ....
    /* afterwards writing to file */
    fprintf(fp, "%s", results); 
    fclose(fp);
