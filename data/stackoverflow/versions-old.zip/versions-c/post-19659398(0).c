    #define kAccelStep 4
    void accelerate_step() {
        uint8_t x = OCR0;
        if(x < (255 - kAccelStep))
            OCR0 = x + kAccelStep;
        else
            OCR0 = 255;
    }
