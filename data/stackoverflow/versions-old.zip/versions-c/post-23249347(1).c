    #define GMilliSecondPeriod F_CPU / 1000

    unsigned int gNextOCR = 0;
    volatile unsigned long gMillis = 0;
    bool valveOpened = false;
    
    // This interruption will be called every 1ms
    ISR(TIMER2_COMPA_vect)
    {
      if(valve_open){
        gMillis++;
        if(gMillis >= 30){
          close_valve();
          gMillis = 0;
        }
      }  

      gNextOCR += GMilliSecondPeriod;
      OCR2A = gNextOCR >> 8; // smart way to handle millis, they will always be average of what they should be
    }
    
    // Just call this function within your setup
    void setupTime(){
      TCCR2B |= _BV(CS02);
      TIMSK2 |= _BV(OCIE0A);

      sei(); // enable interupts
    }
