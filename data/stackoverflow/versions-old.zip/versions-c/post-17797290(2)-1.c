    /* filename: .\Arduino\libraries\beacon\beacon.h */

    typedef enum State{  // <-- the us of typedef is optional
      menu,
      output_on,
      val_edit
    };
