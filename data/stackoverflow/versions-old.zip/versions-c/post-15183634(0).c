    void getGyroValues () {
      byte MSB, LSB;
    
      MSB = readI2C(0x29);
      LSB = readI2C(0x28);
      // Shift the value in MSB left by 8 bits and OR with the 8-bits of LSB
      // And store this result in x
      x = ((MSB << 8) | LSB);
    
      MSB = readI2C(0x2B);
      LSB = readI2C(0x2A);
      // Do the same as above, but store the value in y
      y = ((MSB << 8) | LSB);
    
      MSB = readI2C(0x2D);
      LSB = readI2C(0x2C);
      // Do the same as above, but store the value in z
      z = ((MSB << 8) | LSB);
    }
