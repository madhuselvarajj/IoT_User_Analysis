    int get_both(int* b) {
        a = 0;
        *b = 1;
        return a;
    }
