 commFrame_t frame;
 
 if (read(tty_fd,&frame,sizeof(frame))){
  // Process a frame
 }
