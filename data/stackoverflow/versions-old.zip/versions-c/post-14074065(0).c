    int main(int argc, char **argv)
    
    {
    
       bmp085_Calibration();
    
       while (true) //loop indefinitely
       {
         temperature = bmp085_GetTemperature(bmp085_ReadUT());
         pressure = bmp085_GetPressure(bmp085_ReadUP());
         altitude = bmp085_Altitude(pressure);
    
         printf("Temperature\t%0.1f *F\n", ((double)temperature)/10 * 1.8 + 32);
         printf("Pressure\t%0.2f hPa\n", ((double)pressure)/100);
         printf("Altitude\t%0.1f Feet\n", ((double)altitude)*3.280839895);

         //either sleep for 30 minutes or check variable to see if 30 minutes has passed
         usleep((1000*60)*30); //sleep 30 minutes
       }
    
       return 0;
    }
