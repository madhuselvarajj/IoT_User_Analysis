    void loop() {
        do  {
            button1state = digitalRead(button1pin);
            button2state = digitalRead(button2pin);
           
            if (button1state != lastButton1state) {
                if (button1state == HIGH) {
                   button1counter++;
                   Serial.print("number of button 1 pushes: ");
                   Serial.println(button1counter);
                }
                lastButton1state = button1state;
            }
       } while(button2state == LOW);
    
      Serial.println("done");
    
    
    }
