    String stringOne = "A long integer: ";
    // using += to add a long variable to a string:
    stringOne += 123456789;

    // or

    stringTwo.concat(123456789);
