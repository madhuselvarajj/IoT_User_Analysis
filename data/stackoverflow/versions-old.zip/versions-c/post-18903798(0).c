    int globalInt;
    
    void incGlobal() {
        globalInt++;
    }
    
    int main() {
        globalInt = 0;
        printf("%d\n", globalInt);
        incGlobal();
        printf("%d\n", globalInt);
        incGlobal();
        printf("%d\n", globalInt);
        incGlobal();
    }
