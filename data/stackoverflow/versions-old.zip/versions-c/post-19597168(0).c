    char scaledData = ScaleToChar(int x);
    
    char ScaleToChar(int x)
    {
        int a = x;
     float ratio;
     //bound a:  -32768 to 32768
     if (abs(x) > 32768)
     {
      a = (x >= 0) ? (32768) : (-32768);
     }
     //scale x: -128 to 127
     ratio = (a <= 0) ? (128.0/32768.0) : (127.0/32768);
    
     return (char)(a * ratio);
    }
