    String serialDataIn;
    String data[3];
    int counter;


    int inbyte;
    
    void setup(){
      Serial.begin(9600);
      counter = 0;
      serialDataIn = String("");
    }
    
    void loop()
    {
        if(serial.available){
            inbyte = Serial.read();
            if(inbyte >= '0' & inbyte <= '9')
                serialDataIn += inbyte;
            if (inbyte == ','){  // Handle delimiter
                data[counter] = String(serialDataIn);
                serialDataIn = String("");
                counter = counter + 1;
            }
            if(inbyte ==  '\r'){  // end of line
                    handle end of line a do something with data
            }        
        }
    }
