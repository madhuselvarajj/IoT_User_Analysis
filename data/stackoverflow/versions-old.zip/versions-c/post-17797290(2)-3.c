    /* filename: .\Arduino\beacon\beacon.ino */
    
    enum State{
      menu,
      output_on,
      val_edit
    } state; // <-- the actual instance, so can't be a typedef
    
    void setup()
    {
      // put your setup code here, to run once:
      state = menu;
    }
    
    void loop()
    {
      // put your main code here, to run repeatedly:
      state = val_edit;
    }
