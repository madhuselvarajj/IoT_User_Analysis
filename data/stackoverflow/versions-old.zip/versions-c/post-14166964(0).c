    void reverse(char *s)
    {
        char *e = s + strlen(s) - 1;
        char tmp;
        while (s < e)
        {
            tmp = *e;
            *e-- = *s;
            *s++ = tmp;    
        }
    }
    
    char digit(int x)
    {
        if (x < 10)
            return '0' + x;
        else
            return 'a' + x;
    }
    
    void tobase(char *s, int x, int base)
    {
        int r;
        char *p = s;
        while (x)
        {
            r = x % base;
            x = x / base;
            *p++ = digit(r);
        }
        *p = '\0';
        reverse(s);
    }
