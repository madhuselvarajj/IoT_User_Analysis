    #include "TimerOne.h"
    /*
     * kegboard-serial-simple-blink07
     * This code is public domain
     *
     * This sketch sends a receives a multibyte String from the iPhone
     * and performs functions on it.
     *
     * Examples:
     * http://arduino.cc/en/Tutorial/SerialEvent
     * http://arduino.cc/en/Serial/read
     */
    
     // global variables should be identified with _
    
     // flow_A LED
     int led = 4;
     // relay_A
     const int RELAY_A = A0;
    
     // variables from sketch example
     String  inputString = ""; // a string to hold incoming data
     boolean stringComplete = false; // whether the string is complete
     
     boolean shouldBeBlinking = false;
     boolean ledOn = false;
    
    void setup() {
       Serial.begin(9600); // open serial port, sets data rate to 2400bps
       Serial.println("Power on test");
       inputString.reserve(200);
       pinMode(RELAY_A, OUTPUT);
       pinMode(led, OUTPUT);
       digitalWrite(led, LOW);
       Timer1.initialize(100000);
       Timer1.attachInterrupt(timer1Callback);
    }
    
    void loop() {  
      if (!stringComplete)
        return;
      if (inputString == "{blink_Flow_A}") 
        flow_A_blink_start();    
      if (inputString == "{blink_Flow_B}") 
        flow_A_blink_stop();
      inputString = "";
      stringComplete = false;
    }
    
    void timer1Callback() {
      /* If we are not in blinking mode, just make sure the LED is off */  
      if (!shouldBeBlinking) {
        digitalWrite(led, LOW);
        ledOn = false;
        return;
      }
      /* Since we are in blinking mode, check the state of the LED. Turn
         it off if it is on and vice versa. */
      ledOn = (ledOn) ? false : true; 
      digitalWrite(led, ledOn);
    }  
    
    void flow_A_blink_start() {
      shouldBeBlinking = true;
      open_valve();
    }
    
    void flow_A_blink_stop() {
      shouldBeBlinking = false;
      close_valve();  
    }
      
    void close_valve() {
      digitalWrite(RELAY_A, LOW); // turn RELAY_A off
    }
    
    void open_valve() {
      digitalWrite(RELAY_A, HIGH); // turn RELAY_A on
    }
    
    
    //SerialEvent occurs whenever a new data comes in the
    //hardware serial RX.  This routine is run between each
    //time loop() runs, so using delay inside loop can delay
    //response.  Multiple bytes of data may be available.
    
    void serialEvent() {
      if (stringComplete)
        return;  
      while(Serial.available()) {
        // get the new byte:
        char inChar = (char)Serial.read();
        // add it to the inputString unless it is a newline
        if (inChar != '\n')
          inputString += inChar;
        // if the incoming character is a newline, set a flag
        // so the main loop can do something about it:
        else {
          stringComplete = true;
        }
      }
    }
