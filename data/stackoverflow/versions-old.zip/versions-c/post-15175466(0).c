    int charFromHex(char x)
    {
       if ((x >= '0') && (x <= '9'))
       {
         return x - '0';
       }
       else if ((x >= 'A') && (x <= 'F'))
       {
          return x - 'A' + 10;
       }
       else
       {
         return 0; 
         //somehow handle error!
       }
    {
