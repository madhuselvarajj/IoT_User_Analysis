    char * item = strtok (stringToParse, delim);
    while (item != NULL)
    {
      Serial.println(item);
      item = strtok (NULL, delim);
    }
