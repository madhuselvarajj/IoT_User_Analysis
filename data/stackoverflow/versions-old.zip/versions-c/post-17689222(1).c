        rc = tcgetattr(fd, &tty);
        if (rc < 0) {
            /* handle error */
        }
        savetty = tty;    /* preserve original settings for restoration */

        spd = B9600;
        cfsetospeed(&tty, (speed_t)spd);
        cfsetispeed(&tty, (speed_t)spd);

        tty.c_cflag &= ~PARENB
        tty.c_cflag &= ~CSTOPB
        tty.c_cflag &= ~CSIZE;
        tty.c_cflag |= CS8;

        tty.c_cflag &= ~CRTSCTS;    /* no HW flow control? */
        tty.c_cflag |= CLOCAL | CREAD;

        tty.c_iflag |= IGNPAR | ICRNL;
        tty.c_iflag &= ~(IXON | IXOFF | IXANY);
        tty.c_lflag |= ICANON;
        tty.c_oflag |= OPOST | ONLCR;

        rc = tcsetattr(fd, TCSANOW, &tty);
        if (rc < 0) {
            /* handle error */
        }
