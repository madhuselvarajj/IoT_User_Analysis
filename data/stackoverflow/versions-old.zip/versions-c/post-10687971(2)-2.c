    void loop()
    {
      int topLevel = 0;
      int currentSort = 0;
      /* You never initialize this - what's supposed to be in it? */
      int numbers [49];
      int sizeOfArray = sizeof(numbers)/sizeof(int);
      /* Two things here: you're passing an array (numbers) in where the 
         sortNumbers() function has it declared as an int;
         and the return value is declared as an int, but you're storing it 
         into an array. */
      numbers = sortNumbers(topLevel,currentSort,sizeOfArray,numbers);
    }
    
    /* You're going to have to change this method signature - you're working 
       with arrays, not plain ints. You're changing numbers[] inline, so you 
       don't need to return anything. */
    int sortNumbers(int p,int c,int l,int numbers)
    {
     /* The first iteration has c = 0, so [c-1] is going to be out-of-bounds. 
        Also, when c = l, [c] will be out of bounds. */
     if( numbers[c-1] > numbers[c] )
     {
       int temp = numbers[c-1];
       numbers[c-1] = numbers[c];
       numbers[c] = temp;
     }
     if( c == l )
     {
       c = 0;
       p++;
     }
     if( p == l+1 )
     {
       return numbers;
     }
     return sortNumbers(p,c+1,l, numbers);
    }
