        // print stuff to see what has been read
        int i;
        for(i = 0; i < sizeof(buf); i++) {
            printf("%i", (int)buf[i]);
        }
