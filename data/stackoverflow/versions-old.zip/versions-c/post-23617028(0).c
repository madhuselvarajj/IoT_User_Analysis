    #include <stdio.h>
    #include <stdlib.h>

    int main(int argc, const char * argv[])
    {
    char *a = "10100110";
    
    int b = (int) strtol(a, NULL, 2);
    
    printf("%d", b); //prints 166
    
    return 0;
    }
