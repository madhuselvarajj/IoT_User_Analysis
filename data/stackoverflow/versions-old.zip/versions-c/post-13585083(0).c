    // Flag needs to be volatile if used in an ISR
    volatile int buttonFlag = 0; 
    
    void loop()
    {
        if (buttonFlag == 0)
        {
            heartbeat();                        //make led beat
        }
        else
        {
            analogWrite(greenPin, 255);         //button stays green once pushed
            functionA                           //has some delays in it
            functionB                           //has some other delays
            buttonFlag = 0;                     //clear flag after executing code
        }
        
    }
    
    // Interrupt Service Routine attached to INT0 vector
    ISR(EXT_INT0_vect)
    {
        buttonFlag = digitalRead(buttonPin);    //set flag to value of button
    }
