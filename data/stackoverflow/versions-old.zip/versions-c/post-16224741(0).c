     #include <Ethernet.h>
     
     // network configuration.  gateway and subnet are optional.
     
      // the media access control (ethernet hardware) address for the shield:
     byte mac[] = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED };  
     // the router's gateway address:
     byte gateway[] = { 10, 0, 0, 1 };
     // the subnet:
     byte subnet[] = { 255, 255, 0, 0 };
     
     EthernetServer server = EthernetServer(23);
     
     //the IP address is dependent on your network
     IPAddress ip(192,168,1,1);
     void setup()
     {
       // initialize the ethernet device
       Ethernet.begin(mac, ip, gateway, subnet);
     
       // start listening for clients
       server.begin();
     }
     void loop()
     {
       //print out the IP address
       Serial.println(myIPaddress);
     }
