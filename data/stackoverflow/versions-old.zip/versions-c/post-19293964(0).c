    const int a = 600;
    const unsigned char high = ((a >> 8) & 0xff) | 0x80;
    const unsigned char low  = (a & 0xff);

    Serial.print(high);
    Serial.print(low);
