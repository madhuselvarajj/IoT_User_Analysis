    #define GPFSEL1 ((UINT32_P)0x20200004)
    #define GPFSEL2 ((UINT32_P)0x20200008)
    
    #define GPSET0  ((UINT32_P)0x2020001C)
    #define GPCLR0  ((UINT32_P)0x20200028)
