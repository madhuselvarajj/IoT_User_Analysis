    char buff[100]; // needs to be large enough.
    int c = 33;
    sprintf (buff, "hello%d", c); // may want a space after hello

    // Now do something with buff.
