    uint8_t B = 34;
    char C = 34;
    int  D = 34;
     
    printf("0x%02x\n", 'A'); // surrounded with '' gives ASCII value of 65, displayed in Hex
    printf("0x%02x\n", B);
    printf("0x%02x\n", C);
    printf("0x%02x\n", D);
