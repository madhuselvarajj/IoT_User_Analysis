    int main(void)
    {
    
     FILE *fp;
     char filename[]=".\\in.txt";
     uint8_t c;  //as specified, uint8_t data type
     
     fp=fopen(filename, "r");
     
     c = fgetc(fp);//read each character into a uint8_t
     while(c<255)
     {
      printf("0x%02x\n", c);//display each uint8_t as a hexadecimal
      c = fgetc(fp); 
     }
     fclose(fp);
     getchar();//stop execution to view files (hit any key to exit)
        return 0
    }
