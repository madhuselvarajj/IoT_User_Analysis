    class LedControl {
      LedControl();
      LedControl(uint8_t pin1, uint8_t pin2, uint8_t pin3);
      
    private:
      uint8_t pin1;
      uint8_t pin2;
      uint8_t pin3;
    };
    
    LedControl::LedControl() : pin1(0), pin2(0), pin3(0) {
      // this constructor leaves the class unusable
    }

    LedControl::Ledcontrol(uint8_t p1, uint8_t p2, uint8_t p3) 
      : pin1(p1), pin2(p2), pin3(p3)
    {
      // this object is ready to use    
    }
