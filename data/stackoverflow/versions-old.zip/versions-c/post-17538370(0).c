    bool checkForCorrectCommand(String cmd) {

      if(inputString == cmd) { 
        ...
        inputString = "";
        stringComplete = false;
        return true;

      [ } else { ] <- does not show in above code paste

      // reset String variables for serial data commands
        inputString = "";
        stringComplete = false;
        return false;
    }
