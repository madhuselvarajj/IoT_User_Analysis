    void flash(int numFlashes, int d);

    void loop
    {
        /* .... */
    }
