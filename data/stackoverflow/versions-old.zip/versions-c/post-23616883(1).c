      int n = 0;  // unsigned might be better here
      for (i = 0; i < 10; i++) {
        int bit = analogRead(A0) & 1;
        putchar('0' + bit);
        n = (n << 1) | bit;
        delay(50);
      }
      printf("\n%d\n", n);
