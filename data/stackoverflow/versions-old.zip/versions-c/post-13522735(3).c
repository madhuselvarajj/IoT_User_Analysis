    typedef struct serial_port_s serial_port;
    typedef void (*serial_on_recived_proc)(serial_port* p);
    typedef struct serial_port_s{
     bool timeoutFlag;
     bool receiveFlag;
     void* context;
     serial_on_recived_proc response_handler;
    };
    
    void send_serial(serial_port* p, char* message)
    {
     //SendMsg?
    }
    void receive_serial(serial_port* p, char* response)
    {
     //receiveMsg?
    }
    
    bool has_data(serial_port* p)
    {
     return p->receiveFlag;
    }
    
    bool has_timed_out(serial_port* p)
    {
     return p->timeoutFlag;
    }
    bool is_serial_finished(serial_port* p)
    {
     return has_data(p) || has_timed_out(p); 
    }
    
    bool serial_check(serial_port* p)
    {
     if(is_serial_finished(p) && p->response_handler != NULL)
     {
        p->response_handler(p)
           p-> response_handler = NULL;
           return true;
     }
        return false;
    }
    
    void send(serial_port* p, char* message, char* response)
    {
     p->response_handler=NULL;
     send_serial(p, message);
     while(!is_serial_finished(p));
     receive_serial(p, response);
    }
    
    void sendAsync(serial_port* p, char* message, serial_on_recived_proc handler, void* context)
    {
     p->response_handler = handler;
     p->context = context;
     send_serial(p, message);
    }
    
    void pow_response(serial_port* p)
    {
     // could pass a pointer to a struct, or anything depending on what you want to do
     char* r = (char*)p->context;  
     receive_serial(p, r);
     // do stuff with the pow response
    }

    typedef struct
    {
       char text[100];       
       int x;
       bool has_result;
    } bang_t;

    void bang_parse(bang_t* bang)
    {
       bang->x = atoi(bang->text);
    }

    void bang_response(serial_port* p)
    {
     bang_t* bang = (bang_t*)p->context;  
     receive_serial(p, bang->text);
     bang_parse(bang);
        bang->has_result=true;
    }
    
    void myFunc();
    {
     char response[100];
     char pow[100];
        bang_t bang1;
        bang_t bang2;
     serial_port p; //
        int state = 1;
     // whatever you need to do to set the serial port

        // sends and blocks till a response/timeout
     send(&p, "Hello", response);
        // do what you like with the response

        // alternately, lets do an async send...
     sendAsync(&p, "Pow", pow_response, pow);       
       
     while(true)
     {
      // non block check, will process the response when it arrives               
      if(serial_check(p))
                {
                  // it has responded to something, we can send something else...

                  // using a very simple state machine, work out what to send next.
                  // in practice I'd use enum for states, and functions for managing state
                  // transitions, but for this example I'm just using an int which
                  // I just increment to move to the next state
                  switch(state)
                  {
                  case 1: 
                     // bang1 is the context, and will receive the data
                     sendAsync(&p, "Bang1", bang_response, &bang1);
                     state++; 
                     break;
                  case 2:
                     // now bang2 is the context and will get the data...
                     sendAsync(&p, "Bang2", bang_response, &bang2);
                     state++; 
                     break;
                  default:
                     //nothing more to send....
                     break;
                  }
                }
      // do other stuff you want to do in parallel
     }
    };
