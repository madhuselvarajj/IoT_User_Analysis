    struct legtype {
        Servo hip;
        Servo shin;
        Servo foot;
    };

    typedef legtype leg;
