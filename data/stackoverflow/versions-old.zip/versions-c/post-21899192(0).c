    union {
      uint8_t BAR;
      struct {
        uint8_t  r1 : 1; // bit position 0
        uint8_t  r2 : 2; // bit positions 1..2
        uint8_t  r3 : 3; // bit positions 3..5
        uint8_t  r4 : 2; // bit positions 6..7 
        // total # of bits just needs to add up to the uint8_t size
      } bar;
    } foo;

    void setup() {
      Serial.begin(9600);
      foo.bar.r1 = 1;
      foo.bar.r2 = 2;
      foo.bar.r3 = 2;
      foo.bar.r4 = 1;

      Serial.print(F("foo.bar.r1 = 0x"));
      Serial.println(foo.bar.r1, HEX);
      Serial.print(F("foo.bar.r2 = 0x"));
      Serial.println(foo.bar.r2, HEX);
      Serial.print(F("foo.bar.r3 = 0x"));
      Serial.println(foo.bar.r3, HEX);
      Serial.print(F("foo.bar.r4 = 0x"));
      Serial.println(foo.bar.r5, HEX);

      Serial.print(F("foo.BAR = 0x"));
      Serial.println(foo.BAR, HEX);
    }
