    String deBinaryStringify(String source) {
     char val = 0;
     String result = "";
     for (int i=0; i<source.length(); i++) {
      val += (source.charAt(i) == '1') << (7-(i%8)); // Trick: using an evaluation result as an int
      if ((i>0) && (i%8==0)) {
       result.concat(val);
       val = 0;
      }
     }

     if (source.length() % 8 > 0) {
         // What do you want to do if source doesn't contain enough bits for full number of bytes?
           result.concat(val);
        }
     return result;
    }
