    typedef struct {
        byte LED1 : 1;
        byte LED2 : 1;
        byte LED3 : 1;
        byte LED4 : 1;
        byte LED5 : 1;
        byte LED6 : 1;
        byte LED7 : 1;
        byte LED8 : 1;
    } LED_ROW;

    LED_ROW leds[256];

    leds[0].LED1 = 1; // turn led at row 0, col 0 to 1
    leds[0].LED5 = 1; // turn led at row 4, col 0 to 1
    led[100].LED3 = 1; // turn led at row 2, col 100 to 1
    ...
    // and so on
