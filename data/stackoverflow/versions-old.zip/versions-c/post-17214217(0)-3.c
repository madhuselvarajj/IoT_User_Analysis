    #define THROTTLE_PIN 6
    #define STEERING_PIN 7
    #define WHEEL_PIN    8
    #define MFORWARD_PIN 13
    #define MBACKWARD_PIN 10

    Servo wheel;
 
    // sets up the arduino
    void setup() {
        Serial.begin(115200);
        wheel.attach(WHEEL_PIN);
        pinMode(THROTTLE_PIN, INPUT);
        pinMode(STEERING_PIN, INPUT);
    }

    // input data handling
    int read_throttle() {
        int throttle = pulseIn(THROTTLE_PIN, HIGH, 20000);
        return map(throttle, 1000, 2000, -255, 255);
    }

    int read_steering() {
        int steering = pulseIn(STEERING_PIN, HIGH, 20000);
        return map(throttle, 1000, 2000, 24, 169);
    }

    // output actions handling
    void move_forward(int val) {
        analogWrite(MFORWARD_PIN, val);
        digitalWrite(MBACKWARD_PIN, LOW);
        // Serial.print...
    }

    void move_backward(int val) {
        analogWrite(MFORWARD_PIN, val);
        digitalWrite(MBACKWARD_PIN, LOW);
        // Serial.print...
    }

    void stop_motor() {
        digitalWrite(MFORWARD_PIN, LOW);
        digitalWrite(MBACKWARD_PIN, LOW);
    }

    void handle_throttle(int throttle) {
        if (throttle > 40)
            move_forward(throttle);
        elif (throttle < -40)
            move_backward(throttle);
        else
            stop_motor();
    }

    // general algorithm
    void loop() {
        int throttle = read_throttle();
        delay(5);
        handle_throttle(throttle);
    }
