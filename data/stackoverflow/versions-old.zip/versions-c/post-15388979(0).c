    #include <stdio.h>
    #include <math.h>
    
    #define PLACES 3
    
    void extract(double x)
    {
            char buf[PLACES+10], tmp[PLACES+10];
            int a, b;
    
            sprintf(buf, "%.*f", PLACES, x);
            sscanf(buf, "%d.%s", &a, tmp);
            sscanf(tmp, "%d", &b);
    
            int n = (int) pow(10, PLACES);
    
            printf("Number           : %.*f\n", PLACES, x);
            printf("  Integer        : %d\n", a);
            printf("  Fractional part: %d over %d\n", b, n);
    }
    
    int main()
    {
            extract(1.1128);
            extract(20.0);
            extract(300.000512);
    }
