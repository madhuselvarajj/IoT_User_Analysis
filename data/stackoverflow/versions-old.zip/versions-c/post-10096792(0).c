    void setup() {
      Serial.begin(9600);
      int c = 33;                 // var c = 33;
      String myString = "hello";  // var myString = "hello"
      myString += c;              //                        + c;
      Serial.println(myString);   // alert(myString); //---> hello33
    }

    void loop() {
    }
