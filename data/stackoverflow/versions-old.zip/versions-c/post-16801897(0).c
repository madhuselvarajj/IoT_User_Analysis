    struct ip_mreqn mreq;
    
    inet_aton("225.0.0.37", &mreq.imr_multiaddr);
    mreq.imr_address.s_addr = htonl(INADDR_ANY);
    mreq.imr_ifindex = 0;
