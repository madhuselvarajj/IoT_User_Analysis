    extern "C" {
      #include "Arduino.h"
    }

    void setup();
    void loop();

    void setup()
    {
         LED_open();
    }

    void loop()
    {

    }
