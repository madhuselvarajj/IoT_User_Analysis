    #include <unistd.h>
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <sys/wait.h>
    #include <fcntl.h>
    #include <errno.h>

    /* Helper function: Close file descriptor, without modifying errno.
     * Returns 0 if successful, otherwise the errno reported by close().
    */
    static int closefd(const int fd)
    {
        int saved_errno, result;

        /* Invalid descriptor? */
        if (fd == -1)
            return EINVAL;

        /* Save errno. It's thread-local, so as long as we restore
         * it before returning, no-one will notice any change in it. */
        saved_errno = errno;

        /* Close descriptor, and save errno (or 0) in result. */
        do {
            result = close(fd);
        } while (result == -1 && errno == EINTR);
        if (result == -1)
            result = errno;
        else
            result = 0;

        /* Restore errno. Done. */
        errno = saved_errno;

        return result;
    }

    /* Helper function: Create a close-on-exec pipe.
     * Return 0 if success, errno otherwise.
    */
    int close_on_exec_pipe(int fds[2])
    {
        int result;

        result = pipe(fds);
        if (result == -1) {
            fds[0] = -1;
            fds[1] = -1;
            return errno;
        }

        do {

            do {
                result = fcntl(fds[0], F_SETFD, FD_CLOEXEC);
            } while (result == -1 && errno == EINTR);
            if (result == -1)
                break;

            do {
                result = fcntl(fds[1], F_SETFD, FD_CLOEXEC);
            } while (result == -1 && errno == EINTR);
            if (result == -1)
                break;

            /* Success. */
            return 0;

        } while (0);

        /* Failed. */
        closefd(fds[0]);
        closefd(fds[1]);
        fds[0] = -1;
        fds[1] = -1;

        return errno;
    }

    /* Run an external command in a child process.
     * command[0] is the path or name of the command,
     * and the array must be terminated with a NULL.
     *
     * If successful, this function will return the PID
     * of the child process. Otherwise, it will return
     * (pid_t)-1, with errno indicating the error.
    */
    pid_t run(char *const command[])
    {
        pid_t   child, p;
        int     commfd[2], errcode;

        /* Create a close-on-exec pipe between the parent and child. */
        if (close_on_exec_pipe(commfd))
            return (pid_t)-1;

        /* Fork the new child process. */
        child = fork();
        if (child == (pid_t)-1) {
            closefd(commfd[0]);
            closefd(commfd[1]);
            return (pid_t)-1;
        }

        if (!child) {
            /* Child process: */

            /* Close the read/parent end of the pipe. */
            closefd(commfd[0]);

            /* In case of C library bugs, prepare errno. */
            errno = EINVAL;

            /* Execute the desired command. */
            execvp(command[0], command);

            /* Failed. errno describes why. */
            errcode = errno;

            /* Send it to the parent via the pipe. */
            {
                const char       *p = (char *)&errcode;
                const char *const q = (char *)&errcode + sizeof errcode;
                ssize_t           n;

                while (p < q) {
                    n = write(commfd[1], p, (size_t)(q - p));
                    if (n > (ssize_t)0)
                        p += n;
                    else
                    if (n != (ssize_t)-1)
                        break;
                    else
                    if (errno != EINTR)
                        break;
                }
            }

            /* Close write/child end of the pipe. */
            closefd(commfd[1]);

            /* Exit with a failure (127). */
            _exit(127);
        }

        /* Parent: */

        /* Close the write/child end of the pipe. */
        closefd(commfd[1]);

        /* Try to read the execution error. */
        {
            char       *p = (char *)&errcode;
            char *const q = (char *)&errcode + sizeof errcode;
            ssize_t     n;

            errcode = 0;

            while (p < q) {
                n = read(commfd[0], p, (size_t)(q - p));
                if (n > (ssize_t)0)
                    p += n;
                else
                if (n != (ssize_t)-1)
                    break; /* n == 0 is pipe closed */
                else
                if (errno != EINTR)
                    break;
            }

            /* Close the read/parent end of the pipe. */
            closefd(commfd[0]);

            /* Pipe closed (on exec), no data read? */
            if (n == (ssize_t)0 && p == (char *)&errcode) {
                /* Yes, success! */
                errno = 0;
                return child;
            }

            /* Execution failed.
             * If we didn't get the reason, use EINVAL. */
            if (!errcode || p != q)
                errcode = EINVAL;
        }

        /* Reap the child process. */
        do {
            p = waitpid(child, NULL, 0);
            if (p == (pid_t)-1) {
                if (errno == EINTR)
                    continue;
                else
                    break;
            }
        } while (p != child);

        /* Return with failure. */
        errno = errcode;
        return (pid_t)-1;
    }
