    /* filename: .\Arduino\beacon\beacon.ino */
    
    enum State{
      menu,
      output_on,
      val_edit
    } state; // <-- the actual instance, so can't be a typedef
    
    void setup()
    {
      state = menu;
    }
    
    void loop()
    {
      state = val_edit;
    }
