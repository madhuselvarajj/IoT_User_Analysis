    boolean shouldMove;
    
    void setup()
    {
     shouldMove = true;//set the flag
    }
    
    void loop()
    {
      if (shouldMove){
        moveForward(5);
      }
    }
    
    
    void moveForward(int steps)
    {
     shouldMove = false; //clear the flag
      for (int x = steps; steps > 0; steps--) {
       // tight loop controlling movement
      }
    }

}
