    struct array
    {
        int len;
        int data[];
    };

    struct array *table[NUMBER_OF_ARRAYS];
