    while (1) {
        while (!button_pressed)
            ;

        printf("Button pressed!\n");

        
        while (elapsed_time < offset)
            ;
    }
