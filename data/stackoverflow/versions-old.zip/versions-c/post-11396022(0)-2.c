    //load status
    int status;
    ioctl(fd, TIOCMGET, &status);

    //disable DTR
    status &= ~TIOCM_DTR;

    //update the status
    ioctl(fd, TIOCMSET, &status);
