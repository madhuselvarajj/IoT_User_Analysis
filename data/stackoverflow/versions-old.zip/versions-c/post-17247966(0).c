    for(;;)
    {
        WaitTimer() ;
        pulses = pulse_count - previous_pulse_count ;
        previous_pulse_count = pulse_count ;
        control = pid( pulse_count ) ;
        motor( control ) ;
    }
