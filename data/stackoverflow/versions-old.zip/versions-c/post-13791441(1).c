    // Put all your preconstructed items in some array.....
    // You'd typically make this a global.

    boolean glyphs[2][6][5] = {
        {
            {0,0,1,0,0},
            {0,0,0,1,0},
            {0,0,1,0,0},
            {0,1,0,0,0},
            {1,0,0,0,0},
            {1,1,1,1,1}
        },
        {
            {1,1,1,1,1},
            {1,0,0,1,1},
            {1,0,1,0,1},
            {1,1,0,0,1},
            {1,0,0,0,1},
            {1,1,1,1,1}
        }
    };

    // Then whereever you want to change the framebuffer in your code:
    // copy the second into a framebuffer:
    memcpy(framebuffer, glyphs[1], sizeof(boolean)*6*5);
