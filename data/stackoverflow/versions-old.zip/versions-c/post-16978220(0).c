    char buff[300];
    memset(buff, 0, sizeof(buff));
    for (;;)
    {
      n=read(fd,buff,sizeof(buff)-1);
      buff[n] = '\0';
      sleep(1);
      printf("%s", buff);
      printf("\n");
      ....
      ....
