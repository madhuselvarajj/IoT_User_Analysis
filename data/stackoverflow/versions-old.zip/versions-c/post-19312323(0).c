    #define HEADER_1 0xFA // here you define your headers, etc. You can also use variables.
    
    uint8_t readByte[4]; // your packet is 4 bytes long. each byte is stored in this array.
    
    void setup() {
     Serial.begin(9600);
    }
    
    void loop() {
    
     while (Serial.avalaible() > 1) { // when there is data avalaible on the serial port
      
      readByte[0] = Serial.read(); // we store the first incomming byte.
      delay(10);
      
      if (readByte[0] == HEADER_1) { // and check if that byte is equal to HEADER_1
      
       for (uint8_t i = 1 ; i < 4 ; i++) { // if so we store the 3 last bytes into the array
        readByte[i] = Serial.read();
        delay(10);
       }
       
      }
      
     }
     
     //then you can do what you want with readByte[]... i.e. check if readByte[1] is equal  to HEADER_2 and so on :)
     
    }
