#include <unistd.h>
    #define DEBOUNCE_MILLISEC 20
    
    void waitButtonRelease()
    {
        int debounce = 0 ;

        usleep(1000) ;

        while( debounce < DEBOUNCE_MILLISEC )
        {
            if( bcm2835_gpio_lev(PIN) )
            {
                debounce = 0 ;
            }
            else
            {
                debounce++ ; 
            }
        }
    }
