    byte b[4];  // contains bytes
    int x= 0;
    
    x= (x << 8) + b[3];
    x= (x << 8) + b[2];
    x= (x << 8) + b[1];
    x= (x << 8) + b[0];
