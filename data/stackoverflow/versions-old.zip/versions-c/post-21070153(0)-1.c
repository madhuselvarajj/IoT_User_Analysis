    void mode0() {
      while(mode == 0){
      digitalWrite(rPin, LOW);
      digitalWrite(yPin, LOW);
      digitalWrite(gPin, LOW);
    
      checkSwitch(); // this will potentially change the 'mode' so the while loop with exit if the mode has changed.
      }
    }
