    ssize_t writen(int fd, char * buffer, size_t size)
    {
      ssize_t written_total = 0;
      ssize_t written = 0;

      while  (outputLength > written_total)
      {
        written = write(fd, buffer + written_total, size - written_total);
        if (-1 == written)
        {
          if (EINTR == errno)
          {
            /* interupted by signal -> break and leave */
            break;
          }
          elseif ((EAGAIN == errno) || (EWOULDBLOCK == errno))
          {
            continue; /* try again */
          }

          /* another error occured -> log, break and leave */
       
          break;
        }

        written_total += written;
      }

      if (outputLength > written_total)
      {
        if (-1 = written)
        {
          /* handle error */
        }
        else
        {
          /* notify of interruption */
        }
      }
      else
      {
        /* log succesfully transmission of all data */
      }

      return written_total;
    }

    int main()
    {
      ...

      do
      {
        if (outputLength != writen(fd, outputString, outputLength))
        {
          fprintf(stderr, "writen(fd, outputString, outputLength) failed");
          break;
        }
       
        if (1 != writen(fd, ",", 1))
        {
          fprintf(stderr, "writen(fd, ",", 1)) failed");
          break;
        }

        if (1 != writen(fd, "0", 1))
        {
          fprintf(stderr, "writen(fd, "0", 1)) failed");
          break;
        }

        if (1 != writen(fd, "\n", 1))
        {
          fprintf(stderr, "writen(fd, "\n", 1)) failed");
          break;
        }
      } while (0);

      if (-1 == close(fd))
      {
        perror("close() failed");
      }

      ...
    }
