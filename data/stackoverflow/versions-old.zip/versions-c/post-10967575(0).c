    void setup() {
        Serial.begin(9600);
        Serial.write("Power On");
    }
    
    void loop()
    {
        while(!Serial.available());
    
        while (true) {
          int byte = Serial.timedRead();
          if(byte == -1)
             break;
          Serial.write(byte);
        }
        Serial.println();
    }
