    #ifndef COMMS_H
    #define COMMS_H
 typedef struct commFrame_t commFrame_t {
  unsigned int wind, 
  signed int temperature;  
 }
    #endif COMMS_H
