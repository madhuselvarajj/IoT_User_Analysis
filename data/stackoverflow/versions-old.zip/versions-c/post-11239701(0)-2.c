    boolean MAX3421E::reset()
    {
        regWr( rUSBCTL, bmCHIPRES );                        //Chip reset. This stops the   oscillator
        regWr( rUSBCTL, 0x00 );                             //Remove the reset
        while(!(regRd(rUSBIRQ) & bmOSCOKIRQ)) ;
    }
