 #include <stdio.h>
    
    #define STATE_ON    0x01
    #define STATE_OFF    0x00
    
    void enable_relay(unsigned char relay, unsigned char state)
    {
        /* This is a brute force approach that enables any relay/port combination:
         * relay 8: PB2
         * relay 7: PB4
         * (...)
         * relay 1: PA1
         */
    
        switch(relay)
        {
            case 8:
                if(state == STATE_ON)
                    GPIOB->ODR |= 0x0004;
                else
                    GPIOB->ODR &= ~0x0004;
                break;
            case 7:
                if(state == STATE_ON)
                    GPIOB->ODR |= 0x0010;
                else
                    GPIOB->ODR &= ~0x0010;
                break;
            case 1:
                if(state == STATE_ON)
                    GPIOA->ODR |= 0x0002;
                else
                    GPIOA->ODR &= ~0x0002;
                break;
        }
    
    }
    
    void check_relay(unsigned char fan_map)
    {
    int i;
    unsigned char bit;
    unsigned char state;
    
        for(i=0; i < 8; i++) {
            bit = (fan_map&(0x01<<i));
            state = ((bit != 0)? STATE_ON : STATE_OFF);
            enable_relay( (8-i), state);
        }
    }
    
    int main(void)
    {
        unsigned char fan_map = 0x0B; /* 0x0B = 00001011 */
        check_relay(fan_map);
    }
