   #include <stdio.h>
    
    void enable_relay(unsigned char fan_map)
    {
    int i;
    unsigned char bit;
    
        for(i=0; i < 8; i++) {
            bit = (fan_map&(0x01<<i));
            if( bit != 0 )
                printf(""relay %d should be ON\n"", 8-i);
            else
                printf(""relay %d should be OFF\n"", 8-i);
        }
    }
    
    int main(void)
    {
        unsigned char fan_map = 0x0B; /* 0x0B = 00001011 */
        enable_relay(fan_map);
    }