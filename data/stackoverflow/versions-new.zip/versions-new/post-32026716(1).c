    #include <unistd.h> // for read & write functions
    #include <sys/select.h> // fd_set functions
    #include <stdio.h> // for perror & printf family
    #include <sys/types.h> // for open related function
    #include <sys/stat.h> // for open related function
    #include <fcntl.h> // for open related function
    #include <termios.h> // for terminal functions
    #include <errno.h> // for error code
    
    #define RFID "path_to_rfid" // FIXME <- you should set this properly
    char read_rfid(char* rfid_num, int fd)
    {
        fd_set input_fdset;
        ssize_t length;
        int done;
    
        for(done=0; done < 14; ) {
            FD_ZERO(&input_fdset);
            FD_SET(fd,&input_fdset);
    
            if(select(fd+1 ,&input_fdset, NULL,NULL,NULL) == -1) {
                perror("Terminal select() failed");
                return -1;
            }
    
            if(FD_ISSET(fd,&input_fdset)) {
                if((length = read(fd,rfid_num+done,14-done)) == -1) {
                    perror("Terminal: read() failed");
                    return -1;
                }
                write(STDOUT_FILENO,rfid_num+done,length);
                done += length;
            }
        }
        return 0;
    }
    
    
    int setupRS232()
    {
        struct termios term_attr;
        int fd = 0;
    
        if((fd = open(RFID,O_RDWR)) == -1) {
            perror("Can't open Device");
            return(-1);
        }
        if(tcgetattr(fd,&term_attr) != 0)
        {
            perror("terminal: tcgetattr() failed");
            close(fd);
            return(-1);
        }
    
        term_attr.c_cflag = CBAUD|CS8|CRTSCTS|CLOCAL|CREAD;
        term_attr.c_iflag = 0;
        term_attr.c_oflag = 0;
        term_attr.c_lflag = 0;
        if(tcsetattr(fd,TCSAFLUSH,&term_attr) != 0) {
            perror("terminal: tcsetattr() failed");
            close(fd);
            return(-1);
        }
        return (fd);
    }
    
    int main(int argc, char** argv)
    {
    
        char rfid_num[14];
        int i;
        int fd;
    
        if((fd = setupRS232()) == -1) {
            return(-1);
        }
    
        puts("Waiting for transponder...");
        read_rfid(rfid_num, fd);
        for(i=0;i<20;i++) {
            printf("%x\n",rfid_num[i]);
        }
    
        return 0;
    }
