class SensorArray {
    sensor** arr = nullptr;
    size_t count = 0; 
   public:
    size_t size() const {
        return count; 
    }
    // Default-construct it
    SensorArray() = default;

    // Make a copy of the SensorArray 
    SensorArray(SensorArray const& source)
      : arr(new sensor*[source.size()])
      , count(source.size())
    {
        std::copy_n(source.arr, source.count, arr);
    }

    // Move-construct SensorArray
    SensorArray(SensorArray&& source)
      : arr(source.arr)
      , count(source.count)
    {
        source.arr = nullptr; 
        source.count = 0; 
    }

    template<class T...>
    SensorArray(T&... sensors)
      : arr(new sensor*[] { &sensors... }) // Initialize arr
      , count(sizeof...(sensors))          // Initialize count
    {} // Constructor is empty because we already initialized stuff

    SensorArray& operator=(SensorArray const& source) {
        if(this == &source) return *this;
        
        SensorArray s = source;
        swap(s);
        return *this; 
    }

    // Copy-and-swap idiom
    // This automatically handles the case of self-assignment
    SensorArray& operator=(SensorArray&& source) {
        SensorArray s = std::move(source);
        swap(s);
        return *this;
    }
    sensor& operator[](int index) const {
        return *arr[index];
    }

    ~SensorArray() {
         delete[] arr;
    }
    void swap(SensorArray& other) {
        std::swap(arr, other.arr);
        std::swap(count, other.count);
    }
};