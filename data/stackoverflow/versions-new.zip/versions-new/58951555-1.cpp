// create your class
    class MyClass {
        int m_canvasX; // we need store the array size somewhere
      public:
        int** m_canvas;
        // assign a value to your member in a method in our constructor
        MyClass(const int canvasX = 1, const int canvasY = 1){
          m_canvasX = canvasX;
          m_canvas = new int*[canvasX];
          for(int x = 0; x < m_canvasX; x++)
            m_canvas[x] = new int[canvasY];
          // store a value for demonstration  
          m_canvas[canvasX-1][canvasY-1] = 1234;
        }
    
        // make sure we free the allocated memory in the destructor
        ~MyClass(){
          for(int x = 0; x < m_canvasX; x++)
            delete[] m_canvas[x];
          delete[] m_canvas;
        }
    
    };
    
    int main(){
    
      // create an instance of your class
      int sizeX = 2;
      int sizeY = 3;
      MyClass example(sizeX,sizeY);
      // print the value to proof that our code actually works
      cout << example.m_canvas[sizeX-1][sizeY-1];
    
      return 0;
    }