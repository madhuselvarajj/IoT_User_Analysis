    int main(void)
     {
     unsigned char c;
     unsigned char b;
    
    while(1)
    {
        a = USART_Receive();
        c = 10;
        a=c;
        a=c/10;
        USART_Transmit(b+48);
        b=0;
        b=c%10;
        USART_Transmit(b+48);
        _delay(10000);
    }
    }
