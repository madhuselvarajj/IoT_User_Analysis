template<typename T>
    struct ArrayView {
        T* ptr;
        std::size_t sz;
    public:
        template<int arrSize>
        ArrayView(T (&arr)[arrSize]) : ptr(arr), sz(arrSize) { }
    
        T& operator[](int i) { return ptr[i]; }
        std::size_t size() const { return sz; }
    };