    #include <iostream>
    #include <string>
    
    class hexset {
     public:
         hexset(int num) {
             this->hexnum = (unsigned short int) num;
             this->hexstring = hexset::to_string(num);
        }
        
        unsigned short int get_hexnum() {return this->hexnum;}
        std::string get_hexstring() {return this->hexstring;}
    
     private:
        static std::string to_string(int decimal) {
            int length = int_length(decimal);
            std::string ret = "";
            for (int i = (length > 1 ? int_length(decimal) - 1 : length); i >= 0; i--) {
                ret = hex_arr[decimal%16]+ret;
                decimal /= 16;
            }
            if (ret[0] == '0') {
                ret = ret.substr(1,ret.length()-1);
            }
            return "0x"+ret;
        }
        
        static int int_length(int num) {
            int ret = 1;
            while (num > 10) {
                num/=10;
                ++ret;
            }
            return ret;
        }
        
        static constexpr char hex_arr[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
        unsigned short int hexnum;
        std::string hexstring;
    };
    
    constexpr char hexset::hex_arr[16];
    
    int main() {
        int number_from_file = 3000; // This number is in all forms technically, hex is just another way to represent this number.
        hexset hex(number_from_file);
        std::cout << hex.get_hexstring() << ' ' << hex.get_hexnum() << std::endl;
        return 0;
    }
