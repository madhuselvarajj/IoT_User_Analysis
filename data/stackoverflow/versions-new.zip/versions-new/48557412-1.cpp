#include <vector>
    #include <algorithm>
    #include <iostream>

    class observable;

    class observer {

    public:

        virtual void notify(observable&) = 0;
    };

    // For simplicity, I will give some default implementation for storing the observers
    class observable {

        // assumping plain pointers
        // leaving it to you to take of memory
        std::vector<observer*> m_observers;

    public:

        observable() = default;

        void notifyObservers() {
            for(auto& obs : m_observers) obs->notify(*this);
        }

        void registerObserver(observer* x) {
            m_observers.push_back(x);
        }

        void unregisterObserver(observer* x) {
            // give your implementation here
        }

        virtual ~observable() = default;
    };

    // our first observable with its own interface
    class clock_observable
    : public observable {

        int m_time;

    public:

        clock_observable(int time)
        : m_time(time){}

        void change_time() {
            m_time++;
            notifyObservers(); // notify observes of time change
        }

        int get_time() const {
            return m_time;
        }
    };

    // another observable
    class account_observable
    : public observable {

        double m_balance;

    public:

        account_observable(double balance)
        : m_balance(balance){}

        void deposit_amount(double x) {
            m_balance += x;
            notifyObservers(); // notify observes of time change
        }

        int get_balance() const {
            return m_balance;
        }
    };

    // this wrapper will be inherited and allows you to access the interface of the concrete observable
    // all concrete observers should inherit from this class
    template <class Observable>
    class observer_wrapper
    : public observer {

        virtual void notify_impl(Observable& x) = 0;

    public:

        void notify(observable& x) {
            notify_impl(static_cast<Observable&>(x));
        }
    };

    // our first clock_observer
    class clock_observer1
    : public observer_wrapper<clock_observable> {

        void notify_impl(clock_observable& x) override {
            std::cout << ""clock_observer1 says time is "" << x.get_time() << std::endl;
        }
    };

    // our second clock_observer
    class clock_observer2
    : public observer_wrapper<clock_observable> {

        void notify_impl(clock_observable& x) override {
            std::cout << ""clock_observer2 says time is "" << x.get_time() << std::endl;
        }
    };

    // our first account_observer
    class account_observer1
    : public observer_wrapper<account_observable> {

        void notify_impl(account_observable& x) override {
            std::cout << ""account_observer1 says balance is "" << x.get_balance() << std::endl;
        }
    };

    // our second account_observer
    class account_observer2
    : public observer_wrapper<account_observable> {

        void notify_impl(account_observable& x) override {
            std::cout << ""account_observer2 says balance is "" << x.get_balance() << std::endl;
        }
    };


    int main() {

        auto clock = new clock_observable(100);
        auto account = new account_observable(100.0);

        observer* clock_obs1 = new clock_observer1();
        observer* clock_obs2 = new clock_observer2();

        observer* account_obs1 = new account_observer1();
        observer* account_obs2 = new account_observer2();

        clock->registerObserver(clock_obs1);
        clock->registerObserver(clock_obs2);

        account->registerObserver(account_obs1);
        account->registerObserver(account_obs2);

        clock->change_time();
        account->deposit_amount(10);
    }