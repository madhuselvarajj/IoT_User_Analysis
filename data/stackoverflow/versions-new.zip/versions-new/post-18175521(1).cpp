    int Linuxutils::readFromSerialPort(int fd, int bufferSize)
    {
        if ( !checkFileDecriptorIsValid(fd) ) {
            fprintf(stderr, "Could not read from serial port - it is not a valid file descriptor!\n");
            return -1;
        }

        fcntl(fd, F_SETFL, 0); // block until data comes in
        int absoluteMax = bufferSize;
        char *buffer = malloc(bufferSize);
        int rcount = 0;
        int length = 0;

        // Read in each newline
        FILE* fdF = fdopen(fd, "r");
        int ch = getc(fdF);
        for (;;) {
            int ch = getc(fdF);
            if (ch == '\n') {
                break;
            }
            if (ch == EOF) { // Reached end of file
                printf("ERROR: EOF!\n");
                break;
            }
            if (length+1 >= absoluteMax) {
                absoluteMax *= 2;
                char* tmp = realloc(buffer, absoluteMax);
                if (tmp == NULL) {
                    printf("ERROR: OOM\n");
                    goto cleanup;
                }
                buffer = tmp;
            }
            buffer[length++] = ch;
        }

        if (length == 0) {
            return 0;
        }
        buffer[length] = '\0';

        // Print results
        printf("Received ( %d bytes ): %s\n", rcount,buffer);

    cleanup:
        free(buffer);
        fclose(fdH);
        return length;
    }
