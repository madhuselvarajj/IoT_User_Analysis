class SensorArray {
    sensor** arr;
    size_t count; 
   public:
    size_t size() const {
        return count; 
    }
    template<class T...>
    SensorArray(T&... sensors) {
       arr = new sensor*[] { &sensors... };
       count = sizeof...(sensors); 
    }

    sensor& operator[](int index) {
        return *arr[index];
    }
    ~SensorArray() {
         delete[] arr;
    }
};