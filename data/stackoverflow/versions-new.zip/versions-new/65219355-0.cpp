#include <iostream>
    void dump_str(const std::string&str)
    {
        int n;
        std::cout << std::hex;
    
        for (int i=0; i<str.size(); i++)
          {
              n = str[i];
              if (i%24==0) std::cout << std::endl;
                 else if (i%12 == 0 ) std::cout <<"  ";
              if (n<16) std::cout << " " << '0' << (int)str[i];
              else  std::cout << " " << (int)str[i];
           }
    }
    int main ()
    {
      std::string str ( "some\r\ttest\rst\2\athis is \n a ran\5dom\10g\n\nTake this for granted. To bo or not to be\a\a\t\t");
      dump_str(str);
    }