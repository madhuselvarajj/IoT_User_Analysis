 #include ""AES.h""
    #include ""Base64.h""
    
    AES aes;
    
    // Our AES key. Note that is the same that is used on the Node-Js side but as hex bytes.
    byte key[] = { 0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C };
    // The unitialized Initialization vector
    byte iv[N_BLOCK] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    
    // Our message to encrypt. Static for this example.
    String msg = ""{\""solution\"":\""hacker\"", \""stat\"":5 , \""msg\"":\""WORKS GREAT!\"" }"";
    
    uint8_t generate_random_unit8()
    {
      uint8_t really_random = *(volatile uint8_t *)0x3FF20E44;
      return really_random;
    }
    
    // Generate a random initialization vector
    void generate_iv(byte *vector)
    {
      for (int i = 0; i < N_BLOCK; i++)
      {
        vector[i] = (byte)generate_random_unit8();
      }
    }
    
    void encrypt()
    {
      char b64data[200];
      byte cipher[1000];
      byte iv[N_BLOCK];
    
      generate_iv(iv);
    
      base64_encode(b64data, (char *)iv, N_BLOCK);
      String IV_base64 = String(b64data);
      Serial.println("" IV b64: "" + IV_base64);
    
      int b64len = base64_encode(b64data, (char *)msg.c_str(), msg.length());
    
      Serial.println("" The lenght is:  "" + String(b64len));
    
      // Encrypt! With AES128, our key and IV, CBC and pkcs7 padding
      aes.do_aes_encrypt((byte *)b64data, b64len, cipher, key, 128, iv);
    
      Serial.println(""Cipher size: "" + String(aes.get_size()));
    
      base64_encode(b64data, (char *)cipher, aes.get_size());
      Serial.println(""Encrypted data in base64: "" + String(b64data));
    
      decrypt(b64data, IV_base64, aes.get_size());
    }
    
    void decrypt(String b64data, String IV_base64, int lsize)
    {
      char data_decoded[200];
      char iv_decoded[200];
      byte out[200];
      char temp[200];
      b64data.toCharArray(temp, 200);
      base64_decode(data_decoded, temp, b64data.length());
      IV_base64.toCharArray(temp, 200);
      base64_decode(iv_decoded, temp, IV_base64.length());
      aes.do_aes_decrypt((byte *)data_decoded, lsize, out, key, 128, (byte *)iv_decoded);
      char message[msg.length()];
      base64_decode(message, (char *)out, aes.get_size() - 5);
      printf(""Out %s \n"", message);
    }
    
    void setup_aes()
    {
      aes.set_key(key, sizeof(key)); // Get the globally defined key
    }
    
    void setup()
    {
      Serial.begin(115200);
    }
    
    void loop()
    {
      encrypt();
      delay(8000);
    }