    #include <stdio.h>
    #include <unistd.h>
    
    int main(int argc, char** argv)
    {
        int fd=STDIN_FILENO;
        int i,n;
        int c=0;
    
        char buff[300];
        memset(buff, 0, sizeof(buff));
        for (;;)
        {
            n=read(fd,buff,sizeof(buff));
            for (i=0; i<n; i++) 
            {
                switch(buff[i])
                {
                case '^':
                    if(c) 
                    {
                        // ^^ so output first ^
                        putchar('^');
                    }
                    else
                    {
                        // Possible ^M or ^J
                        c++;
                    }
                    break;
    
                case 'M':
                    if (c)
                    {
                        // ignore ^M
                        c=0;
                    }
                    else
                    {
                        // just M 
                        putchar(buff[i]);
                    }
                    break;
    
                case 'J':
                    if (c)
                    {
                        // ^J is \n
                        putchar('\n');
                        c=0;
                    }
                    else 
                    {
                        // just J
                        putchar(buff[i]);
                    }
                    break;
    
                default:
                    if (c)
                    {
                        // ^ followed by other than J or M
                        putchar('^');
                        c=0;
                    }
    
                    putchar(buff[i]);
                }
            }
    
        }
        return 0;
    }
