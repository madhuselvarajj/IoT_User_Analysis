#define updateEEPROMVal(address,val)  EEPROM.get(address,val_in_EEPROM); \
                                          if (val_in_EEPROM!=val)            \
                                            EEPROM.put(address,val)
    void storeGlobalXYValsIntoEEPROM()
    {
      uint16_t val_in_EEPROM;
     
      updateEEPROMVal(0,x_low);
      updateEEPROMVal(2,x_ctr);
      updateEEPROMVal(4,x_high);
      updateEEPROMVal(6,y_low);
      updateEEPROMVal(8,y_ctr);
      updateEEPROMVal(10,y_high);
    }