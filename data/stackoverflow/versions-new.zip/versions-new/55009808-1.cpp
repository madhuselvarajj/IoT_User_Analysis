    class i2cController
    {
    private:
      int foo;
    
    public:
      explicit i2cController(int Foo)
         foo(Foo) 
      {}
      void write(int value);
    };

    class Led
    {
    Led(Led&) = delete;
    Led& operator=(Led&) = delete;
    private:
      i2cController &controller;
      int pin;
    
    public:
      Led(int pin, i2cController &Controller);
      ~Led() noexcept;
      void turnOn();
    };
    
    Led::Led(int Pin, i2cController &Controller)
      controller(Controller),
      pin(Pin)
    {}
    Led::~Led() noexcept
    {}