// create your class
    class MyClass {
      public:
        int num;
        // assign a value to your member in a method
        MyClass(int number = 0){
          num = number;
        }
    };
    
    int main(){

      // create an instance of your class
      MyClass example(1);
      // access its member
      cout << example.num;
      return 0;
    }