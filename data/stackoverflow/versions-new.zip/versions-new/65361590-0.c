void loop() {
  static char buffer[12];
  static int colourArray[3];

  if (Serial.available() > 0) {
    Serial.readBytesUntil('\n', buffer, 12);
    int i = 0;
    char *p = strtok(buffer, ",");
    while (p) {
      colourArray[i++] = atoi(p);
      p = strtok(NULL, ",");
    }
    // You now have ints in colourArray[]; convert to uint8 if needed.
    Serial.println(colourArray[0]);
    Serial.println(colourArray[1]);
    Serial.println(colourArray[2]); 
  }
}