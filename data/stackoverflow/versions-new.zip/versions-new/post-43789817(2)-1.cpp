    #ifndef SHUTTER_H
    #define SHUTTER_H
    #include "Servo.h"
    
    class Shutter {
      public:
        Shutter(Servo *servo);
        Servo *getServo() const;
    
        void shut();
      private:
        Servo *_servo;        
    }
    
    #endif
