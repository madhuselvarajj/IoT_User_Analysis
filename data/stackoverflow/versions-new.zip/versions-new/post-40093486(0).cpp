    String words = "This is a sentence.";

    void setup() {
        Serial.begin(9600);
        // put your setup code here, to run once:
        println(words);
        char c;
        char no = " ";

        for (int i=0; i<words.length()-1;++i;){
            c = word.charAt(i);
            if(c==no){
                word.remove(i);
            }
        }

        println(words);
    }
