    class Led
    {
    private:
      i2cController &controller;
      int pin;
    
    public:
      Led(int pin, i2cController &Controller);
      void turnOn();
    };
    
    Led::Led(int Pin, i2cController &Controller)
      controller(Controller),
      pin(Pin)
    {
    }