    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <ctype.h>
    
    
    /*__________________________________________________________________________
    */
    
    struct DATA{
       char a;
       char b;
       char c;
       unsigned long d;
    };
    
    
    /*__________________________________________________________________________
    
      allocate DATA struct, and fill it.
      on error or no data, returns NULL
    */
    struct DATA *ParseString(char **pstr){
        int val=0;
        char *p;
        struct DATA *data;
        if(!pstr) return NULL;
    
        char *str=*pstr;
        if(!str) return NULL;
    
        // can be ommited
        // skipping non digital chars
        while(*str && !isdigit(*str))
            str++;
    
        //no digits?
        if(!*str) return NULL;
    
        p=str;
        //ok at least one
        data=(struct DATA*) calloc(1,sizeof(struct DATA));//calloc to initialize all to 0
        for(int n=0;n<4;n++){
            val=0;
            while(isdigit(*p)){
                val*=10;
                val+=(*p)-'0';
                p++;
            }
            switch(n){
                case 0:
                    data->a=val;
                    break;
                case 1:
                    data->b=val;
                    break;
                case 2:
                    data->c=val;
                    break;
                case 3:
                    data->d=val;
                    break;
            }
            val=0;
            if(*p!=',')
                break;
            p++;
    
        }
        *pstr=p;
        return data;
    }
    /*__________________________________________________________________________
    
        calculate the size of DATA * arra[c1][c2]
    */
    void countArrBoudaries(char *s,unsigned short *c1,unsigned short *c2){
        *c1=*c2=0;
        unsigned short _c1=0;
        while(*s){
            switch(*s){
                case ';':
                    _c1++;
                    break;
                case '.':
                    if(_c1>*c1)
                        *c1=_c1;
                    _c1=0;
                    *c2+=1;
                    break;
            }
            s++;
        }
    }
    /*__________________________________________________________________________
    */
    int main(void){
    
        struct DATA **pdata,*data;
        char buff[]="1,2,3,1445303228;4,5,6,1445303228;.7,8,9,1445303273;.";
        char *p=buff;
        unsigned short c1,c2;
        countArrBoudaries(buff,&c1,&c2);
        pdata=(struct DATA**)calloc((c2*c1),sizeof(pdata));
    
        if(pdata){
            // loading
            for(int i=0;i<c1;i++)
                for(int j=0;j<c2;j++)
                    pdata[i+(j*c1)]=ParseString(&p);
    
            // printing:
            for(int i=0;i<c1;i++)
                for(int j=0;j<c2;j++){
                    data=pdata[i+(j*c1)];
                    if(data){
                        printf("data[%u][%u]={%d,%d,%d,%u};\n",i,j,data->a,data->b,data->c,data->d);
                    }else{
                        printf("data[%u][%u]=NULL;\n",i,j);
                    }
                }
    
            // freeing memory:
            for(int i=0;i<(c1*c2);i++)
                free(pdata[i]);
            free(pdata);
    
        }
        printf("\n\nDONE\n\n");
        return 0;
    }
