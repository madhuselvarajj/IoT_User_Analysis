#include <iostream>
    
    class Object {
    public:
      Object(int number) : number{number} {}
      void print() { std::cout << ""The number is "" << number << std::endl; }
    
    private:
      const int number;
    };
    
    // -------------------------------------------------------------------------- //
    
    template <class T, size_t N> class ArrayWrapper {
    public:
        T &operator[](size_t index) { return data[index]; }
        const T &operator[](size_t index) const { return data[index]; }
        T *begin() { return &data[0]; }
        const T *begin() const { return &data[0]; }
        T *end() { return &data[N]; }
        const T *end() const { return &data[N]; }
    
      T data[N];
    };
    
    // -------------------------------------------------------------------------- //
    
    template <size_t N> class ManyObjects {
    public:
      ManyObjects(const ArrayWrapper<Object, N> &objects, const char *name)
          : objects{objects}, name{name} {}
      void print() {
        std::cout << name << std::endl;
        for (auto &object : objects)
          object.print();
      }
    
    private:
      ArrayWrapper<Object, N> objects;
      const char *name;
    };
    
    // -------------------------------------------------------------------------- //
    
    int main() {
        ManyObjects<3> many = {{1, 2, 3}, ""Many""};
        many.print();
    }