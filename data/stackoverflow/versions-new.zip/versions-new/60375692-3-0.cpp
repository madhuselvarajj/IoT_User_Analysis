template<typename T>
    struct ArrayView {
        T* ptr;
        std::size_t sz;
    public:
        template<int arrSize>
        ArrayView(T arr[inputSize]) : ptr(arr), sz(arrSize) { }

        T& operator[](int i) { return ptr[i]; }
    };