class SensorArray {
    sensor** arr;
    size_t count; 
   public:
    size_t size() const {
        return count; 
    }

    template<class T...>
    SensorArray(T&... sensors)
      : arr(new sensor*[] { &sensors... }) // Initialize arr
      , count(sizeof...(sensors))          // Initialize count
    {} // Constructor is empty because we already initialized stuff

    sensor& operator[](int index) const {
        return *arr[index];
    }

    ~SensorArray() {
         delete[] arr;
    }
};