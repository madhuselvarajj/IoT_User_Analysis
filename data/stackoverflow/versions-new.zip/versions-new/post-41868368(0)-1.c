        #include <stdio.h>
        #include <stdlib.h>
        #include <string.h>

        int main()
        {
            char nums[] = "140,100";
            char *str;
            int num;

            str = strtok (nums, ",");
            
            while (str != NULL)
            {
                num = atoi(str);
                printf ("%d\n", num);
                str = strtok (NULL, ",");
            }
            return 0;
        }
