typedef enum {
     START,  
     SET_VIB,
     CHECK_TEMP,
     GET_TIME,
     CLEANUP,
     SLEEP,
     MAX_STATE
    }STATE;
    
    int main(void)
    {
     
     STATE state = STATE_NULL;
     
     RunProcess(state);
      
     return 0;
    }

    int RunProcess(STATE state)
    {
     int duration = 2;
     time_t elapsed = 0 //s
     BOOL running = TRUE;
     
     while(running)
     switch (state) {
      case START:
       status = 0;
       state = SLEEP;
      case SET_VIB:
       if(duration == 2) 
       {
        duration = 5;
        //& turn off vibe
       }
       else
       {
        duration = 2;
        //& turn on vibe
          
       state = CHECK_TEMP;
      case CHECK_TEMP:
       //read temperature
       if(temp < setpoint) state = SLEEP;
       else state = CLEANUP;
      case GET_TIME:
          elapsed = getTime();
       if(elapsed > duration) state = SET_VIB;
      case CLEANUP:
       //turn off heat
       //turn off vibe
       status = 1;//normal 
       running = FALSE;
      case SLEEP:
          Sleep(someMsValue);
       state = GET_TIME;
      default:
     }
     return status;
    }