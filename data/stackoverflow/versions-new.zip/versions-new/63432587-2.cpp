 struct Temperature{
      uint8_t temp[7];
      uint8_t humi[7];
      Temperature(){temp[0] = humi[0] ='\0';}
      Temperature(uint8_t * t, uint8_t *h){strcpy(temp,t); strcpy(humi,h);}
      void reset(){ temp[0] = humi[0] ='\0';}  
      void setTemp(uint8_t* t){strcpy(temp,t);}
      void setHum(uint8_t* h){strcpy(humi,h);}
      void print(){ char str[16]; sprintf(str,"Temp=%4.2f Hum=%4.2f", atof(temp), atof(humi)); Serial.println(str);}
      void operator=(Temperature other){ strcpy(temp,other.temp); strcpy(humi,other.humi);}
    };    
  
    void loop() {
      Temperature temp1;
      temp1.reset();
      temp1.setTemp("52.34");
      temp1.setHum("30");
      Temperature temp2;
      temp2 = temp1;
      temp2.print();
    }