#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include <cstdint>

/* define led pins here */
int pins[] = {2, 3 , 4, 5};

void turn_led_on(int led)
{
    digitalWrite(pins[led], HIGH);        
}

void turn_led_off(int led)
{
    digitalWrite(pins[led], LOW);
}

void display_number(int number)
{
    int num_of_leds = sizeof(pins) / sizeof(int);
    
    printf("The number is: %d\n", number);
        
    uint8_t led_mask = (1 << num_of_leds) - 1;
    
    int masked_number = number & led_mask;
    
    for (int i = 0; i < num_of_leds; i++) {
        if (masked_number & (1 << i)) {
            turn_led_on(i);
        } else {
            turn_led_off(i);
        }
    }
}

void initialize_leds()
{
    int num_of_leds = sizeof(pins) / sizeof(int);
    
    for (int i = 0; i < num_of_leds; i++) {
        pinMode(pins[i], OUTPUT);
        turn_led_off(pins[i]);
    }
}

int main(int argc, char *argv[])
{
    int number;
 
    wiringPiSetup();
    
    initialize_leds(); 

    printf("Please select a number to display!\n");

    scanf("%i", &number);
    
    display_number(number);
    
    return 0;
}