void setup()
{
    Serial.begin(9600);
    pinMode(BUTTON_SWITCH, INPUT_PULLUP);
    pinMode(BUTTON_ALARM, INPUT_PULLUP);
    pinMode(RED_LED, OUTPUT);
}

void loop()
{
    // If BUTTON_ALARM pressed, enable alarm
    if (digitalRead(BUTTON_ALARM) == LOW) {
        displayAlarm();
    }

    // Check if there is data in the serial port input buffer
    // If there is and it is ""RESET"", disable the alarm
    if (Serial.available()) {
        // Read entire buffer up to newline character
        // Since on the C# side, serialPort1.WriteLine appends a newline character
        String respond =Serial.readStringUntil('\n');
        if (respond == ""RESET"") {
            digitalWrite(RED_LED, LOW);
            digitalWrite(BUZZER, LOW);
        }
    }
}

void displayAlarm()
{
    digitalWrite(RED_LED, HIGH);
    tone(BUZZER, 1500, 700);
}