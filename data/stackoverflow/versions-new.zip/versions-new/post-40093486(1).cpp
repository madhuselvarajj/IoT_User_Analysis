    void setup() {
        // put your setup code here, to run once:
        Serial.begin(9600);
    }

    void loop() {
        // put your main code here, to run repeatedly:
        String words = "This is a sentence."; //reassign same string at the start of loop.
        delay(1000);
        println(words);
        char c;
        char no = " "; //character I want removed.

        for (int i=0; i<words.length()-1;++i;){
            c = word.charAt(i);
            if(c==no){
                word.remove(i, 1);
            }
        }
        println(words);
        delay(5000);//5 second delay, for demo purposes.
    }
