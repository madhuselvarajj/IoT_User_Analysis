class MidiHandler
    {
    public:
        MidiHandler(HardwareSerial& serial_port)
            : midiA(serial_port)
        { }
    
    private:
        midi::MidiInterface<HardwareSerial> midiA;
    };