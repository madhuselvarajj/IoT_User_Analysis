    #include <iostream>
    #include <fstream>
    
    int main() {
      std::ofstream out_file("out.bin", std::ofstream::binary);
      int received_from_socket = 3000;
      out_file.write((const char *) &received_from_socket, sizeof(int));
      out_file.close();
      
      std::ifstream in_file("out.bin", std::ifstream::binary);
      int number_from_file = -1;
      in_file.read((char *) &number_from_file, sizeof(int));
      std::cout << number_from_file << std::endl;
      return 0;
    }
