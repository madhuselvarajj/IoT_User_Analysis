class DeviceWithShiftReference: public Device{

        private ShiftRegister * myShiftReference;
    
        public DeviceWithShiftReference(ShiftRegister* reg) {
            myShiftReference = reg
        }

        public doSomething() {
            // here you can perform stuff with the shift register inside your device 
        }
    };

    void main(void){
        ShiftRegister myRegister;
        DeviceWithShiftReference myDevice(&myRegister);
        myDevice.doSomething();
    }