    #ifndef Shutter
    #define Shutter
    #include "Servo.h"
    
    class Shutter {
      public:
        Shutter(Servo *servo);
        Servo *getServo() const;
    
        void shut();
      private:
        Servo *_servo;        
    }
    
    #endif
