    #include <unistd.h> // for read & write functions
    #include <sys/select.h> // fd_set functions
    #include <stdio.h> // for perror & printf family
    #include <sys/types.h> // for open related function
    #include <sys/stat.h> // for open related function
    #include <fcntl.h> // for open related function
    #include <termios.h> // for terminal functions
    #include <errno.h> // for error code
