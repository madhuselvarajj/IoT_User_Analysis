void loop()
{
    if (digitalRead(BUTTON_ALARM) == LOW) {
        digitalWrite(RED_LED, HIGH);
        digitalWrite(BUZZER, HIGH);
    }

    // Check if there is data in the serial port input buffer
    if (Serial.available()) {
        // Read entire buffer up to newline character
        // Since on the C# side, serialPort1.WriteLine appends a newline character
        String respond = serialPort1.readStringUntil('\n');
        if (respond == ""RESET"") {
            digitalWrite(RED_LED, LOW);
            digitalWrite(BUZZER, LOW);
        }
    }
}