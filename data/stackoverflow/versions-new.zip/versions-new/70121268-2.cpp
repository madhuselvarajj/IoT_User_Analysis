#include <stdbool.h>
    #include <assert.h>
    
    static bool is_setup; /* Optimized away in production with -D NDEBUG */
    
    static void setup_function(void) {
     assert(!is_setup && (is_setup = 1));
    }
    
    static bool operations(void) {
     assert(is_setup);
     return true;
    }
    
    int main(void) {
     //setup_function(); // Triggers `assert` if omitted.
     operations();
     return 0;
    }