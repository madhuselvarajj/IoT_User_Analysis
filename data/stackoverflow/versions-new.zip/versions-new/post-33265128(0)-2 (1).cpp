    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    
    /*__________________________________________________________________________
    */
    
    typedef struct {
       char a;
       char b;
       char c;
       unsigned long d;
    }DATA;
    /*__________________________________________________________________________
    */
    
    int countNbItems(const char *p){
        int nb=0;
        while(*p){
            if(*p==';')nb++;
            p++;
        }
        return nb;
    }
    /*__________________________________________________________________________
    */
    
    int main(void){
        int nb=0,i=0,n=0;
        DATA *data;
        char buff[]="1,2,3,1445303228;4,5,6,1445303228;.7,8,9,1445303273;.";
        char *p=buff,*pp=buff;
    
        nb=countNbItems(buff);
        data=calloc(nb,sizeof(DATA));
    
        while(*p){
            if(*p==','){
                *p=0;// null terminate string
                switch(n){
                    case 0:
                        data[i].a=atoi(pp);
                        break;
                    case 1:
                        data[i].b=atoi(pp);
                        break;
                    case 2:
                        data[i].c=atoi(pp);
                        break;
                    default:
                        printf("Error: missing(\";\")\n");
                        exit(1);
                   }
                n++;
                *p=','; // restore it back
                pp=&p[1];// pp point to next char
            }
            else if(*p==';'){
                *p=0;// null terminate string
                sscanf(pp,"%u", &(data[i].d));
                *p=';';// restore it back
                pp=&p[1]; // pp point to next char
    
                i++; /*newt item*/
                n=0;/*reset fileds*/
                
            }
            else if(*p=='.'){
                /*points will be ignored*/
                pp=&p[1]; // pp point to next char
            }
            p++;
        }
    
        for(int i=0;i<nb;i++){
            printf("%d,%d,%d,%u;",data[i].a,data[i].b,data[i].c,data[i].d);
        }
        
        free(data);
        printf("\n\n\n");
        
        return 0;
    }
