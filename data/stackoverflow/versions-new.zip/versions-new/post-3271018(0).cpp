char *
int2str( int num ) {
  static char retnum[11];  // for 32-bit int, allow 10 digits plus NUL
  sprintf( retnum, "%d", num );
  return retnum;
}
