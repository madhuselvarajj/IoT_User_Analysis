 #include <iostream>
    
    // ------------------------------- TYPE_TRAITS ------------------------------ //
    
    template <class _Tp, _Tp v> struct integral_constant {
      static constexpr _Tp value = v;
      typedef _Tp value_type;
      typedef integral_constant type;
      constexpr operator value_type() const { return value; }
    };
    
    typedef integral_constant<bool, true> true_type;
    typedef integral_constant<bool, false> false_type;
    
    template <bool, class Tp = void> struct enable_if {};
    template <class Tp> struct enable_if<true, Tp> { typedef Tp type; };
    template <class Tp, class Up> struct is_same : public false_type {};
    template <class Tp> struct is_same<Tp, Tp> : public true_type {};
    template <class Tp> struct remove_reference { typedef Tp type; };
    template <class Tp> struct remove_reference<Tp &> { typedef Tp type; };
    
    // -------------------------------------------------------------------------- //
    
    class Object {
    public:
      Object(int number) : number{number} {}
      void print() { std::cout << ""The number is "" << number << std::endl; }
    
    private:
      const int number;
    };
    
    // -------------------------------------------------------------------------- //
    
    template <class T, size_t N> class ArrayWrapper {
    public:
      template <
          typename Arg, typename... Args,
          typename = typename enable_if<!(
              sizeof...(Args) == 0 && is_same<typename remove_reference<Arg>::type,
                                              ArrayWrapper>::value)>::type>
      ArrayWrapper(Arg arg, Args &&... arguments) : data{arg, arguments...} {}
      T &operator[](size_t index) { return data[index]; }
      T *begin() { return &data[0]; }
      T *end() { return &data[N]; }
    
    private:
      T data[N];
    };
    
    // -------------------------------------------------------------------------- //
    
    template <size_t N> class ManyObjects {
    public:
      ManyObjects(const ArrayWrapper<Object, N> &objects, const char *name)
          : objects{objects}, name{name} {}
      void print() {
        std::cout << name << std::endl;
        for (auto &object : objects)
          object.print();
      }
    
    private:
      ArrayWrapper<Object, N> objects;
      const char *name;
    };
    
    // -------------------------------------------------------------------------- //
    
    int main() {
        ManyObjects<3> many = {{1, 2, 3}, ""Many""};
        many.print();
    }