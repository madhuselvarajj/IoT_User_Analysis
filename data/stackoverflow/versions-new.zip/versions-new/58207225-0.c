void step_state(enum events event) {
        switch(state) {
        case START:
            switch(event) {
            case START_LOOPING:
                state = LOOP;
                break;
            default:
                exit(1);
                break;
            }       
            break;
        case LOOP:
            switch(event) {
            case PRINT_HELLO:
                printf(""Hello World!\n"");
                break;
            case STOP_LOOPING:
                state = END;
                break;
            default:
                exit(1);
                break;
            }
            break;
        case END:
            exit(1);
            break;
        }
    }