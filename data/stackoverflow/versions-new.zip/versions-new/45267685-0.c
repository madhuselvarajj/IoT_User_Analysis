class MidiHandler
    {
        MidiHandler(HardwareSerial& serial_port)
            : midiA(serial_port)
        { }

        midi::MidiInterface<HardwareSerial)> midiA;
    }