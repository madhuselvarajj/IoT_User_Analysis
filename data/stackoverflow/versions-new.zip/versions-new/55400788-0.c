const int redPin = 3;
    const byte numChars = 32;
    char receivedChars[numChars];
    char tempChars[numChars];        // temporary array for use when parsing
    
          // variables to hold the parsed data
    boolean newData = false;
    
    int InitVal = 0; // change to init value or red
    int red = 0;
    
    void setup() {
      // initialize serial:
      Serial.begin(9600);
      // make the pins outputs:
      pinMode(redPin, OUTPUT);
    
    }
    
    void loop() {
        recvWithStartEndMarkers();
        if (newData == true) {
            strcpy(tempChars, receivedChars);
                // this temporary copy is necessary to protect the original data
                //   because strtok() used in parseData() replaces the commas with \0
            parseData();
            One();
            newData = false;
        }
        else {
          Zero();
          
        }
    }
    
    
     ///////////////////// ///////////////////// /////////////////////
    void recvWithStartEndMarkers() {
        static boolean recvInProgress = false;
        static byte ndx = 0;
        char startMarker = '<';
        char endMarker = '>';
        char rc;
    
        while (Serial.available() > 0 && newData == false) {
            rc = Serial.read();
    
            if (recvInProgress == true) {
                if (rc != endMarker) {
                    receivedChars[ndx] = rc;
                    ndx++;
                    if (ndx >= numChars) {
                        ndx = numChars - 1;
                    }
                }
                else {
                    receivedChars[ndx] = '\0'; // terminate the string
                    recvInProgress = false;
                    ndx = 0;
                    newData = true;
                }
            }
    
            else if (rc == startMarker) {
                recvInProgress = true;
            }
        }
    }
    
     ///////////////////// ///////////////////// /////////////////////
    
    void parseData() {      // split the data into its parts
    
        char * strtokIndx; // this is used by strtok() as an index
    
        strtokIndx = strtok(tempChars,"","");      // get the first part - the string
        InitVal = atoi(strtokIndx); // copy it to messageFromPC
     
        strtokIndx = strtok(NULL, "",""); // this continues where the previous call left off
        red = atoi(strtokIndx);     // convert this part to an integer
    
    }
    
    
     ///////////////////// ///////////////////// /////////////////////
    void One() {
      
      if (InitVal == 0){
        
        delay(20);
        Serial.println(red);
        delay(20);
      }      
     }
     ///////////////////// ///////////////////// /////////////////////
    void Zero() {
      
      if (InitVal == 1){
        
        delay(20);
        Serial.println(0);
        delay(20);
      }      
     }
