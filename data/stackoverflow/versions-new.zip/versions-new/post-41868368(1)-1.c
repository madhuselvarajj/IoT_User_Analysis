        #include <stdio.h>
        #include <stdlib.h>
        #include <string.h>

        int main()
        {
            char nums[] = "140,100";
            char *str;
            int num;
            int SpeedX, SpeedY, i = 0;

            str = strtok (nums, ",");

            while (str != NULL)
            {
                num = atoi(str);
                if (i == 0)
                   SpeedX = num;
                else if (i == 1)
                   SpeedY = num;
                str = strtok (NULL, ",");
                i++;
            }
            return 0;
        }
