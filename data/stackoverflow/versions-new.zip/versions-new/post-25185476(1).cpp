    #define WIDTH 10
    #define HEIGHT 12
    
    #include <stdint.h>
    
    uint8_t arr1[WIDTH][HEIGHT];
    uint8_t arr2[WIDTH][HEIGHT];
    uint8_t (*currState)[WIDTH][HEIGHT];
    uint8_t (*nextState)[WIDTH][HEIGHT];
    
    void copyArray(uint8_t ar1[WIDTH][HEIGHT], uint8_t ar2[WIDTH][HEIGHT]) {
        uint8_t i,j;
        for (i=0; i<WIDTH; i++) {
            for (j=0; j<HEIGHT; j++) {
                ar1[i][j] = ar2[i][j];
            }
        }
    }
    
    int main(void) {
        currState = &arr1;
        nextState = &arr2;
        
        uint8_t tempState[WIDTH][HEIGHT];
        
        copyArray(tempState, *currState);
        currState = nextState;
        nextState = &tempState;
        
        return 0;
    }
