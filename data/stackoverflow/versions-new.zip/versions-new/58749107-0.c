// Read entire buffer up to newline character
// Since on the C# side, serialPort1.WriteLine appends a newline character
String respond = serialPort1.readStringUntil('\n');
if (respond == "RESET") {
    digitalWrite(RED_LED, LOW);
    digitalWrite(BUZZER, LOW);
}