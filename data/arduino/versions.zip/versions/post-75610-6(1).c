// Iniciamos los pins de los 4 leds
const int Red = 4;
const int Blue = 5;
const int Green = 6;
const int White = 7;

// Creamos el boton que limpia pantalla
const int buttonClear = 10;

char rc;
const int maxChar = 6;
static byte charCount = 0;
char leds2[7] = {'\0'};
bool newData = false;

#define DEBUG_INTERFACE Serial
#define receiver Serial

void setup() {
  receiver.begin(9600);
  pinMode(Red, OUTPUT);
  pinMode(Blue, OUTPUT);
  pinMode(Green, OUTPUT);
  pinMode(White, OUTPUT);

  DEBUG_INTERFACE.begin(9600);
  DEBUG_INTERFACE.println("DEBUG ON");
}

void loop() {
  receiveStartEndMarkers();
  if (newData) {
    DEBUG_INTERFACE.print(" LED Array received: ");
    DEBUG_INTERFACE.println(leds2);
    lightLeds(leds2);
    newData = false;
  }
}

void lightLeds(char A[]) {
  for (int i = 0; i < 6; i++) {
    if (A[1] == '1' || A[1] == 1) digitalWrite(Red, HIGH);
    if (A[2] == '1' || A[2] == 1) digitalWrite(Blue, HIGH);
    if (A[3] == '1' || A[3] == 1) digitalWrite(Green, HIGH);
    if (A[4] == '1' || A[4] == 1) digitalWrite(White, HIGH);
    if (A[1] == '0' || A[1] == 0) digitalWrite(Red, LOW);
    if (A[2] == '0' || A[2] == 0) digitalWrite(Blue, LOW);
    if (A[3] == '0' || A[3] == 0) digitalWrite(Green, LOW);
    if (A[4] == '0' || A[4] == 0) digitalWrite(White, LOW);
  }
  DEBUG_INTERFACE.print(A); DEBUG_INTERFACE.println(" Leds switched");
}

void receiveStartEndMarkers() {
  static boolean recvInProgress = false;
  char startMarker = 'H';
  char endMarker = 'F';

  if (receiver.available() > 0) {
    rc = receiver.read();
    //DEBUG_INTERFACE.print(rc);
    if (recvInProgress) {
      if (rc != endMarker) {
        leds2[charCount] = rc;
        charCount++;
        if (charCount > maxChar) {
          charCount = maxChar;
        }
      }
      else {
        leds2[charCount] = rc;
        charCount++;
        leds2[charCount] = '\0'; // terminate the string
        recvInProgress = false;
        charCount = 0;
        newData = true;
      }
    }
    else if (rc == startMarker) {
      recvInProgress = true;
      leds2[charCount] = rc;
      charCount++;
    }
  }
}
