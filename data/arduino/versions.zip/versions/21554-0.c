//  A little fakery to make the OP code look closer

    HardwareSerial & client = Serial; // redirect 'client' to the Serial Monitor
    const bool WL_CONNECTED = true;
    const bool WL_DISCONNECTED = false;
    bool status = WL_CONNECTED;

    bool hueOn;
    uint16_t hueBri, hueHue;

    //---------------------------------------------------------------------
    // Utility function to extract one `bool` value from the client stream.
    //   No buffers are used.  Each character is handled as it is received.
    //   (you may want/need to add a timeout)

    static bool clientParseBool( char delim )
    {
      bool val = false;
      uint8_t count = 0; // number of chars we've read for the value

      while (status == WL_CONNECTED) {

        if (client.available()) {
          char c = client.read();

          if (c == delim)
            break; // done!

          // skip spaces and anything after the first non-space char
          if ((c == ' ') || (count++ > 0))
            continue;

          if (c == 't')
            val = true;
        }
      }

      // debug prints
      Serial.print( F("bool ") );
      Serial.println( val );

      return val;
    }

    //---------------------------------------------------------------------
    // Utility function to extract one 'unsigned 16-bit int' value from the client stream.
    //   No buffers are used.  Each character is handled as it is received.
    //   (you may want/need to add a timeout)

    static uint16_t clientParseUint( char delim )
    {
      uint16_t val = 0;
      
      while (status == WL_CONNECTED) {

        if (client.available()) {
          char c = client.read();

          if (c == delim)
            break; // done!

          if (c == ' ')
            continue; // skip spaces

          if (isdigit(c))
            val = val*10 + (c - '0'); // accumulate one digit of the bri value
        }
      }

      // debug prints
      Serial.print( F("int ") );
      Serial.println( val );

      return val;
    }

    //-------------------------------------------

    boolean getHue(int lightNum)
    {
        bool gotHue = false;

        client.println(F("Content-type: application/json"));
        client.println(F("keep-alive"));
        client.println();

        if (status == WL_CONNECTED)
        {
            client.findUntil("\"on\":", "\0");
            hueOn = clientParseBool(',');

            if (status == WL_CONNECTED)
            {
                client.findUntil("\"hue\":", "\0");
                hueHue = clientParseUint(',');

                if (status == WL_CONNECTED)
                {
                  client.findUntil("\"bri\":", "\0");
                  hueBri = clientParseUint(',');
                  
                  gotHue = true;  // captured all three: on,bri,hue
                }
            }
        }

        client.flush();
    //  client.stop(); not for faked Serial  :)

        return gotHue;
    }

    void setup()
    {
      Serial.begin( 9600 );
      while (!Serial)
        ;
    }

    void loop()
    {
      setHue
        ( 1,
          F("{\"on\": true,\"hue\": 50100,\"sat\":255,\"bri\":255,\"transitiontime\":"),
          random(15,25),
          F("}") );
          
      getHue( 1 );
      
      delay( 2000 );
    }