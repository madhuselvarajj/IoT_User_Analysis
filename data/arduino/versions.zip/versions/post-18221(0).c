static   byte rcOld;  // Prev. states of inputs
volatile unsigned long rcRises; // times of prev. rising edges
volatile unsigned long rcTimes; // recent pulse lengths

// Be sure to call setup_rcTiming() from setup()
void setup_rcTiming() {
  rcOld = 0;
  pinMode(A0, INPUT);  // pin 14, A0, PC0, for pin-change interrupt
  pinMode(A1, INPUT);  // pin 15, A1, PC1, for pin-change interrupt
  pinMode(A2, INPUT);
  pinMode(A3, INPUT);
  PCMSK1 |= 0x0F;  // Four-bit mask for four channels
  PCIFR  |= 0x02;  // clear pin-change interrupts if any
  PCICR  |= 0x02;  // enable pin-change interrupts
}
// Define the service routine for PCI vector 1
ISR(PCINT1_vect) {
  byte rcNew = PINC & 15; // Get low 4 bits, A0-A3
  byte changes = rcNew^rcOld; // Notice changed bits
  byte channel = 0;
  unsigned long now = micros(); // micros() is ok in int routine
  while (changes) {
    if ((changes & 1)) {  // Did current channel change?
      if ((rcNew & (1<<channel))) { // Check rising edge
        rcRises[channel] = now;     // Is rising edge
      } else {       // Is falling edge
        rcTimes[channel] = now-rcRises[channel];
      }
    }
    changes >>= 1;  // shift out the done bit
    ++channel;
  }
  rcOld = rcNew;  // Save new state
}
