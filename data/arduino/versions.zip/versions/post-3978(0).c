#include <SoftwareSerial.h>

SoftwareSerial mySerial(10, 11); // RX, TX

char buffer[16];
#define buffer_size sizeof(buffer)/sizeof(buffer[0])
int8_t buffer_pos = 0;

void setup() {
  //Initialize serial and wait for port to open:
  Serial.begin(9600);
  while (!Serial) {
    ; // wait for serial port to connect. Needed for Leonardo only
  }
  Serial.println(""Serial to mySerial demo started"");

  buffer_pos = 0;
}

void loop() {
  char inByte;
  while (mySerial.available()) {
    inByte = mySerial.read();
    while (buffer_pos >= buffer_size) {
      for (int8_t i = 0; i < buffer_size - 1; i++) { // if shift buff left if at end of buff
        buffer[i] = buffer[i + 1];
      }
    }
    buffer[buffer_pos++] = inByte;
    if (strcmp(buffer, ""track"")) {
      buffer_pos = 0;
      Serial.println(""TRACK FOUND!"");
    } else {
      Serial.write(inByte);
    }
  }

}
