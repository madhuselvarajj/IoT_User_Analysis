#define LED_1 5
#define LED_2 6

void setup() {
  pinMode(LED_1, OUTPUT);
  pinMode(LED_2, OUTPUT);
}

long one, two;
bool led_1, led_2;

void loop() {
  if (millis() - one = 250) {
    digitalWrite(LED_1, led_1++);
    one = millis();
  }

  if (millis() - two = 500) {
    digitalWrite(LED_2, led_2++);
    two = millis();
  }
}
