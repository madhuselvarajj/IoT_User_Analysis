#include <SPI.h>
#include <Wire.h>
#include "U8glib.h"  //Library for display

U8GLIB_SH1106_128X64 u8g(U8G_I2C_OPT_NONE);  // I2C interface for OLED

int index = 0; //size of array
const int number_of_readings = 200; //total number of readings arduino takes before it averages
const int current_zero = 510; //initial value of current from arduino with 0 amps
int current_reading[number_of_readings]; //create array for current_reading
int voltage_reading[number_of_readings]; //create array for voltage_reading

float R1=30000; //resistance of R1 in voltage sensor
float R2=7500; //resistance of R2 in voltage sensor
float current_average = current_zero; //initial value of current average
float current_total = 0; //initial value of current_total
float voltage_average = 0; //initial value of voltage_average
float voltage_total = 0; //initial value of voltage_total
float voltage = 0.0,current_mV = 0.0,current = 0.0,power = 0.0;

int x = 0;
int row = 0;
float voltage = 0.1;



  void setup() {
   Serial.begin(9600);
   pinMode(A4,INPUT_PULLUP);
   pinMode(A5, INPUT_PULLUP);
  }


  void draw(void) {
   u8g.setFont(u8g_font_fub14r);
   u8g.drawStr(0, 20, "V: ");
   u8g.drawStr(0, 40, "A: ");
   u8g.drawStr(0, 60, "Watt: ");
   u8g.setPrintPos(58,20);
   u8g.print( voltage,2);
   u8g.println("V");
   u8g.setPrintPos(58,40);
   u8g.print( current,0);
   u8g.println("mA");
   u8g.setPrintPos(58, 60);
   u8g.print( power ,1);
}


 void loop() {
  voltage_reading[index]=analogRead(A0); //read voltage reading from pin A0 (value 0-1023)
  voltage_total = voltage_total + voltage_reading[index]; //add voltage to voltage_total
  current_reading[index]=analogRead(A3); //read current reading from pin A3 (value 0-1023)
  current_total = current_total + current_reading[index]; // add current to current_total
  index = index + 1;

  if (index >=number_of_readings) { //once you have read number_of_reading, create average value of all readings taken
    current_average=current_total/number_of_readings;
    voltage_average=voltage_total/number_of_readings;
    Serial.print("Current average=");
    Serial.print(current_average);
    Serial.print("   Voltage average=");
    Serial.println(voltage_average);
    current_total=0;
    voltage_total=0;
    index=0;

  }


  voltage = ((5*(voltage_average)*(R1+R2))/(1023*R2)); //convert unit value of voltage_average (0-1023) to actual voltage, substract voltage average value when not voltage should be read
  current_mV = (current_average-current_zero)*5; //convert unit value of current_average(0-1023) to mV reading, substract surrent_average value when no current should be read
  current = current_mV/185; //sensor is rated for 185mV/amp according to pdf, may need to change depending on calibration
  power = (voltage*current); //calculate power


 u8g.firstPage();
  do {
    draw();
  } while( u8g.nextPage() );


}
