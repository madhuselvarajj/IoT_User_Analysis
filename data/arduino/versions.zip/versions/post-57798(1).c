// include the library code:
#include <SPI.h>

// Set Constants
const int adcChipSelectPin = 8;      // set pin 8 as the chip select for the ADC:

// Start setup function:
void setup() {
 pinMode (adcChipSelectPin, OUTPUT);

 // set the ChipSelectPins high initially:
 digitalWrite(adcChipSelectPin, HIGH);

 // initialise SPI:
 SPI.begin();
 SPI.setBitOrder(MSBFIRST);         // Not strictly needed but just to be sure.
 SPI.setDataMode(SPI_MODE0);        // Not strictly needed but just to be sure.
 Serial.begin(9600);

 //Clock Speed: Master clock/divider
 //84Mhz/64 =  1.3 MHz
 SPI.setClockDivider(SPI_CLOCK_DIV64);

 //Send dummy values over when ADC is turned on
 //Hold Din High for 16 clock cycles twice
 digitalWrite(adcChipSelectPin, LOW);
 SPI.transfer(0xFF);
 SPI.transfer(0xFF);
 digitalWrite(adcChipSelectPin, HIGH);

 digitalWrite(adcChipSelectPin, LOW);
 SPI.transfer(0xFF);
 SPI.transfer(0xFF);
 digitalWrite(adcChipSelectPin, HIGH);
 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
 //Send dummy values, next read should have correct values

 digitalWrite(adcChipSelectPin, LOW);
 byte FirstByte = 0x83;
 byte SecondByte = 0x50;
 byte response1 = SPI.transfer(FirstByte);
 byte response2 = SPI.transfer(SecondByte);

 digitalWrite(adcChipSelectPin, HIGH);

 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
 ///////////////////////////////////////////////////////////////////////////////////

 //50ns quiet time?
 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
 asm volatile("nop");
} // End setup function.

// Start loop function:
void loop() {
 float voltage[2];
 for (int i = 1; i < 17; i++) {
  voltage[i] = readAdc(0, 1);
  //50ns quiet time?
  asm volatile("nop");
  asm volatile("nop");
  asm volatile("nop");
  asm volatile("nop");
  asm volatile("nop");
 }
} // End of loop function.

//Function to read the ADC, accepts the channel to be read.
float readAdc(int channel, int slave) {
 float value;
 if (slave == 0) {
  byte FirstByte = 0x83;
  byte SecondByte = 0x50;
  FirstByte |= channel << 2;

  noInterrupts(); // disable interupts to prepare to send address data to the ADC.
  
  digitalWrite(adcChipSelectPin, LOW); // take the Chip Select pin low to select the ADC.
  //Write = 1
  //SEQ = 0
  // ADD3-ADD0 = 0000
  //PM1 = PM0 = 1
  //Shadow = 0
  //WEAK/Tri = 1
  //Range = 0
  //Coding = 1
  //0b10000010 1010 0000
  //extra 4 zeros to fill

  //May need to wait 16 * (1/freq)
  //16 * (1/1.3MHz)
  byte response1 = SPI.transfer(FirstByte);
  byte response2 = SPI.transfer(SecondByte);
  digitalWrite(adcChipSelectPin, HIGH);

  interrupts(); // Enable interupts.

  //Serial.println(response1);
  Serial.println(response2);
  byte channel = (response1 >> 4);
  //byte value = (response1 << 4);
  //byte digitalValue = (response1 << 4) | response2;
  //Serial.println(digitalValue);
  //Serial.println(channel);

  byte digitalValue = 0x00;
  float value = (float(digitalValue) * 3.3) / 4096.000; // The digital value is
  converted to an analogue voltage using a VREF of 2.048V.
  //Serial.print(channel);
  //Serial.print("\t");
  //Serial.println(value);
 }
}
