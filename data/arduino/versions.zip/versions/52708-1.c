    #include <Arduino.h>
    #include <Adafruit_CC3000.h>
    #include <SPI.h>
    #include ""utility/debug.h""
    #include ""utility/socket.h""
    #include <HttpClient.h>
    
    #define ADAFRUIT_CC3000_IRQ   3
    #define ADAFRUIT_CC3000_VBAT  5
    #define ADAFRUIT_CC3000_CS    10
    Adafruit_CC3000 cc3000 = Adafruit_CC3000(ADAFRUIT_CC3000_CS,    ADAFRUIT_CC3000_IRQ, ADAFRUIT_CC3000_VBAT,SPI_CLOCK_DIVIDER);
    /* Create new Adafruit_CC3000_Client object */
    Adafruit_CC3000_Client cc3000_client;
    /* Feed this into the client */
    HttpClient client (cc3000_client, ""dweet.io"", 80);
    
    #define WLAN_SSID       ""ssid""
    #define WLAN_PASS       ""pwd""
    #define WLAN_SECURITY   WLAN_SEC_WPA2
    
    int statusCode = 0;
    String response;
    
    void setConnection(){
    
     Serial.println(""Initializing..."");
     if (!cc3000.begin())
     {
      Serial.println(""Couldn't begin()! Check your wiring?"");
      while(1);
     }
     Serial.print(""Attempting to connect to "");
     Serial.println(WLAN_SSID);
     if (!cc3000.connectToAP(WLAN_SSID, WLAN_PASS, WLAN_SECURITY)) {
      Serial.println(""Failed!"");
      while(1);
     }
     Serial.println(""Connected!"");
     Serial.println(F(""Request DHCP""));
     while (!cc3000.checkDHCP())
     {
      delay(100);
     }
     Serial.println(F(""DHCP success!!""));
    }
    
    void dweet(){
    
     int ctr=0;
     char buff[100];
     int x=0;
     const char* host = ""https://dweet.io/get/latest/dweet/for/dunebot"";
    
     Serial.println(F(""Initializing dweet client ...""));
    
     client.get(host);
     Serial.println(F(""Client Connected !""));
    
     // read the status code and body of the response
     statusCode = client.responseStatusCode();
     response = client.responseBody();
     Serial.print(""Status code: "");
     Serial.println(statusCode);
     Serial.print(""Response: "");
     Serial.println(response);
    
     /*
     Typical response is:
     {""this"":""succeeded"",
     ""by"":""getting"",
     ""the"":""dweets"",
     ""with"":[{""thing"":""my-thing-name"",
       ""created"":""2016-02-16T05:10:36.589Z"",
       ""content"":{""sensorValue"":456}}]}
     You want ""content"": numberValue
     */
     // now parse the response looking for ""content"":
     int labelStart = response.indexOf(""content\"":"");
     // find the first { after ""content"":
     int contentStart = response.indexOf(""{"", labelStart);
     // find the following } and get what's between the braces:
     int contentEnd = response.indexOf(""}"", labelStart);
     String content = response.substring(contentStart + 1, contentEnd);
     Serial.println(content);
    
     //There was a missing brace here. Was the code cut off?!
    }
    
    void setup(){
     Serial.begin(115200);
     while(!Serial);
     Serial.print(""Free RAM: ""); Serial.println(getFreeRam(), DEC);
     setConnection();
    }
    
    void loop() {
     dweet();
    }