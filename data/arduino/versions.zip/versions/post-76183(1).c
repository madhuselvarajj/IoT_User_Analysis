#include <StreamLib.h>

void setup() {
    Serial.begin(115200);
    char btnPressed = 1;

    byte b;
    BufferedPrint bp(Serial, &b, 1);

    if (btnPressed) {
        bp.printf("%c: %s %i %s", 'Q', "BtnPressed: ", btnPressed, " done ");
    }
}

void loop() {
}
