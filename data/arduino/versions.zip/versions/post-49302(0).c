void setup()
{
 pinMode(LED_BUILTIN, OUTPUT);
}

#define INTERVAL 20000L
#define BLINK_TIMES 5
void loop()
{
 static unsigned long lastBlink = 0;
 static int count = 0;

 unsigned long now = millis();

 if(count > 0) {
  blink();
  count--;
  lastBlink = now;
 } else {
  if(now - lastBlink >= INTERVAL) {
   count = BLINK_TIMES;
  }
 }
}

void blink()
{
 digitalWrite(LED_BUILTIN, HIGH);   // turn the LED on (HIGH is the voltage level)
 delay(500);
 digitalWrite(LED_BUILTIN, LOW);    // turn the LED off by making the voltage LOW
 delay(500);
}
