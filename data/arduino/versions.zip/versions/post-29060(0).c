int LED_PIN = 13;

void flashing(int times=1) { // By default it will flash once, you can chance this into your desire
      int i = 1;
      int delayPeriod = 500;
      do {
        digitalWrite(LED_PIN, HIGH); delay(delayPeriod);
        digitalWrite(LED_PIN, LOW); delay(delayPeriod);
        i++;
      } while (i<=times);
}

void setup() {
    pinMode(ledPin, OUTPUT);
    flashing(3);
}

void loop() {
    // Do something here
}
