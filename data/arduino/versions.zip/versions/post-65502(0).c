void draw(void)
{
   u8g.setFont(u8g_font_fub14r);
   u8g.drawStr(0, 20, "V: ");
   u8g.drawStr(0, 40, "A: ");
   u8g.drawStr(0, 60, "Watt: ");
   u8g.setPrintPos(58,20);
   u8g.print( Bat_Volt,2);
   u8g.println("V");
   u8g.setPrintPos(58,40);
   u8g.print( current,0);
   u8g.println("mA");
   u8g.setPrintPos(58, 60);
   u8g.print( power ,1);
}
