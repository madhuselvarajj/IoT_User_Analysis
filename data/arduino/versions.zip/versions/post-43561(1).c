/* DEFINE PINS */
const int PinBuzzer = 2;
const int PinMic = 0;
const int PinRelayLED = 9;
const int PinRelayLights = 8;

const int sampleWindow = 50;
const int MaxSamples = 50;

// Simple enumeration to clarify which state is on and off.
enum EOnOff { Off, On };
EOnOff lights = Off; //lights on or off
EOnOff leds = Off; //leds on or off

double soundArray[MaxSamples]; //array to check claps


void setup()
{
 pinMode(PinRelayLED, OUTPUT);
 pinMode(PinRelayLights, OUTPUT);
 digitalWrite(PinRelayLED, ConvertOnOff(leds));
 digitalWrite(PinRelayLights, ConvertOnOff(lights));
}


void loop()
{
 for (int sample = 0; sample < MaxSamples; ++sample)
 { // Get the samples
  soundArray[sample] = getVolts();
 }
 switch (clapCount())
 { // Analyse the samples
 case 2:
  lights = ChangeRelay(lights, PinRelayLights);
  playSound();
  break;
 case 3:
  leds = ChangeRelay(leds, PinRelayLEDs);
  playSound();
        break;
 }
}

/// Count the number of 'claps' in the sample data
int clapCount(/*clap array is global*/)
{
 int claps = 0;
 for (int sample = 0; sample < MaxSample; ++sample)
 {
  if (soundArray[sample] > 3.0 && soundArray[sample] < 3.5) /* Why 3.5?? */
  {
   ++claps;
  }
 }
 return claps;
}

/// Convert an EOnOff value to a HIGH or LOW value.
// OFF = HIGH
int ConvertOnOff(const EOnOff& state)
{
 return state == Off ? HIGH : LOW;
}

/// Change a relay to the given state.
/// Return the new state.
EOnOff ControlRelay(const EOnOff& state, const int& relayPin)
{
 EOnOff result = state == On ? Off : On;
 digitalWrite(relayPin, ConvertOnOff (result));
 return result;
}


/* gets mic volts */
double getVolts()
{
 const unsigned long startMillis = millis();  // Start of sample window
 unsigned int signalMax = 0;
 unsigned int signalMin = 1024;

 unsigned int sample;
 // collect data for 50 mS
 while (millis() - startMillis < sampleWindow)
 {
  sample = analogRead(PinMic);
  if (sample < 1024)     // ?? Should this be 1024 or signalMin?
  {
   if (sample > signalMax)
   {
    signalMax = sample;  // save just the max levels
   }
   else if (sample < signalMin)
   {
    signalMin = sample;  // save just the min levels
   }
  }
 }
 const unsigned int peakToPeak = signalMax - signalMin;  // max - min = peak-peak amplitude
 const double volts = (peakToPeak * 5.0) / 1024.0;  // convert to volts
 return volts;
}

void playSound()
{
 tone(buzzer, 1000);
 delay(100);
 tone(buzzer, 500);
 delay(100);
 noTone(buzzer);
}
