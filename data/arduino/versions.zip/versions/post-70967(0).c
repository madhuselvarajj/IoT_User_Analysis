const int model = 0;
float sensitivity[] = {
  0.185,// for ACS712ELCTR-05B-T
  0.100,// for ACS712ELCTR-20A-T
  0.066// for ACS712ELCTR-30A-T
} ;

unsigned long count = 0;
float         Vsum  = 0;
float         Csum  = 0;

long startTime = 0;

void setup()
{
  Serial.begin(9600);
  // setting the LED pins to output
  // I use a loop
  for ( int i = 0; i < 14; i++ )
  {
    pinMode( i, OUTPUT );
  }
}


void loop()
{
  float Vave = 0;
  float Cave = 0;
  // pow is to expensive for the loop
  // I use a constant
  float milli = 0.001;

  if ( startTime = 0 ) startTime = millis();

  float voltage = map( analogRead( A1 ), 0, 1023, 0, 2500 ) / 100.0;
  Vsum = Vsum + voltage;

  float current  = ( voltage / sensitivity[ model ] );
  float current1 = current * milli;

  Csum = Csum + current1;

  count++;

  Vave = Vsum / count;
  Cave = Csum / count;
  float watts = Vave * Cave;

  // you did not use a time delta here,
  // but energiy it work over a time period
  long timeDelta = ( millis() - startTime ) / 1000;

  float energy = ( watts * timeDelta ) / 3600;
  Serial.print( energy, 6 );
  Serial.println( "Wh" );
  delay( 1000 );
}

// naming convention for a serial interrupt
void serialEvent()
{
   while (Serial.available())
   {
     // get the new byte:
     int inByte = Serial.read();

     if(inByte == 0x01)
     {
       digitalWrite(13, HIGH);
       Serial.println("ON");
     }
     else if(inByte == 0x00)
     {
       digitalWrite(13, LOW);
       Serial.println("OFF");
     }
     else if(inByte == 0x02) digitalWrite(12, HIGH);
     else if(inByte == 0x03) digitalWrite(12, LOW);
     else if(inByte == 0x04) digitalWrite(11, HIGH);
     else if(inByte == 0x05) digitalWrite(11, LOW);
     else if(inByte == 0x06) digitalWrite(10, HIGH);
     else if(inByte == 0x07) digitalWrite(10, LOW);
     else if(inByte == 0x08) digitalWrite(9,  HIGH);
     else if(inByte == 0x09) digitalWrite(9,  LOW);
     else if(inByte == 0x10) digitalWrite(8,  HIGH);
     else if(inByte == 0x11) digitalWrite(8,  LOW);
     else if(inByte == 0x12) digitalWrite(7,  HIGH);
     else if(inByte == 0x13) digitalWrite(7,  LOW);
     else if(inByte == 0x14) digitalWrite(6,  HIGH);
     else if(inByte == 0x15) digitalWrite(6,  LOW);
     else if(inByte == 0x16) digitalWrite(5,  HIGH);
     else if(inByte == 0x17) digitalWrite(5,  LOW);
     else if(inByte == 0x18) digitalWrite(4,  HIGH);
     else if(inByte == 0x19) digitalWrite(4,  LOW);
     else if(inByte == 0x20) digitalWrite(3,  HIGH);
     else if(inByte == 0x21) digitalWrite(3,  LOW);
     else if(inByte == 0x22) digitalWrite(2,  HIGH);
     else if(inByte == 0x23) digitalWrite(2,  LOW);
     else if(inByte == 0x24) digitalWrite(1,  HIGH);
     else if(inByte == 0x25) digitalWrite(1,  LOW);
     else if(inByte == 0x26) digitalWrite(0,  HIGH);
     else if(inByte == 0x27) digitalWrite(0,  LOW);
   }
}
