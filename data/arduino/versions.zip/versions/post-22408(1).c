String rcev_data="";
bool chk=false;
\#define output 9

\#define output2 10

void setup()
{
// put your setup code here, to run once:
Serial.begin(9600);
pinMode(output, OUTPUT);
pinMode(output2, OUTPUT);
}

void loop()
{
// put your main code here, to run repeatedly:
while(Serial.available())
{
char rxx = Serial.read();
recv.concat(rxx);
delay(10);
if (recv == "QWER")
{
   chk=1;
   break;
 }
else
 chk=0;
}



if (chk)
{
digitalWrite(output,HIGH);
Serial.println("ON");
delay(3000);
chk=0;
}

else
{
digitalWrite(output,LOW);
}
recv="";
}
