#include <MadgwickAHRS.h>
const float sensorRate = 104.00;
Madgwick filter;
filter.begin(sensorRate);
void loop() {
 float xAcc, yAcc, zAcc;
 float xGyro, yGyro, zGyro;
 float roll, pitch, heading;
 if(IMU.accelerationAvailable() && IMU.gyroscopeAvailable()){
   IMU.readAcceleration(xAcc, yAcc, zAcc);
   IMU.readGyroscope(xGyro, yGyro, zGyro);
   filter.updateIMU(xGyro, yGyro, zGyro, xAcc, yAcc, zAcc);
   pitch = filter.getPitch()
   }
};
