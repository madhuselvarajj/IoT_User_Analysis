    #include <SPI.h>
    #include <WiFi.h>
    #include <WiFiClient.h>

    char ssid[] = "rtcin-dlink";     //  your network SSID (name)
    char pass[] = "bosch1601";  // your network password
    int status = WL_IDLE_STATUS;     // the Wifi radio's status

    //Hue constants
    const char hueHubIP[] = "192.168.0.50";  //Hue hub IP
    const char hueUsername[] = "myhue";  //Hue username
    const int hueHubPort = 80;

    IPAddress server(192,168,0,50);

    // Uncomment this to *really* use the Wi-Fi sheild.
    // Comment this to read & write everything to the Serial Monitor for testing.
    //#define REAL_WIFI
    #ifdef REAL_WIFI
    WiFiClient client;
    #else
    HardwareSerial & client = Serial; // redirect 'client' to the Serial Monitor
    #endif

    //Hue variables
    boolean hueOn;  // on/off
    int hueBri;  // brightness value
    long hueHue;  // hue value
    String hueCmd;  // Hue command

    unsigned long buffer=0;  //buffer for received data storage
    unsigned long addr;
    IPAddress ip;

    void setup()
    {
     //Initialize serial and wait for port to open:
      Serial.begin(9600);
      while (!Serial) {
        ; // wait for serial port to connect. Needed for native USB port only
      }

      // check for the presence of the shield:
      if (WiFi.status() == WL_NO_SHIELD) {
        Serial.println(F("WiFi shield not present"));
        // don't continue:
    #ifdef REAL_WIFI
        while (true);
    #else
        status = WL_CONNECTED;
    #endif
      }

      // attempt to connect to Wifi network:
      while (status != WL_CONNECTED) {
        Serial.print(F("Attempting to connect to WPA SSID: "));
        Serial.println(ssid);
        // Connect to WPA/WPA2 network:
        status = WiFi.begin(ssid, pass);

        // wait 10 seconds for connection:
        delay(10000);
      }

      // you're connected now, so print out the data:
      Serial.print(F("You're connected to the network"));
      printCurrentNet();
      printWifiData();
    }


    void loop() 
    {
      setHue
        ( 1,
          F("{\"on\": true,\"hue\": 50100,\"sat\":255,\"bri\":255,\"transitiontime\":"),
          random(15,25),
          F("}")
        );

      delay( 10000 );

      setHue
        ( 2,
          F("{\"on\": true,\"hue\": 65280,\"sat\":255,\"bri\":255,\"transitiontime\":"),
          random(15,25),
          F("}")
        ); 

      delay( 10000 );

      setHue
        ( 1,
          F("{\"hue\": 65280,\"sat\":255,\"bri\":255,\"transitiontime\":"),
          random(15,25),
          F("}")
        );

      delay( 10000 );

      setHue
        ( 2,
          F("{\"hue\": 50100,\"sat\":255,\"bri\":255,\"transitiontime\":"),
          random(15,25),
          F("}")
        );

      delay( 10000 );

    //  getHue( 1 );
    //  getHue( 2 );
    }


    /* setHue() is our main command function, which needs to be passed a light number and a 
     * properly formatted command string in JSON format (basically a Javascript style array of variables
     * and values. It then makes a simple HTTP PUT request to the Bridge at the IP specified at the start.
     */
    boolean setHue
      ( int                        lightNum,
        const __FlashStringHelper *header,
        int                        parameter,
        const __FlashStringHelper *trailer )
    {
    #ifdef REAL_WIFI
      client.stop();

      if (client.connect(server, 80))
    #endif
      {

        Serial.println(F("connected to server"));
    #ifdef REAL_WIFI
        if (client.connected()&& status == WL_CONNECTED)
    #endif
        {
          client.print(F("PUT /api/"));
          client.print(hueUsername);
          client.print(F("/lights/"));
          client.print(lightNum);  // hueLight zero based, add 1
          client.println(F("/state HTTP/1.1"));
          client.println(F("Connection: keep-alive"));
          client.print(F("Host: "));
          client.println(hueHubIP);

          // Calculate total command length.
          int cmdLength =
            strlen_P( (const prog_char *)header ) +
            1 +   //   Assume one digit for parameter...
            strlen_P( (const prog_char *)trailer );
          
          //  ... and add room for more digits if necessary.
          if (parameter > 9)
            cmdLength++;
          if (parameter > 99)
            cmdLength++;

          client.print(F("Content-Length: "));
          client.println( cmdLength );
          client.println(F("Content-Type: text/plain;charset=UTF-8"));
          client.println();  // blank line before body
          client.print( header );  // Hue command pieces
          client.print( parameter );
          client.println( trailer );
        }
        client.flush();
    #ifdef REAL_WIFI
        client.stop();
    #endif
        return true;  // command executed
      }
    #ifdef REAL_WIFI
      else
        return false;  // command failed
    #endif
    }

    //---------------------------------------------------------------------
    // Utility function to extract one `bool` value from the client stream.
    //   No buffers are used.  Each character is handled as it is received.
    //   (you may want/need to add a timeout)

    static bool clientParseBool( char delim )
    {
      bool val = false;
      uint8_t count = 0; // number of chars we've read for the value

      while (status == WL_CONNECTED) {
        if (client.available()) {
          char c = client.read();
          if (c == delim)
            break; // done!
          if ((c == ' ') || (count++ > 0))
            continue; // skip spaces and anything after the first non-space char

          if (c == 't')
            val = true;
        }
      }

      // Debug prints
      Serial.print( F("bool ") );
      Serial.println( val );

      return val;
    }

    //-------------------------------------------
    // Utility function to extract one 'unsigned 16-bit int' value from the client stream.
    //   No buffers are used.  Each character is handled as it is received.
    //   (you may want/need to add a timeout)

    static uint16_t clientParseUint( char delim )
    {
      uint16_t val = 0;
      
      while (status == WL_CONNECTED) {
        if (client.available()) {
          char c = client.read();
          if (c == delim)
            break; // done!
          if (c == ' ')
            continue; // skip spaces

          if (isdigit(c))
            val = val*10 + (c - '0'); // accumulate one digit of the bri value
        }
      }

      // Debug prints
      Serial.print( F("int ") );
      Serial.println( val );

      return val;
    }

    //-------------------------------------------

    /* A helper function in case your logic depends on the current state of the light. 
     * This sets a number of global variables which you can check to find out if a light is currently on or not
     * and the hue etc. Not needed just to send out commands
     */
    boolean getHue(int lightNum)
    {
      bool gotHue = false;

    #ifdef REAL_WIFI
      client.stop();
      if (client.connect(server, 80))
    #endif
      {

        client.print(F("GET /api/"));
        client.print(hueUsername);
        client.print(F("/lights/"));
        client.print(lightNum);  
        client.println(F(" HTTP/1.1"));
        client.print(F("Host: "));
        client.println(hueHubIP);
        client.println(F("Content-type: application/json"));
        client.println(F("Connection: keep-alive"));
        client.println();
        
        if (status == WL_CONNECTED)
        {
            client.findUntil("\"on\":", "\0");
            hueOn = clientParseBool(',');

            if (status == WL_CONNECTED)
            {
                client.findUntil("\"bri\":", "\0");
                hueBri = clientParseUint(',');
                
                if (status == WL_CONNECTED)
                {
                    client.findUntil("\"hue\":", "\0");
                    hueHue = clientParseUint(',');
                    
                    gotHue = true;  // captured all three: on,bri,hue
                }
            }
        }

        client.flush();
    #ifdef REAL_WIFI
        client.stop();
    #endif
      }

      return gotHue;
    }

    void printWifiData() {

      //WiFi shield's IP address:
      IPAddress ip = WiFi.localIP();
      Serial.print(F("IP Address: "));
      Serial.println(ip);
    }

    void printCurrentNet() {
      //SSID of the network you're attached to:
      Serial.print(F("SSID: "));
      Serial.println(WiFi.SSID());
    }