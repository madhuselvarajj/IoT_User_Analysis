void setup()
{
 Serial.begin(9600);
 pinMode(LED_BUILTIN, OUTPUT);
}

#define INTERVAL 20000L
#define BLINK_TIMES 5
void loop()
{
 static unsigned long lastBlink = 0;
 static int count = 0;

 unsigned long now = millis();

 if(count > 0) {
  count -= blink();
  lastBlink = now;
 } else {
  if(now - lastBlink >= INTERVAL) {
   count = BLINK_TIMES;
  }
 }
}

/*
 * Do one blink.
 * Return 1 when blink is done.
 */
int blink()
{
  static unsigned long lastFlip = 0;
  static int count = 0;
  bool last = false;

  unsigned long now = millis();

  if(now - lastFlip >= 500) {
 digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    Serial.print(now / 1000); Serial.print(". "); Serial.println("blink");
 lastFlip = now;
    count++;
    if (count == 2) {
      count = 0;
      last = true;
      }
   }

   return (last) ? 1 : 0 ;
}
