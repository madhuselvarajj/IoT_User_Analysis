const int lowerThreshold = 150;
    const int upperThreshold = 200;
    
    const uint8_t analogPin = A0;
    const uint8_t ledPin = LED_BUILTIN;
    
    void setup() {
      Serial.begin(115200);
      pinMode(ledPin, OUTPUT);
    }
    
    void loop() {
      static bool state = LOW;
      static unsigned int counter = 0;
    
      int analogValue = analogRead(analogPin);
      if (state == HIGH) {
        if (analogValue < lowerThreshold) {
          state = LOW;
          counter++;
          Serial.println(counter);
          digitalWrite(ledPin, LOW);
        }
      } else { // state == LOW
        if (analogValue > upperThreshold) {
          state = HIGH;
          digitalWrite(ledPin, HIGH);
        }
      }
    }