void setup () {
  Serial.begin( 115200 ); // set the baud rate for writing messages.
  int go = 1; // set the flag to continue do-while loop;
  int n, nMin = 0, nMax = 0; // see how many more the numbers of calling micros() to get different value;
  int d, dMin, dMax; // see the time interval of micros() having different values;
  unsigned long currT; // the time of current micros() calling
  unsigned long lastT = micros(); // the time of last micros() calling
  unsigned long T[200]; // keep tracking 200 different lastT values
  int it = 0; // use T[it%200] to keep each lastT (circular buffer)
  do {
    n = 0;
    while( (currT=micros()) == lastT ) n++; // get a different value
    T[ (it++) % 200 ] = currT; // save the value
    d = currT - lastT; // get the difference
    if ( d<0 ) { // if micros() rolls over
      go = 0; // stop this do-while loop
      Serial.println(); // print new line
      for ( int i=it-200, j=0; i<it; i++ ) {
        Serial.printf( "%9x", T[i%200] ); // the last 200 different lastT values
        if ( ++j%5==0 ) Serial.println(); //
      }
      Serial.printf("\nat %d ms lastT 0x%x currT 0x%x n=[%d..%d] d=[%d..%d]\n",
        millis(), lastT, currT, nMin, nMax, dMin,dMax);
    }
    if ( !nMin && !nMax ) nMin = nMax = n, dMin = dMax = d;
    if ( nMin>n ) {
      PRINTF( "\nat %d ms nMin %d > n %d ", millis(), nMin, n);
      nMin = n;
    } else if ( nMax<n ) {
      PRINTF( "\nat %d ms nMax %d < n %d", millis(), nMax, n );
      nMax = n;
    }
    if ( dMin>d ) dMin = d;
    else if ( dMax<d ) dMax = d;
    lastT = currT;
  } while( go );
}
