int LED_PIN = 13;
        
        void flashing(size_t times=1) { // By default it will flash once, you can chance this into your desire
            int delayPeriod = 500;
            for (size_t loop = 0; loop < (times*2); ++loop) {
              digitalWrite(LED_PIN, (loop % 2)?HIGH:LOW);// Use Modulus
              delay(delayPeriod);
            } // Thanks to [Matt][1] and [Edgar Bonet][2] for their comments
        }
        
        void setup() {
            pinMode(ledPin, OUTPUT);
            flashing(3);
        }
        
        void loop() {
            // Do something here
        }