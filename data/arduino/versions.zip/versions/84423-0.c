uint16_t SparkFun_Ambient_Light::_readRegisterLight(uint8_t _reg)
    {
        int lsb;
        int msb;
    
        _i2cPort->beginTransmission(_address);
        _i2cPort->write(_reg); // Moves pointer to register.
        if (_i2cPort->endTransmission(false) == 0) { // 'False' here sends a restart message so that bus is not released
    
            unsigned long tstamp = millis();
            while ((_i2cPort->available() < 2) && ((millis() - tstamp) < 10));
    
            if ((_i2cPort->available() < 2)) {
                _i2cPort->requestFrom(_address, 2); // Two reads for 16 bit registers
                lsb = _i2cPort->read(); // LSB
                msb |= uint16_t(_i2cPort->read()) << 8; //MSB
    
                if ((lsb >= 0) && (msb >= 0)) {
                    _regValue = lsb;
                    _regValue |= uint16_t(msb) << 8;
                }
            }
    
    
            return(_regValue);
        }
        else
            return _regValue;//last read 
    }
