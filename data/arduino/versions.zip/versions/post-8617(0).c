#include <IRremote.h> // IR Library - Encode/Decode

void irSerial( char SerChar[] ) {// Receive array of characters

    char IDChar[]={'s', 'i', 'u'}; // List of Serial Char to identify position
    String HRD[]={"Power", "Input", "ChaUp"}; // Action referece
    long CodesIR[]={0x61A0F00F, 0x61A048B7, 0x61A050AF}; // IR Codes
    int IRArray = 2; // Size Of The array

    if ( SerChar[0] == 's' ) { // Compare Array
      for (int CountIR = 0; CountIR <= IRArray; CountIR++){ // Loop through array
        if ( SerChar[0] == IDChar[CountIR]) {
           Serial.println(HRD[CountIR]); // Send String in array - Works
           SendIR.sendNEC(CodesIR[CountIR],32); // Send IR in array position
        }
      }
    }
}
