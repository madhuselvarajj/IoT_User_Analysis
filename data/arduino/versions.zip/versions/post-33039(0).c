void loop() {
    Serial.println("To toggle relay enter on or off");
    if (Serial.available()) {
      char c = Serial.read();   // get one byte from serial buffer
      if ('\r'!=c && '\n'!=c)
        serialinput += c;     // add it to readString
      }
    }

    if(serialInput=="on") {
        digitalWrite(relay, HIGH);
        serialInput = "";
    }

    if(serialInput=="off") {
        digitalWrite(relay, LOW);
        serialInput = "";
    }
}
