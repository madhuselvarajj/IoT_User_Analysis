#include <FastLED.h>


    #define LED_PIN     5
    #define COLOR_ORDER GRB
    #define CHIPSET     WS2811
    #define NUM_LEDS    (kMatrixWidth * kMatrixHeight)
    #define FRAMES_PER_SECOND 60
    //////////////////////////////////////////////////////
    const uint8_t kMatrixWidth  = 15;
    const uint8_t kMatrixHeight = 4;
    const bool    kMatrixSerpentineLayout = true;
    //////////////////
    int BRIGHTNESS = 250;

   //////////////////////////////////////////////////
   bool gReverseDirection = false;

   CRGB leds[NUM_LEDS];

   void setup() {
   Serial.begin(115200);
   Serial.println("*** Inicialization");
   ///////////////////////////////////////////////
   delay(3000); // sanity delay
   FastLED.addLeds<CHIPSET, LED_PIN, COLOR_ORDER>(leds, NUM_LEDS);
   FastLED.setBrightness( BRIGHTNESS );
   }
   /////////////////////////////////// end setup

   void loop()
   {

    Fire2012();
    FastLED.show(); // display this frame
    FastLED.delay(1000 / FRAMES_PER_SECOND);
    FastLED.setBrightness( BRIGHTNESS );
    }


    void Fire2012()
    {
     int COOLING = 90;
     int SPARKING = 100;
      // Array of temperature readings at each simulation cell

       static byte heat[kMatrixWidth] [kMatrixHeight];

       // Step 1.  Cool down every cell a little
       for (int n = 0; n< kMatrixHeight; n++)
      {

        for ( int i = 0; i < kMatrixWidth; i++) {
          heat[i][n] = qsub8( heat[i][n],  random8(0,
          ((COOLING * 10) / (kMatrixWidth)) + 2));
          }

          // Step 2.
         for ( int k = (kMatrixWidth) - 1; k >= 2; k--) {
         heat[k][n] = (heat[k - 1][n] + heat[k - 2][n] +
         heat[k - 2][n] ) / 3;
         }

          // Step 3.
         if ( random8() < SPARKING ) {
          int y = random8(3);
          heat[y][n] = qadd8( heat[y][n], random8(160, 255) );
         }
        }

     // Step 4.  Map from heat cells to LED colors

   for ( int i= 0; i < kMatrixWidth; i++) {
     for (int j = 0; j < kMatrixHeight; j++) {

       CRGB color = HeatColor(heat[i][j]);
       leds[XY(i, j)] = color;

     }
   }




       }

      /////////////
       uint16_t XY( uint8_t x, uint8_t y)
       {
       uint16_t i;
       if ( kMatrixSerpentineLayout == false) {
       i = (y * kMatrixWidth) + x;
       }
       if ( kMatrixSerpentineLayout == true) {
       if ( y & 0x01) {
        // Odd rows run backwards
        uint8_t reverseX = (kMatrixWidth - 1) - x;
        i = (y * kMatrixWidth) + reverseX;
        } else {
       // Even rows run forwards
         i = (y * kMatrixWidth) + x;
        }
       }

       return i;

        }/////
