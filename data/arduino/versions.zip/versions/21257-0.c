 const char* GetBoard()
    {
        // -------------------------------- ARDUINO BOARDS
        #if defined(ARDUINO_AVR_ADK)       
            return ""Adk"";
        #elif defined(ARDUINO_AVR_BT)       
            return ""Bt"";
        #elif defined(ARDUINO_AVR_DUEMILANOVE)       
            return ""Due"";
        #elif defined(ARDUINO_AVR_ESPLORA)       
            return ""Esplora"";    
        #elif defined(ARDUINO_AVR_ETHERNET)       
            return ""Ethernet"";    
        #elif defined(ARDUINO_AVR_FIO)       
            return ""Fio"";
        #elif defined(ARDUINO_AVR_GEMMA)       
            return ""Gemma"";
        #elif defined(ARDUINO_AVR_LEONARDO)       
            return ""Leonardo"";
        #elif defined(ARDUINO_AVR_LILYPAD)       
            return ""Lilypad"";
        #elif defined(ARDUINO_AVR_LILYPAD_USB)       
            return ""Lilypad Usb"";
        #elif defined(ARDUINO_AVR_MEGA)       
            return ""Mega"";
        #elif defined(ARDUINO_AVR_MEGA2560)       
            return ""Mega 2560"";
        #elif defined(ARDUINO_AVR_MICRO)       
            return ""Micro"";
        #elif defined(ARDUINO_AVR_MINI)       
            return ""Mini"";
        #elif defined(ARDUINO_AVR_NANO)       
            return ""Nano"";
        #elif defined(ARDUINO_AVR_NG)       
            return ""NG"";
        #elif defined(ARDUINO_AVR_PRO)       
            return ""Pro"";
        #elif defined(ARDUINO_AVR_ROBOT_CONTROL)       
            return ""Robot Ctrl"";
        #elif defined(ARDUINO_AVR_ROBOT_MOTOR)       
            return ""Robot Motor"";
        #elif defined(ARDUINO_AVR_UNO)       
            return ""Uno"";
        #elif defined(ARDUINO_AVR_YUN)       
            return ""Yun"";
        // -------------------------------- TEENSY BOARDS
        #elif defined(TEENSY_TEENSY2)       
            return ""Teensy 2.0"";
        #elif defined(TEENSY_TEENSY2PP)       
            return ""Teensy++ 2.0"";
        #elif defined(TEENSY_TEENSY30)       
            return ""Teensy 3.0"";
        #elif defined(TEENSY_TEENSY31)       
            return ""Teensy 3.1"";
        #elif defined(TEENSY_TEENSY32)       
            return ""Teensy 3.2"";
        #elif defined(TEENSY_TEENSYLC)       
            return ""Teensy LC"";
        #else
           return ""?"";
        #endif
    }