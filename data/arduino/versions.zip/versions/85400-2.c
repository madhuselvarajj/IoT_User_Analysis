#include <limits.h>
    
    #define sprintfln(args...) { char _qsx6_[200]; snprintf(_qsx6_, 200, args); Serial.println(_qsx6_); } // _qsx6_ may collide with local var
    
    void setup()
    {
        Serial.begin(115200);
    
        unsigned char  uc = 0; uc=~uc; Serial.println(uc);
        unsigned short us = 0; us=~us; Serial.println(us);
        unsigned int   ui = 0; ui=~ui; Serial.println(ui);
        unsigned long  ul = 0UL; ul=~ul; Serial.println(ul);
        unsigned long long ull = 0ULL; ull=~ull; // doesn't work: Serial.println(~ull);
        
        sprintfln(""char:%u short:%u int:%u long:%lu long long:%llu"", uc, us, ui, ul, ull);
        sprintfln(""char:%u short:%u int:%u long:%lu long long:%llu"", UCHAR_MAX, USHRT_MAX, UINT_MAX, ULONG_MAX, ULLONG_MAX);
        sprintfln(""char:%u short:%u int:%u long:%u long long:%u"", sizeof(uc), sizeof(us), sizeof(ui), sizeof(ul), sizeof(ull));
        sprintfln(""pointer:%u"", sizeof(&uc));
    }