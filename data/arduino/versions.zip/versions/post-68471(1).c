#include "FastLED.h"


int inPin = 8;         // the number of the input pin
int inPinTwo = 9;
int inPinThree = 10;
int outPin = 13;       // the number of the output pin

int state = HIGH;      // the current state of the output pin

int reading;           // the current reading from the input pin
int readingTwo;
int readingThree;
int previous = LOW;    // the previous reading from the input pin
volatile int change;
int btnPress;

int pixelNumber;



// the follow variables are long's because the time, measured in miliseconds,
// will quickly become a bigger number than can be stored in an int.
long time = 0;         // the last time the output pin was toggled
long debounce = 200;   // the debounce time, increase if the output flickers

//NEOPIXEL
#define LED_PIN     7
#define LEDPIN 7
#define LED_TYPE     NEOPIXEL
#define NUM_LEDS    2
#define BRIGHTNESS 255
#define FRAMES_PER_SECOND 60
CRGB leds[NUM_LEDS];
#define COLOR_ORDER GRB
#define CHIPSET     WS2812B


void setup()
{


//BUTTON
 pinMode(inPin, INPUT);
 pinMode(inPinTwo,INPUT);
 pinMode(inPinThree,INPUT);
 pinMode(outPin, OUTPUT);

 Serial.begin(9600);

 // set up LED strip info
FastLED.addLeds<LED_TYPE,LEDPIN>(leds,NUM_LEDS).setCorrection(TypicalLEDStrip);
FastLED.setBrightness(BRIGHTNESS);
btnPress = 1;

}

void loop()
{
//    BUTTON 1 - SOLID LIGHT
 reading = digitalRead(inPin);
 if (reading == HIGH && previous == LOW && millis() - time > debounce) {
   if (state == HIGH){
     state = LOW;
     btnPress = 1;
   }
   else{
     state = HIGH;
     btnPress = 2;
     }

   time = millis();

 }
   digitalWrite(outPin, state);
   previous = reading;

//  BUTTON 2 - GLITTER LIGHT
  readingTwo = digitalRead(inPinTwo);
 if (readingTwo == HIGH && previous == LOW && millis() - time> debounce){
   if(state == HIGH){
     state = LOW;
     btnPress = 3;
     }
   else{
     state = HIGH;
     btnPress = 4;
   }
   time = millis();
   }
   digitalWrite(outPin,state);
   previous = readingTwo;


//  BUTTON 3  - MOVEMENT SENSOR LIGHT
      readingThree = digitalRead(inPinThree);
 if (readingThree == HIGH && previous == LOW && millis() - time> debounce){
   if(state == HIGH){
     state = LOW;
      btnPress = 5;
     }
   else{
     state = HIGH;
     btnPress = 6;
   }

   time = millis();
   }
   digitalWrite(outPin,state);
   previous = readingThree;



   //BUTTON 1 - SOLID LIGHT
    if (btnPress == 1){
         fill_solid(leds,NUM_LEDS,CRGB::Black);
         FastLED.show();
     }

   if (btnPress == 2){
         fill_solid(leds,NUM_LEDS,0xFfffff);
         FastLED.show();

     }

   //  BUTTON 2 - GLITTER LIGHT
   if (btnPress == 3){
           fill_solid(leds,NUM_LEDS,CRGB::Black);
         FastLED.show();

     }
   if (btnPress == 4){
        fadeToBlackBy( leds, NUM_LEDS, 10);
         addGlitter(30);
         FastLED.show();
     }

   //  BUTTON 3  - MOVEMENT SENSOR LIGHT
   if (btnPress == 5){
           fill_solid(leds,NUM_LEDS,CRGB::Black);
         FastLED.show();

     }
   if (btnPress == 6){

     }
 }


//glitter effect
void addGlitter( fract8 chanceOfGlitter) {
 if( random8() < chanceOfGlitter) {
   leds[ random16(NUM_LEDS) ] += CRGB::White;}
}
