bool increasing(int * DIST)
{
    int dir = 0;

    for (int x=1; x<MAX_AVRG; x++)
    {
        if (DIST[x] > DIST[x-1])   // change this to < for DECREASE
            dir++;
        else
            dir--;
    }

    if (dir > 0)
        return TRUE;
    else
        return FALSE;
}
