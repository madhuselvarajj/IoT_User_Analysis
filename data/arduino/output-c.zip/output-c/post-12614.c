uart myUart;

int main() {
    myUart.begin(9600);
    myUart.print("Hello world\n");
}
