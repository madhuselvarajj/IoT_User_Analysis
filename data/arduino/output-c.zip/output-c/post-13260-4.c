void BlinkLed(int f);
void HandleRequest();
boolean HandleSerial();

int f = 0;//Frequency of the led (blinking)

void setup() {
    Serial.begin(57600);  
    pinMode(13, OUTPUT);
}

void loop() {
    String in = "";//Clear the string every new loop.
    if (Serial.available()) {
        if(HandleSerial()){
            HandleRequest();
        }
    }
    BlinkLed(f);
}

void BlinkLed(int f){
if (f>0) {
        static unsigned long t = millis();
        if (millis() > t + 1000/f) {
            digitalWrite(13, 1-digitalRead(13));
            t = millis();
        }
    }
}

boolean HandleSerial(){
        in = "";
        while (true) {  // should add time out here
            while (Serial.available() == false) {}
            in += (char)(Serial.read());
            if (in.endsWith("\r\n\r\n")) {
                return true;
            } 
        }
        return false;
}

void HandleRequest(void){
    int i1 = in.indexOf("GET /blink?f="), i2;
    if (i1 != -1) {
        i2 = in.indexOf(" ", i1+13);
        f = in.substring(i1+13, i2).toInt();
    }
    Serial.println("HTTP/1.1 200 OK\nContent-Type: text/html\nConnection: close");
    String sr = "<!DOCTYPE HTML>\n";
    sr += "<html>\n";
    sr += "LED frequency: ";
    sr += f;
    sr += "Hz.</html>";
    Serial.print("Content-Length: ");
    Serial.print(sr.length());
    Serial.print("\r\n\r\n");
    Serial.print(sr);
}
