#include <SPI.h>
const byte LATCH = 10;
const byte numberOfChips = 4;
byte LEDdata [numberOfChips];  // initial pattern

void refreshLEDs ()
  {
  digitalWrite (LATCH, LOW);
  for (byte i = 0; i < numberOfChips; i++)
    SPI.transfer (LEDdata [i]); 
  digitalWrite (LATCH, HIGH);
  } // end of refreshLEDs

void setup ()
{
  SPI.begin ();
}  // end of setup

void showPattern (unsigned long patt)
  {
  LEDdata [0] = patt & 0xFF;
  LEDdata [1] = (patt >> 8) & 0xFF;
  LEDdata [2] = (patt >> 16) & 0xFF;
  LEDdata [3] = (patt >> 24) & 0xFF;
  refreshLEDs ();
  } // end of showPattern

const int whichFlicker = 12;  // which LED to toggle
unsigned long pattern = 0xFFFFFFFF;  // pattern for other LEDs

void loop ()
{
  pattern ^= 1UL << whichFlicker;
  showPattern (pattern);
  delay (100);
  pattern ^= 1UL << whichFlicker;
  showPattern (pattern);
  delay (20);
}  // end of loop
