...
boolean borrar = false;
int IP = 0;
...

void loop() {
  while (Serial1.available()) { 
    char caracter = Serial1.read(); //Comprobamos el caracter 
    switch(caracter) {

    // NOTE it is better to replace default by the list of all digits...    
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
                if (borrar) { 
                              IP = 0; 
                              lcd.clear();
                }

                lcd.print(caracter);
                delay(125);
                borrar = false;

                IP *= 10;
                IP += (int) (caracter - '0');
                break;  

    case '\r':                
    case 0x0F:
    case 0x0A:  

                String res = "";
                borrar = true;
                int num= IP;
                if (num < 127) 
                  res="Clase A";
                if (num == 127) 
                  res="Direccion reservada";
                if (num > 127 && num < 192)
                  res="Clase B ";
                if (num >= 192 && num < 224)
                  res="Clase C ";
                if (num >= 224 && num < 240)
                  res="Clase D ";
                if (num >= 240 && num < 255)
                  res="Clase E ";
                break;  

  } //fin switch

}//serial disponible

}//fin programa
