#include "share.h"

// Loop function callback (to speed things up)
typedef void (*loopfunction)();
loopfunction currentloop;

const int RXTX_PIN = 8;

void setup()
{
    pinMode(RXTX_PIN,INPUT);
    if (digitalRead(RXTX_PIN))
    {
        setup_tx();
        currentloop = loop_tx;
    }
    else
    {
        setup_rx();
        currentloop = loop_rx;
    }
}

void loop()
{
    currentloop();
}

void setup_tx(){...}
void loop_tx(){...}

void setup_rx(){...}
void loop_rx(){...}
