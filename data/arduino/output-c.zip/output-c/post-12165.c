
#include <EasyTransfer.h>

int D_Status_Word = 0;
int Status_Word = 0; //sets all bits to  zero
int Light_Threshold = 150; //the light level that constitutes an unusual entry
int Active = 0;
int Passive = 100;
int Counter = 100;
int Green_Pin = 7;
int Amber_Pin = 8;
int Red_Pin = 9;
int Photocell_Pin = 1;     // the cell and 10K pulldown are connected to a0
int Photocell_Reading;
int Sensor_Frequency = 0;

struct SEND_DATA_STRUCTURE {
  //put your variable definitions here for the data you want to receive
  //THIS MUST BE EXACTLY THE SAME ON THE OTHER ARDUINO
  int Out_Word;
  int LDR_Level;
};

SEND_DATA_STRUCTURE My_Tx_Data;

//create an object for themessage
EasyTransfer ETout;
int D_Sensor_Pin [] = {
  2, 3, 5, 6
};
// pin hallwaypir, 3 doorpir, 5 door sensor, 6 hallpir

void setup() {
  Serial.begin (9600);
  // put your setup code here, to run once:
  ETout.begin(details(My_Tx_Data), &Serial);
  for (int i = 0; i <= 3; i++)// read the two state sensors
  {
    pinMode(D_Sensor_Pin [i], INPUT);
  }
  pinMode(A1, INPUT);//set the analoge u ldr pin ot input mode
  pinMode (Green_Pin, OUTPUT);
  pinMode (Amber_Pin , OUTPUT);
  pinMode (Red_Pin , OUTPUT);
}

void loop() {
  Scan_Sensors();
  if (D_Status_Word != Status_Word)
  {
    Sensor_Frequency = Active; // high frequency sampling because a sensor has activated
    //send a data packet to the mega with mem card via serial.
    Send_Data_Packet();
  }
  if (bitRead (Status_Word, 1) != bitRead (D_Status_Word, 1))
  {
    if ((D_Status_Word, 1) == 1)
    {
      Traffic_Light_Stop();
    }
    else
    {
      Traffic_Light_Go();
    }
  }
  Status_Word = D_Status_Word;

  delay(Sensor_Frequency);// 1000= waits for a second
}

void Scan_Sensors()
{
  byte readings = 0;
  Photocell_Reading  = 0;
  for (int i = 0; i <= 3; i++)// read the two state sensors
  {
    bitWrite(readings, i, digitalRead(D_Sensor_Pin [i] ));
  }
  //test to see if any sensors have trivggered (readings>0)
  if (readings > 0)
  { // a 2 state sensor has triggered, reset the Counter to 100
    Counter = 100;
  }

  //read threshold sensors
  Photocell_Reading  = analogRead(Photocell_Pin);
  {
    bitSet(readings, 4); // 4 becaus there are 4 2 state sensors (0 to 3)
    //we write 1 because thelight is below the threshold
    Serial.print ("photocell Reading = ");
    Serial.println(Photocell_Reading);
  }
  D_Status_Word = readings;
  Counter -= 1; //decrement the Counter
  if (Counter <= 0)
  { //the Counter has counted 100 scans since a 2state has triggered
    //rest freqenvcy to Passive
    Sensor_Frequency = Passive;

  }
}
void Send_Data_Packet()
{
  My_Tx_Data.Out_Word = D_Status_Word;
  My_Tx_Data.LDR_Level = Photocell_Reading;
  Serial.print ("photocell Reading = ");
  Serial.println(Photocell_Reading);
  Serial.print ("status word = ");
  Serial.println(D_Status_Word);
  ETout.sendData();
}

void Traffic_Light_Stop()
{
  //lights turn from green to yellow to red
  digitalWrite (Green_Pin, LOW);
  digitalWrite (Amber_Pin, HIGH);
  digitalWrite (Red_Pin, LOW);
  delay(750);
  digitalWrite (Green_Pin, LOW);
  digitalWrite (Amber_Pin, LOW);
  digitalWrite (Red_Pin, HIGH);
}

void Traffic_Light_Go()
{
  //lights turn red to red and yellow to green
  digitalWrite (Green_Pin, LOW);
  digitalWrite (Amber_Pin, HIGH);
  digitalWrite (Red_Pin, HIGH);
  delay(750);
  digitalWrite (Green_Pin, HIGH);
  digitalWrite (Amber_Pin, LOW);
  digitalWrite (Red_Pin, LOW);

}

