int pin = 13; 
volatile  int tcnt = 0; 
volatile int state = LOW; 

void setup() { 
  Serial.begin(9600);
  pinMode(pin, OUTPUT); 
  attachInterrupt(0, blink, RISING); 
} 

void loop() { 
  Serial.println(tcnt); 
  digitalWrite(pin, state);
   delay(10);
} 

void blink() { 
  tcnt = tcnt + 1; 
  state = !state; 
}
