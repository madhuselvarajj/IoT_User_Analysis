#define MAX_DIST 5

int dist[MAX_DIST];    // create an array, no need to initialise.
double distAverage;    // average distance, could be 'int' instead.
int distIterator = 0;  // 'dist' will be a CYCLIC BUFFER. woooOOOOooo.

// As you get the distance from your sensor, update 'dist' and
// then calculate the running average.

dist[distIterator] = microsecondsToCentimeters(duration);
distIterator++;
if (distIterator == MAX_DIST) distIterator = 0;
distAverage = 0.0;
for (int x=0; x<MAX_DIST; x++)
    distAverage += dist[x];
distAverage /= MAX_DIST;
