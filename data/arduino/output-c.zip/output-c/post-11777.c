client.print("GET ");
client.print(page);
client.print(" HTTP/1.1\r\n");

client.print("Host: ");
client.print(serverName);
client.print("\r\n");

// etc.
