NRF24L01     Mega2560
----------   ----------------

  VCC         3.3V pin
  Gnd         Gnd
  CSN         D10 
  CE          D9
  MOSI        D51 - (MOSI) 
  SCK         D52 - (SCK)  
  IRQ         N/C
  MISO        D50 - (MISO)
