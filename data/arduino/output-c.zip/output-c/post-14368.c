enum { timelen=44, maxpause=50000 };
unsigned long int times[timelen];

int collectData() {
  byte ntimes = 0, state=LOW;
  unsigned long int prevtime;
  pinMode(dataPin, OUTPUT);
  digitalWrite(dataPin, LOW ); // Pull DTR low to trigger conversion
  delay(500);
  pinMode(dataPin, INPUT_PULLUP); // Release DTR and set pullup
  delay(1);           // Let TX23U pull DTR low
  prevtime = micros();
  while (micros() - prevtime < maxpause && ntimes < timelen) {
    if (digitalRead(dataPin) != state) {
      times[ntimes++] = prevtime = micros();
      state = 1-state;
    }
  }
  return ntimes;
}
