if (everything_is_working()) {
  if (millis()%10000<1000) {
     <turn led on>
  } else {
     <turn led off>
  }
}
