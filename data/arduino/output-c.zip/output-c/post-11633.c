switch (results.value) {
  case "0x2E3A06C0":
    main = 1;
    Serial.println("MAIN: on");
    break;
  case "0x8C2921D6":
    left = 1;
    Serial.println("LEFT: on");
    break;
  case "0x226270DA":
    right = 1;
    Serial.println("RIGHT: on");
    break;
  case "0x4AC6E6A":
    main = 0;
    Serial.println("MAIN: off");
    break;
