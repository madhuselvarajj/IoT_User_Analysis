class Motor {
    private:
        int _speedPin;
        int _directionPin1;
        int _directionPin2;

    public:
        Motor(int sp, int dp1, int dp2) {
            _speedPin = sp;
            _directionPin1 = dp1;
            _directionPin2 = dp2;
        }
        void begin() {
            analogWrite(_speedPin, 0);
            pinMode(_directionPin1, OUTPUT);
            pinMode(_directionPin2, OUTPUT);
            digitalWrite(_directionPin1, LOW);
            digitalWrite(_directionPin2, LOW);
        }
        void forward() {
            digitalWrite(_directionPin1, HIGH);
            digitalWrite(_directionPin2, LOW);
        }
        void reverse() {
            digitalWrite(_directionPin1, LOW);
            digitalWrite(_directionPin2, HIGH);
        }
        void speed(int speed) {
            analogWrite(_speedPin, speed);
        }
        void stop() {
            analogWrite(_speedPin, 0);
            digitalWrite(_directionPin1, LOW);
            digitalWrite(_directionPin2, LOW);
        }
};
