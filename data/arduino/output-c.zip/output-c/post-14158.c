#include <SPI.h>
#include <Mirf.h>
#include <MirfHardwareSpiDriver.h>
#include <MirfSpiDriver.h>
#include <nRF24L01.h>

const int buttonPin = 2;   
const int ledPin =  3;

// sends a string via the nRF24L01
void transmit(const char *string)
{
  byte c; 

  for( int i=0 ; string[i]!=0x00 ; i++ )
  { 
    c = string[i];
    Mirf.send(&c);
    while( Mirf.isSending() ) ;
  }
}

void setup() {
  //RADIO
  Serial.begin(9600);
  Mirf.spi = &MirfHardwareSpi;
  Mirf.init();
  Mirf.payload = 1;
  Mirf.channel = 90;
  Mirf.config();
  Mirf.configRegister(RF_SETUP,0x06);
  Mirf.setTADDR((byte *)"serv1");

  //BUTTON AND LED
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(ledPin, OUTPUT);

  Serial.println("Sending ... ");   
}

void loop() {
  int buttonState = digitalRead(buttonPin);
   if (buttonState == LOW) { //pressed
    digitalWrite(ledPin, HIGH);
    transmit("X");
  }
  else {
    digitalWrite(ledPin, LOW);
  }
}
