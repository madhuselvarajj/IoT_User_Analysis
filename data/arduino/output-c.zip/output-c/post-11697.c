    #include <IRremote.h>

    int RECV_PIN = 11;
    int relay1 = 2;
    int relay2 = 3;
    int relay3 = 4;

    int on = 1;
    int on1 = 1;
    int on2 = 1;

    IRrecv irrecv(RECV_PIN);
    decode_results results;

    void setup()
    {
      digitalWrite(relay3, HIGH);
      pinMode(relay3, OUTPUT);
      digitalWrite(relay2, HIGH);
      pinMode(relay2, OUTPUT);
      digitalWrite(relay1, HIGH);
      pinMode(relay1, OUTPUT);
      pinMode(13, OUTPUT);
      irrecv.blink13(true);
      irrecv.enableIRIn();
    }

    unsigned long last = millis();

    void loop() {
      if (irrecv.decode(&results)){
        if (results.value == 0x36167A85) {
          if (millis() - last > 250) {
            on = !on;
            digitalWrite(relay1, on ? HIGH : LOW);
          }
          last = millis();
        } else if (results.value == 0x36161AE5) {
          if (millis() - last > 250) {
            on1 = !on1;
            digitalWrite(relay2, on1 ? HIGH : LOW);
          }
             last = millis();
        } else if (results.value == 0x3616FA05) {
         if (millis() - last > 250) {
            on2 = !on2;
            digitalWrite(relay3, on2 ? HIGH : LOW);
          }
            last = millis();
        }
        irrecv.resume();
      }  
    }
