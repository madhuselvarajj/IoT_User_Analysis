uart.h:
unsigned char read(char* string);

uart.c:
unsigned char uart::read(unsigned char* string){
