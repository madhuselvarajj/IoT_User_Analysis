leds[0]
leds[1]
leds[2]
... etc to ...
leds[12]
leds[13]
