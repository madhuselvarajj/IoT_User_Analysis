#include <SdFat.h>

// SD card read/write
// MOSI - pin 11
// MISO - pin 12 
// CLK  - pin 13
// CS   - pin 4
const int chipSelect = 4;

SdFat sd;
SdFile myFile;

int idx = 0;

void setup() {
  Serial.begin(115200);

  if (!sd.begin(chipSelect, SPI_HALF_SPEED)) 
    sd.initErrorHalt();

  // dynamic filename
  char filename[11];
  sprintf(filename, "acc_%d.txt", idx);
  Serial.print("filename :");
  Serial.println(filename);

  // open the file for write at end like the Native SD library
  if (!myFile.open(filename, O_RDWR | O_CREAT | O_AT_END)) 
    sd.errorHalt("opening att_0.txt for write failed");        

  Serial.println ("File opened OK");
  myFile.close ();  
}

void loop() 
{
}
