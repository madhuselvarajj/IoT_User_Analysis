switch (state) {
    case 1:
        if (value >= 20 && value < 30)
             state = 2;
        break;
     case 2:
        if (value < 20)
             state = 1;  // initial state
        else if (value >= 20 && value < 30)
             state = 3; // or call a function
        break;
     case 3:
          doSomething();
          break;
}
