String content;
void loop()
{  
    while(Serial1.available()) {
       character = Serial1.read();
       content.concat(character);
     }

if (content == "download")
{
    Serial1.println(content);
    content = "";
    read_from_SD_Card();
    }

........................
    ........................
    ........................
}//end of loop()


read_from_SD_Card(){
    myFile = SD.open("test.txt");
    if (myFile) {
        Serial1.println("test.txt:");

        while (myFile.available()) {
            Serial1.print(myFile.read());
      }
      myFile.close();
    } 
else {
  Serial1.println("error opening test.txt");
  }
  Serial1.readString()//to flush the serial buffer.
}
