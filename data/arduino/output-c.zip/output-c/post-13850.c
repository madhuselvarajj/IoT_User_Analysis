VS = 5.0       -- supply voltage
VMED = VS / 2  -- 50% duty cycle
VL = VMED - 27.2e-3   -- low voltage as measured
VH = VMED + 29.6e-3   -- high voltage as measured
RES = 4700            -- resistance in ohms
CAP = 10e-6           -- capacitance in farads

T1 = -math.log ( (VS - VH) /VS) * RES * CAP 
T2 = -math.log ( (VS - VL) /VS) * RES * CAP 

print ("T1 =", T1)
print ("T2 =", T2)
print ("diff = ", T1 - T2, "seconds")
