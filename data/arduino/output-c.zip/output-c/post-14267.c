const int NUMBER_OF_ELEMENTS = 2;

const char Message0000 [] PROGMEM = "Item X"; 
const char Message0001 [] PROGMEM = "Item Y"; 

const char * const messages[NUMBER_OF_ELEMENTS] PROGMEM = 
   { 
   Message0000, 
   Message0001, 
   };

void setup ()
  {
  Serial.begin (115200);
  Serial.println ();

  for (int i = 0; i < NUMBER_OF_ELEMENTS; i++)
    {
    char * ptr = (char *) pgm_read_word (&messages [i]);
    char buffer [80]; // must be large enough!
    strcpy_P (buffer, ptr);
    Serial.println (buffer);
    }   // end of for loop

  }  // end of setup

void loop () { } 
