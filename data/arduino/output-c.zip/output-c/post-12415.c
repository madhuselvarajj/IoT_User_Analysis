#define BUTTON 2
boolean not_done = true;

void stopDiameterSetup() {
    // some button debounche code
    ...
    // we are done with setting up the diameter.
    not_done = false;
}
void setup() {
    ...

    // POT reading
    interrupts();
    attachInterrupt();
    while(not_done) {
       attachInterrupt(BUTTON, stopDiameterSetup, CHANGE);
    }       
}
void loop(){
// your loop code
}
