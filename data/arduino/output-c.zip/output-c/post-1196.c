Keep re-reading the pressure sensor until it senses pressure;
Read millis(), add 300000 (# of msec in 5 min) to it's value, and store that;
Keep re-read millis() until it returns a number >= to that stored value;
Read the pressure sensor;
If it senses pressure,
  turn on the alarm;
  do nothing, forever;
Otherwise, start over again;
