void setup(){

  Serial.begin(9600);
  SPI.setBitOrder(MSBFIRST);
  SPI.setDataMode(SPI_MODE1);

/// -----CHANGES--------
  digitalWrite(SLAVESELECT_1,HIGH); //disable device
  pinMode(SLAVESELECT_1,OUTPUT);
/// -------------

  SPI.begin();

  digitalWrite(SLAVESELECT_1,LOW); //Enable device
  SPI.transfer(0x0E);  //Send  Fstart Write Enable to Control Reg 
  SPI.transfer(0x13);
  digitalWrite(SLAVESELECT_1,HIGH);

  digitalWrite(SLAVESELECT_1,LOW);
  SPI.transfer(0xC7);  //Send Frequency to Fstart one byte at a time
  SPI.transfer(0x4C);
  digitalWrite(SLAVESELECT_1,HIGH);

  ...
