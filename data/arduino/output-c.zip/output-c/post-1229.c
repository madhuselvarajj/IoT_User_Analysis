// Needed by library "B"
#include "A.h"
// Needed by your program
#include "B.h"

void setup() {
    // You can use B stuff here
}

void loop() {
    // You can use B stuff here
}
