typedef unsigned char addr_t;

#define NUM_CHILDS  0x02
#define CHILD1_I2C_ADDR         0x10
#define CHILD2_I2C_ADDR         0x02

addr_t childAddr[NUM_CHILDS] = { CHILD1_I2C_ADDR, CHILD2_I2C_ADDR };

void setup ()
  {
  Serial.begin (115200);
  Serial.println ();
  Serial.println(childAddr[0]);
  Serial.println(childAddr[1]); 
  }  // end of setup

void loop ()
  {
  }  // end of loop
