static myLib *globalLib;
void globalConfigWriter( unsigned long address, byte data ) {
    globalLib->congigWriter(address, data);
}
byte globalConfigReader( unsigned long address ) {
    return globalLib->configReader(address);
}
