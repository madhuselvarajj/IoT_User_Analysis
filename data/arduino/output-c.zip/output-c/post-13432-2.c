void foo (char * s)
  {
  Serial.println (s);
  strcpy (s, "Goodbye");
  }
