#include <Wire.h>

#define SLAVE_ADDR 0x50

void setup()
{
  Wire.begin();
  Serial.begin(9600);
}

void loop()
{
  Wire.requestFrom(SLAVE_ADDR, 1);

  if (Wire.available())
  { 
    byte byteReceived = Wire.read();
    Serial.println(byteReceived, DEC);
  }

 delay (1000);
}
