Uno    ATtiny85
--------------------
A4      pin 5  (SDA)
A5      pin 7  (SCL)
+5V     pin 8
Gnd     pin 4
