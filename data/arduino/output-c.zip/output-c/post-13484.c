for (uint8_t i = 0; i < 8; i++) {
    if (i == value) {
        digitalWrite(ledPin[i], HIGH);
    } else {
        digitalWrite(ledPin[i], LOW);
    }
}
