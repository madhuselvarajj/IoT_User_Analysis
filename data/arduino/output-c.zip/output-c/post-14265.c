if (analogRead(1)<385)
      Serial.print("0");
   else
      Serial.print("5");
      Serial.print('  ');
