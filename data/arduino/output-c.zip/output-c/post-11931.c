forever,
  for each digital I/O pin:
    write high;
    delay 100ms;
    write low;
  end;

  write "Hello, World!\n" to serial output;
  while serial character available,
    write character to serial output;
  end;
  write "\n" to the serial output;
end;
