#include <dht.h>
#include <SPI.h>
#include <Ethernet.h>
EthernetClient client;
byte mac[] = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED };
char server[] = "192.168.0.101";
dht DHT;
int interval = 5000; // Wait between dumps
#define DHT11_PIN 2
void setup()
{
  Ethernet.begin(mac);
  Serial.begin(115200);

  //Serial.println("Humidity (%),\tTemperature (C)");
}
void loop()
{
  Serial.print("Temperature2 = ");
    Serial.print(DHT.temperature);
    Serial.println(" *C");

    Serial.print("Humidity = ");
    Serial.print(DHT.humidity);
    Serial.println(" ");

  // READ DATA
  //Serial.print("DHT11, \t");
  int chk = DHT.read11(DHT11_PIN);

  if (client.connect(server, 80)) {

    client.print( "GET /diplomna/Arduino/add_data.php?");
    client.print("temperature=");;
    client.print( DHT.temperature );
    client.print("&&");
    client.print("humidity=");
    client.println( DHT.humidity );
    client.println( "HTTP/1.1");
    client.println( "Connection: close" );
    client.stop();
    Serial.println("CONNECTED");
  }
  else {
    // you didn’t get a connection to the server:
    Serial.println("–> connection failed/n");
  }
  delay(interval);
}
