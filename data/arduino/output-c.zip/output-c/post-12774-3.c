#define MAX_DIST 5     // these could also be 'const int's
#define MAX_AVRG 3     // but my preference is this way

int dist[MAX_DIST];    // create an array, no need to initialise.
int distIterator = 0;  // 'dist' will be a CYCLIC BUFFER. woooOOOOooo.
int distAvrg[MAX_DIST]; // create an array of averages.
int avrgIterator = 0;  // wwwwoooOOOOooo ? Not this time.

// There's no single 'distAverage' anymore; the result dumps straight
//into 'distAvrg[avrgIterator]'...

dist[distIterator] = microsecondsToCentimeters(duration);
distIterator++;
if (distIterator == MAX_DIST) distIterator = 0;
distAvrg[avrgIterator] = 0.0;
for (int x=0; x<MAX_DIST; x++)
    distAvrg[avrgIterator] += dist[x];
distAvrg[avrgIterator] /= MAX_DIST;
avrgIterator++;
if (avrgIterator == MAX_AVRG) avrgIterator = 0;
