                   if(add == 33)
                    {                 
                    a1 = func1();
                    b = a1.length();  
                    if(b != 0)
                   {
                    Zigbee=1;
                    if(a1!=c1)
                    {
                    Serial.print("DATA,TIME,"); Serial.print(Zigbee);                     
                    Serial.print(","); Serial.println(a1);
                    }
                    c1=a1;
                    row++;              
                    }
                    }
                  else if(add == 48)
                    { 
                    a2 = func1();
                    b = a2.length();
                    if(b != 0) 
                  { 
                    Zigbee=2;
                    if(a2!=c2){
                   Serial.print("DATA,TIME,"); Serial.print(Zigbee);                     
                   Serial.print(","); Serial.println(a2);
                    }
                    c2=a2;
                   row++;                                          
                    }
                    }

                   else if(add == 69)
                    {
                      a3 = func1();
                      b = a3.length();
                      if(b != 0)
                     {
                      Zigbee=3;
                      if(a3!=c3)
                     {
                      Serial.print("DATA,TIME,"); Serial.print(Zigbee);                     
                      Serial.print(","); Serial.println(a3);
                     }
                     c3=a3;
                     row++;                  
                }
                    }
