SoftwareSerial mySerial(4, 5); // RX, TX

void setup(){ 
    mySerial.begin(9600);
}

void loop(){
    mySerial.print("HelloWurld");
}
