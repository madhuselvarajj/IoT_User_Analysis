#include <ctype.h>
void operateRelays(char *cmdList) {
  char *joints = "BSEWG", *c=cmdList, *j;
  byte relay, delaytenths= 0;

  while (*c && isdigit(*c)) // Get # of tenths-of-seconds to delay
    delaytenths = 10*delaytenths + *c-'0';

  for (; *c; ++c) {
    while (*c && !isalpha(*c)) ++c; // Ignore non-alphas before joint
    if (!*c) break;     // At end of command list, break
    for (j=joints; *j; ++j)
      if (toupper(*c) == *j) break;
    if (!*j) break;     // Ab-exit if joint-letter not found
    if (!*(++c)) break;     // Advance to + or -
    relay = 2*(j-joints) + 1 + (*c != '+'); // The last term is 0 or 1
    digitalWrite(relay, HIGH);
    // If relay numbers aren't contiguous as in question, just use
    // an array (like: byte relays[] = {2,1,5,4,6,3,7,9,10,8};)
    // and in above statement say digitalWrite(relays[relay-1], HIGH);.
  }    
  delay (100*delaytenths); // Wait specified time
  for (relay=1; relay<11; ++relay) // Turn motors off
    digitalWrite(relay, LOW);
}
