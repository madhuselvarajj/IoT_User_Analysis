class Esp8266 {
  public:
    Esp8266(Stream & wifiCom, Stream & debugCom)
      : wifiCom_ (wifiCom), debugCom_ (debugCom) { }

  private:
    Stream & wifiCom_;
    Stream & debugCom_;
  };

Esp8266 esp (Serial, Serial1);

void setup ()
{
  Serial.begin (115200);
  while (!Serial) { }
  Serial1.begin (115200);
  while (!Serial1) { }
}  // end of setup

void loop ()
{
}  // end of loop
