/*
 * Returns the requested frequency, or 0 if nothing valid is found.
 */
static int parse_request(char *request) {

    /* The "GET" should be at the very beginning. */
    if (strncmp(request, "GET /blink?f=", 13) != 0)
        return 0;

    return atoi(request + 13);
}
