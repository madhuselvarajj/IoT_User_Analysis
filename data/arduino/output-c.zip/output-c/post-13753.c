while (dataFile.available()) {
  char readByte = dataFile.read();
  Serial.write(readByte);
  lcd.write(readByte);
  lcd.print(readByte);
}
