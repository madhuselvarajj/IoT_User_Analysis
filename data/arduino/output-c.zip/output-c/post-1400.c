   if (client.connect(server, port)) 
     { 
       ....... 
       client.disconnect( .... );
      }
  else 
........
