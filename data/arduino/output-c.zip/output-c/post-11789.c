#define btnRIGHT  0
#define btnUP     1
#define btnDOWN   2
#define btnLEFT   3
#define btnSELECT 4
#define btnNONE   5
int lcd_key     = 0;

void loop()
{
 setClock();

 /**
 * After set clock now you have 3 int variables with the current time
 */
 //seconds
 //minutes
 //hours
 printValueAtLine(0);

 lcd_key = read_LCD_buttons();  // read the buttons

 switch (lcd_key)
 {
   case btnSELECT:
   {
     printValueAtLine(1);
     break;
   }
   case btnRIGHT:
   {
     // code in case other buttons like  btnRIGHT, etc are pressed
     break;
   }
   case btnNONE:
   {
     //do nothing
     break;
   }
 }
}

void printValueAtLine(int line)
{
 lcd.setCursor (1, line);
 lcd.print(hours);
 lcd.print(":");
 lcd.print(minutes);
 lcd.print(":");
 lcd.print(seconds);
 lcd.print(":");
 lcd.print(elapsedMillis);
}
