const int LED = 13;

void setup() 
  {
  pinMode (LED, OUTPUT);
  }

void loop() 
  {
  int amount = analogRead (A0);   // get a reading
  digitalWrite(LED, HIGH);
  delay(amount);
  digitalWrite(LED, LOW);
  delay(amount);
  }
