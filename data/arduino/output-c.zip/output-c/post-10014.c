#define SPI_ISR_RAN 0x00
static volatile uint8_t flagByte;

void loop(){
    func();
}

void func(){
    uint8_t indicator;
    do {
        // Do something

        //Check for SPI condition
        ATOMIC_BLOCK(ATOMIC_RESTORESTATE){ //Atomic access is required
            indicator = flagByte;
        }
    }while( !(indicator & 1<<SPI_ISR_RAN) );

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
        flagByte &= ~(1<<SPI_ISR_RAN); //Don't forget to clear the flag!
    }
}

ISR(SPI_STC_vect){
    // Do ISR necessities

    // Set flag when appropriate            
    flagByte & 1<<SPI_ISR_RAN;            
}    
