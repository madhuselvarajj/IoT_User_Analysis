String inStr = "Temperature: 28.22C";
int indexOfSpace = inStr.indexOf(' ');
//this stores the address of the space character in the string.
int indexOfC = inStr.indexOf('C');

String Temp = inStr.substring(indexOfScace+1,indexOfC);
//as the parameter for the function is supposed to be the starting point of the string to
 be extracted and one more than its ending point.


//Now to convert to float

float TempFlo = Temp.toFloat();
