const char* const months[] PROGMEM = 
    {
            "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };

const uint8_t days_of_month[] PROGMEM = 
    {
        31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
    };
