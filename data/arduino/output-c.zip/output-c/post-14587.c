typedef struct {
   int a;
   int b;
} pair;


int init_pair(pair *ptr) {
   if (!ptr)
      return -1;
   ptr->a = 6;
   ptr->b = 9;
   return 0;
}

int do_something() {
   pair mypair;
   return init_pair(&mypair);
}
