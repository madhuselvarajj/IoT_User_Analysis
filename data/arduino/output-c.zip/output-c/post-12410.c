if (number == 1) {
    digitalWrite(leda,  LOW);
    digitalWrite(ledb, HIGH);
    digitalWrite(ledc, HIGH);
    digitalWrite(ledd,  LOW);
    digitalWrite(lede,  LOW);
    digitalWrite(ledf,  LOW);
    digitalWrite(ledg,  LOW);
}
