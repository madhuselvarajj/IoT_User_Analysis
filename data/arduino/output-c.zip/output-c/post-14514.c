#define trigPin 6
#define echoPin 4
#define echoPin2 7

void setup() {
  Serial.begin (9600);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
   pinMode(echoPin2, INPUT);
}

void loop() {
  long duration, distance, distance2;
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(20);
  digitalWrite(trigPin, LOW);
  duration = pulseIn(echoPin, HIGH);
  distance = (duration/2) / 29.1;
  duration = duration + pulseIn(echoPin2, HIGH);
  distance2 = (duration/2) / 29.1;
  if (distance >= 200 || distance <= 0){ 
    Serial.println("Out of range");
  }
  else {
    Serial.print(distance);
    Serial.println("cm");
       Serial.print(distance2);
    Serial.println(" cm");
        Serial.println("HHH");
  }
  delay(500);
}
