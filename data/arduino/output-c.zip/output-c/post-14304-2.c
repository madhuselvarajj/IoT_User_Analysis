//              MIDI_Input_0x02


#include <SoftwareSerial.h>             //The Attiny does not natively support the Serial library so this
                        //is the work-around.
SoftwareSerial mySerial(0,1);

const int latchPin = 2;
const int clockPin = 3;
const int dataPin = 4;

const int gate = 1;             //Note that initially, this was the tx pin.
                                //In this configuration absolutely every Attiny85 pin is used.
int isStatus();
int isAftertouch();
int isRealTimeCategory();

int result;
int dataByte;
int velocityByte;

//int noteApprox[13] = {1,3,5,7,9,12,14,17,20,23,26,29,32};
int noteApprox[13] = {32, 29, 26, 23, 20, 17, 14, 12, 9, 7, 5, 3, 1};
    //The above numbers are approximately 100 cents
    //apart from one another. This corresponds to notes of a scale.
    //They descend here because their corresponding
    //voltages will later become inverted in the circuit.

void setup()
{
  mySerial.begin(31250);

  pinMode(latchPin, OUTPUT);
  pinMode(clockPin, OUTPUT);
  pinMode(dataPin, OUTPUT);  
  pinMode(gate, OUTPUT);        //'Gate' controls the level of the
                    //envelope generators. The signal
                    //becomes inverted later.

  digitalWrite(gate, HIGH);     //A simple test to ensure the
  delay(1000);              //circuit is wired correctly
  digitalWrite(gate, LOW);
  delay(1000);

}

void loop()
{

  while(mySerial.available())
  {
    //This is the protocol for reading new stuff
    byte myByte = mySerial.read();      //Read the oldest byte in the buffer
    if(isRealTimeCategory(myByte))      //See Function Notes
    {
      ;
    }
    else
    {
      if(isStatus(myByte))               //See Function Notes
      {
        result = (myByte | 0x80);       //0b10000000
        switch(result)
        {
          case 0b10000000:
            digitalWrite(gate, LOW);            //0b10000000 is the note Off
            break;                      //message
          case 0b10010000:
            digitalWrite(gate, HIGH);           //10010000 is the note On
            break;                      //message
          case 0b10100000:          //Absolutely none of these are important.
            break;
          case 0b10110000:
            break;
          case 0b11000000:
            break;
          case 0b11010000:
            break;
          case 0b11100000:
            break;
          case 0b11110000:
            break;
        }
      }
      else                                     //This is the part where I assume it's a data byte.
      {                                        //this might be causing problems...
        if( (myByte > 48) && (myByte < 61) )         //<-- That's 13 notes. An octave and an extra 
        {
          digitalWrite(latchPin, LOW);
          shiftOut(dataPin, clockPin, MSBFIRST, noteApprox[myByte - 48]);   //Write to the shift
          digitalWrite(latchPin, HIGH);                     //register.
        }
        else
        {
          digitalWrite(gate, LOW);
        }

        byte myByte = mySerial.read();
        if(isRealTimeCategory(myByte))
        {
          ;
        }
        else
        {
          if(myByte > 0)                
      {
        digitalWrite(gate, HIGH);  //Velocity Byte
      }
      else
      {
        digitalWrite(gate, LOW);
          }
        }
      }
    }
  }
}  //END

/***************************
    function Declarations
***************************/

int isStatus(int b)         //Determines if the incoming byte is a Status Byte of some sort.
                    //Returns 1 if so and 0 if not.
{
  if( (b & 0x80) == 0x80)
  {
    return 1;
  }
  else if( (b & 0x80) == 0)
  {
  return 0;
  }
}   

int isRealTimeCategory(int b)           //Determines if the incoming byte is a Real Time Category byte
  {                 //I'm not positive what these *are* but they are only 1 byte long
    if(b >= 0xF8)           //a piece and easily detected (they're all greater than 11111000).
    {                           
      return 1;
    }
    else
    {
      return 0;
    }
}

/*              Bit Math Notes

    if(b & 0x80) == 0x80)

b    =  10000000
0x80 =  10010000
      & ________
        10000000 =/= 10010000

        Not a Note On byte. 
        Return 0.


b    =  10010000
0x80 =  10010000
      & ________
        10010000 == 10010000

        A Note On byte! Hooray!
        Return 1. 
*/
