// For Atmega328 (eg. Uno)

const int BUTTONS = 4;
const int FIRST_BUTTON = 2;
const int FIRST_RELAY =  8;  
const int CLICKS = 5;
const unsigned long DEBOUNCE_TIME = 20;  // ms

int retardo  = 300;
int finBoton = 1000;

volatile bool oldState [BUTTONS];
volatile byte counts [BUTTONS];
unsigned long lastPress;

// handle pin change interrupt for D0 to D7 here
ISR (PCINT2_vect)
 {

 // debounce
 if (millis () - lastPress < DEBOUNCE_TIME)
   return;

 lastPress = millis ();

 // check each switch
 for (int i = 0; i < BUTTONS; i++)
   {
   byte state = digitalRead (FIRST_BUTTON + i);
   if (state != oldState [i])
     {
     oldState [i] = state;  // detect state changes
     if (state == LOW)
       counts [i]++;
     }   // end of state change
   }  // end of for each button

 }  // end of PCINT2_vect


void setup() 
  {

  // configure inputs / outputs
  for (int i = 0; i < BUTTONS; i++)
    {
    pinMode (FIRST_BUTTON + i, INPUT_PULLUP);
    oldState [i] = HIGH;
    pinMode (FIRST_RELAY + i, OUTPUT);
    }

  // pin change interrupt (example for D9)
  PCMSK2 |= bit (PCINT18) | bit (PCINT19) | bit (PCINT20) | bit (PCINT21);  // want pins 2, 3, 4, 5
  PCIFR  |= bit (PCIF2);   // clear any outstanding interrupts
  PCICR  |= bit (PCIE2);   // enable pin change interrupts for D0 to D7
  } // end of setup

// turn relay on for a particular switch
void handleSwitchPress (const int which)
  {
  for (int i = 0; i < CLICKS; i++)
  {
    digitalWrite(FIRST_RELAY + which, HIGH);
    delay(retardo);
    digitalWrite(FIRST_RELAY + which, LOW);
    delay(retardo);
  }
  delay(finBoton);
  } // end of handleSwitchPress

// main loop
void loop()
  {
 for (int i = 0; i < BUTTONS; i++)
   if (counts [i] > 0)
     {
     handleSwitchPress (i);
     counts [i]--;  
     }
  }  // end of loop
