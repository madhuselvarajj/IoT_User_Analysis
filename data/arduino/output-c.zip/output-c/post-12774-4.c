int direction = 0;
for (x=oldest ... x=newest)
{
    if (x > x+1) direction++;
    if (x < x+1) direction--;
}
