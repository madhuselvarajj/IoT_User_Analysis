int readVBG(int _analogReference) {
  uint8_t low, high;
  ADMUX = (_analogReference << 6) | 14;
  delay(2); // Wait for voltage to settle
  sbi(ADCSRA, ADSC);
  while (bit_is_set(ADCSRA, ADSC));
  low  = ADCL;
  high = ADCH;
  return (high << 8) | low;
}
