const byte READ_PIN = 2;
const byte NUMBER_OF_CHANGES = 48;

volatile unsigned long bitTime [NUMBER_OF_CHANGES];
volatile byte state [NUMBER_OF_CHANGES];
volatile byte count;

void stateChange ()
  {
  unsigned long now = micros ();
  if (count >= NUMBER_OF_CHANGES)
    return;  // array full
  state [count] = digitalRead (READ_PIN);
  bitTime [count++] = now;
  } // end of stateChange

void setup ()
  {
  Serial.begin (115200);
  Serial.println ();
  }  // end of setup

void takeReading ()
  {
  count = 0;
  digitalWrite (READ_PIN, LOW);  // start reading
  pinMode (READ_PIN, OUTPUT);   
  delay (20);  // pulse width
  pinMode (READ_PIN, INPUT);     // release line
  EIFR = bit (INTF0);  // clear flag for interrupt 0
  attachInterrupt (0, stateChange, CHANGE);
  delay (55);  // let readings fill up array
  detachInterrupt (0);
  }  // end of takeReading

void loop ()
  {
  takeReading ();
  if (count == 0)
    return;  // nothing!

  delay (500);
  for (byte i = 0; i < count; i++)
    {
    Serial.print ("count: ");
    Serial.print ((int) i);
    Serial.print (" = ");
    Serial.print (bitTime [i]);
    Serial.print (", state = ");
    Serial.print (state [i]);
    if (i > 0)
      {
      Serial.print (", width = ");  
      unsigned long width = bitTime [i] - bitTime [i - 1];
      Serial.print (width);
      Serial.print (" (");
      int bits = width / 1000;
      for (byte k = 0; k < bits; k++)
       Serial.print (state [i - 1]);
      Serial.print (")");
      }
    Serial.println ();
    }
    Serial.println ();
  }  // end of loop
