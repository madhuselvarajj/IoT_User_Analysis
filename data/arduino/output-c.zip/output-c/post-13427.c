char key [20] = "This is a key";
char keypadInput [16];  // whatever they entered

char plain[80];

strcpy (plain, "This is the keypad input");
strcat (plain, keypadInput);
strcat (plain, "and some other random stuff");
