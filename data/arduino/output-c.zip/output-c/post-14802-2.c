#include <EEPROM.h>

const int SERIAL_NUMBER_ADDRESS = 1023;
byte serialNumber;
void setup ()
  {
  Serial.begin (115200);
  Serial.println ();
  serialNumber = EEPROM.read(SERIAL_NUMBER_ADDRESS);
  Serial.print (F("Serial number of this board is: "));
  Serial.println (int (serialNumber));
  }  // end of setup

void loop () { }
