const uint8_t x = A3;    // select the input pin for the switch
const uint8_t y = A4;
const uint8_t z = A5;

const uint8_t ledPin[8] = { 2, 3, 4, 7, 8, 9, 12, 13 };

void setup() {
    for (uint8_t i = 0; i < 8; i++) {
        pinMode(ledPin[i], OUTPUT);
    }
    pinMode(x, INPUT);
    pinMode(y, INPUT);
    pinMode(z, INPUT);
}

void loop() {
    uint8_t value = digitalRead(x) | (digitalRead(y) << 1) | (digitalRead(z) << 2);
    for (uint8_t i = 0; i < 8; i++) {
        digitalWrite(ledPin[i], i == value);
    }
}
