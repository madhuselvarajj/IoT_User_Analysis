#include "MertBus.h" //include header

#define TXEN 13  //transmit-enable pin
#define SELF_ID 1  //id of this node

MertBus mb;  //communicator class

void setup() {
   Serial.begin(57600); //prepare the serial port as usual
   Serial.println("Begin init");
   //then initialize mertbus instance with port, pin and id
   mb = MertBus(Serial,TXEN,SELF_ID); 
}

void loop() {
  if(mb.checkData()) {    //check if and valid data received
    // reply to sender char[] and length, 26 chars
    mb.reply("Incoming Data (SendData): ",26); 
    // reply to sender the received data
    mb.reply(mb.Buffer,mb.ReceiveCount);
  } else {
    digitalWrite(13,HIGH);
    delay(400);
    digitalWrite(13,LOW);
    delay(400);
  }
}
