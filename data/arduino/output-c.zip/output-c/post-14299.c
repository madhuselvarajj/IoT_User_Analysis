float FeqIn, FeqIn1, FeqIn2, FeqIn3, FeqOut, w, Triarea, Recarea, area, n, y, t;

...

      Triarea(n+1) = (0.5*t(2))*(FeqIn3(n+1) - FeqIn3(n));
