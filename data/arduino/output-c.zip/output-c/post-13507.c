int input_pin_blue = 5;
int input_pin_yellow = 6;
volatile int state_button_red = LOW;
volatile int state_button_blue = LOW;
volatile int state_button_yellow = LOW;
...
pinMode(input_pin_blue, INPUT);
pinMode(input_pin_yellow, INPUT);
...
attachInterrupt(0, handler_red, CHANGE);
attachInterrupt(1, handler_blue_yellow, CHANGE);


// interrupt handler function
void handler_red() {
    state_button_red = !state_button_red;
}
void handler_blue_yellow() {
    if (digitalRead(input_pin_blue) == HIGH) {
        state_button_blue = !state_button_blue;
    }

    if (digitalRead(input_pin_yellow) == HIGH) {
        state_button_yellow = !state_button_yellow;
    }
}
