  // clean up screen before printing a new reply
  lcd.clear();

  /* --- first line on LCD --- */
  /*** RTC ***/  
  // set the cursor to LCD column 4, line 0 to center the clock
  lcd.setCursor(4, 0);
