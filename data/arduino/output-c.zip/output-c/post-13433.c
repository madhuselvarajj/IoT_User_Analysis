char array[256];

...

int i;
for( i=0; i<256;i++ ) {
    array[i] = 0x00;
}
