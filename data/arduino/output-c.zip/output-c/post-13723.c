  SPI.transfer(CMD_ADC_READ); // send ADC read command
  SPDR = SPI.transfer(0x00); // send 0 to read 1st byte (MSB)
  ret = SPDR;
  temp = 65536 * ret;
  SPDR = SPI.transfer(0x00); // send 0 to read 2nd byte
  ret = SPDR;
  temp = temp + 256 * ret;
  SPDR = SPI.transfer(0x00); // send 0 to read 3rd byte (LSB)
