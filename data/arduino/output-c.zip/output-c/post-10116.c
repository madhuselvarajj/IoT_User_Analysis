String previousString = "";
String newString = "";

if(newString != previousString){
   println(newString);
   previousString = newString;
}
