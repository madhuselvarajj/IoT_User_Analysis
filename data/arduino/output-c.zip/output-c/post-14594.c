  LifeTest(int pin, long on, long off)
  {
    motorPin = pin;
    OnTime = on;
    OffTime = off;

    previousMillis = 0;

    motorState = HIGH;
    pinMode(motorPin, OUTPUT);
    digitalWrite(motorPin, motorState);
  }
