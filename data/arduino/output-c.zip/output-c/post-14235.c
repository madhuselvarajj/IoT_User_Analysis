    =========================== USB Port1 ===========================

Connection Status        : 0x01 (Device is connected)
Port Chain               : 1-1-3-1

      ======================== USB Device ========================

        +++++++++++++++++ Device Information ++++++++++++++++++
Device Description       : USB Composite Device
Device Path              : \\?\usb#vid_2341&pid_8037#7&171b751b&0&1#{a5dcbf10-6530-11d2-901f-00c04fb951ed}
Device ID                : USB\VID_2341&PID_8037\7&171B751B&0&1
Driver KeyName           : {36fc9e60-c465-11cf-8056-444553540000}\0026 (GUID_DEVCLASS_USB)
Driver                   : C:\Windows\system32\DRIVERS\usbccgp.sys (Version: 6.1.7601.18328  Date: 2013-11-27)
Driver Inf               : C:\Windows\inf\usb.inf
Legacy BusType           : PNPBus
Class                    : USB
Service                  : usbccgp
Enumerator               : USB
Location Info            : Port_#0001.Hub_#0005
Location IDs             : PCIROOT(0)#PCI(1D00)#USBROOT(0)#USB(1)#USB(3)#USB(1)
Container ID             : {821d8eeb-43cd-11e5-b4e1-10c37b50593b}
Manufacturer Info        : (Standard USB Host Controller)
Capabilities             : 0x84 (Removable, SurpriseRemovalOK)
Address                  : 1
Problem Code             : 0
Power State              : D0 (supported: D0, D2, D3, wake from D0, wake from D2)
 Child Device 1          : Arduino Micro
  Device ID              : USB\VID_2341&PID_8037&MI_00\8&6467A9E&0&0000
  Class                  : Ports
  COM-Port               : COM8 (\Device\USBSER000)
 Child Device 2          : USB Input Device
  Device ID              : USB\VID_2341&PID_8037&MI_02\8&6467A9E&0&0002
  Class                  : HIDClass
   Child Device 1        : HID-compliant mouse
    Device ID            : HID\VID_2341&PID_8037&MI_02&COL01\9&F900E83&0&0000
    Class                : Mouse
   Child Device 2        : HID Keyboard Device
    Device ID            : HID\VID_2341&PID_8037&MI_02&COL02\9&F900E83&0&0001
    Class                : Keyboard

        ---------------- Connection Information ---------------
Connection Index         : 0x01 (1)
Connection Status        : 0x01 (DeviceConnected)
Current Config Value     : 0x01
Device Address           : 0x08 (8)
Is Hub                   : 0x00 (no)
Number Of Open Pipes     : 0x04 (4)
Device Bus Speed         : 0x01 (Full-Speed)
Pipe0ScheduleOffset      : 0x01 (1)
Pipe1ScheduleOffset      : 0x00 (0)
Pipe2ScheduleOffset      : 0x00 (0)
Pipe3ScheduleOffset      : 0x00 (0)

        ------------------ Device Descriptor ------------------
bLength                  : 0x12 (18 bytes)
bDescriptorType          : 0x01 (Device Descriptor)
bcdUSB                   : 0x200 (USB Version 2.00)
bDeviceClass             : 0x00 (defined by the interface descriptors)
bDeviceSubClass          : 0x00
bDeviceProtocol          : 0x00
bMaxPacketSize0          : 0x40 (64 bytes)
idVendor                 : 0x2341
idProduct                : 0x8037
bcdDevice                : 0x100
iManufacturer            : 0x01 (String Descriptor 1)
 Language 0x0409         : "Arduino LLC"
iProduct                 : 0x02 (String Descriptor 2)
 Language 0x0409         : "Arduino Micro"
iSerialNumber            : 0x00 (No String Descriptor)
bNumConfigurations       : 0x01

        ------------------ String Descriptors -----------------
             ------ String Descriptor 0 ------
bLength                  : 0x04 (4 bytes)
bDescriptorType          : 0x03 (String Descriptor)
Language ID[0]           : 0x0409 (English - United States)
             ------ String Descriptor 1 ------
bLength                  : 0x18 (24 bytes)
bDescriptorType          : 0x03 (String Descriptor)
Language 0x0409          : "Arduino LLC"
             ------ String Descriptor 2 ------
bLength                  : 0x1C (28 bytes)
bDescriptorType          : 0x03 (String Descriptor)
Language 0x0409          : "Arduino Micro"

        -------------- Configuration Descriptor ---------------
bLength                  : 0x09 (9 bytes)
bDescriptorType          : 0x02 (Configuration Descriptor)
wTotalLength             : 0x0064 (100 bytes)
bNumInterfaces           : 0x03
bConfigurationValue      : 0x01
iConfiguration           : 0x00 (No String Descriptor)
bmAttributes             : 0x80
 D7: Reserved, set 1     : 0x01
 D6: Self Powered        : 0x00 (no)
 D5: Remote Wakeup       : 0x00 (no)
 D4..0: Reserved, set 0  : 0x00
MaxPower                 : 0xFA (500 mA)

        ------------------- IAD Descriptor --------------------
bLength                  : 0x08 (8 bytes)
bDescriptorType          : 0x0B
bFirstInterface          : 0x00
bInterfaceCount          : 0x02
bFunctionClass           : 0x02 (Communications and CDC Control)
bFunctionSubClass        : 0x02
bFunctionProtocol        : 0x01
iFunction                : 0x00 (No String Descriptor)

        ---------------- Interface Descriptor -----------------
bLength                  : 0x09 (9 bytes)
bDescriptorType          : 0x04 (Interface Descriptor)
bInterfaceNumber         : 0x00
bAlternateSetting        : 0x00
bNumEndpoints            : 0x01 (1 Endpoint)
bInterfaceClass          : 0x02 (Communications and CDC Control)
bInterfaceSubClass       : 0x02
bInterfaceProtocol       : 0x00
iInterface               : 0x00 (No String Descriptor)

        -------------- CDC Interface Descriptor ---------------
bFunctionLength          : 0x05 (5 bytes)
bDescriptorType          : 0x24 (Interface)
bDescriptorSubType       : 0x00 (Header Functional Descriptor)
bcdCDC                   : 0x110 (CDC Version 1.10)

        -------------- CDC Interface Descriptor ---------------
bFunctionLength          : 0x05 (5 bytes)
bDescriptorType          : 0x24 (Interface)
bDescriptorSubType       : 0x01 (Call Management Functional Descriptor)
bmCapabilities           : 0x01
bDataInterface           : 0x01

        -------------- CDC Interface Descriptor ---------------
bFunctionLength          : 0x04 (4 bytes)
bDescriptorType          : 0x24 (Interface)
bDescriptorSubType       : 0x02 (Abstract Control Management Functional Descriptor)
bmCapabilities           : 0x06

        -------------- CDC Interface Descriptor ---------------
bFunctionLength          : 0x05 (5 bytes)
bDescriptorType          : 0x24 (Interface)
bDescriptorSubType       : 0x06 (Union Functional Descriptor)
bControlInterface        : 0x00
bSubordinateInterface[0] : 0x01

        ----------------- Endpoint Descriptor -----------------
bLength                  : 0x07 (7 bytes)
bDescriptorType          : 0x05 (Endpoint Descriptor)
bEndpointAddress         : 0x81 (Direction=IN  EndpointID=1)
bmAttributes             : 0x03 (TransferType=Interrupt)
wMaxPacketSize           : 0x0010 (16 bytes) (16 bytes)
bInterval                : 0x40 (64 ms)

        ---------------- Interface Descriptor -----------------
bLength                  : 0x09 (9 bytes)
bDescriptorType          : 0x04 (Interface Descriptor)
bInterfaceNumber         : 0x01
bAlternateSetting        : 0x00
bNumEndpoints            : 0x02 (2 Endpoints)
bInterfaceClass          : 0x0A (CDC-Data)
bInterfaceSubClass       : 0x00
bInterfaceProtocol       : 0x00
iInterface               : 0x00 (No String Descriptor)

        ----------------- Endpoint Descriptor -----------------
bLength                  : 0x07 (7 bytes)
bDescriptorType          : 0x05 (Endpoint Descriptor)
bEndpointAddress         : 0x02 (Direction=OUT  EndpointID=2)
bmAttributes             : 0x02 (TransferType=Bulk)
wMaxPacketSize           : 0x0040 (64 bytes) (64 bytes)
bInterval                : 0x00 (ignored)

        ----------------- Endpoint Descriptor -----------------
bLength                  : 0x07 (7 bytes)
bDescriptorType          : 0x05 (Endpoint Descriptor)
bEndpointAddress         : 0x83 (Direction=IN  EndpointID=3)
bmAttributes             : 0x02 (TransferType=Bulk)
wMaxPacketSize           : 0x0040 (64 bytes) (64 bytes)
bInterval                : 0x00 (ignored)

        ---------------- Interface Descriptor -----------------
bLength                  : 0x09 (9 bytes)
bDescriptorType          : 0x04 (Interface Descriptor)
bInterfaceNumber         : 0x02
bAlternateSetting        : 0x00
bNumEndpoints            : 0x01 (1 Endpoint)
bInterfaceClass          : 0x03 (HID - Human Interface Device)
bInterfaceSubClass       : 0x00 (None)
bInterfaceProtocol       : 0x00 (None)
iInterface               : 0x00 (No String Descriptor)

        ------------------- HID Descriptor --------------------
bLength                  : 0x09 (9 bytes)
bDescriptorType          : 0x21 (HID Descriptor)
bcdHID                   : 0x0101 (HID Version 1.01)
bCountryCode             : 0x00 (00 = not localized)
bNumDescriptors          : 0x01
Descriptor 1:
bDescriptorType          : 0x22 (Class=Report)
wDescriptorLength        : 0x0065 (101 bytes)
  05 01             Usage Page (Generic Desktop Controls)
  09 02             Usage (Mouse)
  A1 01             Collection (Application)
  09 01               Usage (Pointer)
  A1 00               Collection (Physical)
  85 01                 Report ID (0x01)
  05 09                 Usage Page (Buttons)
  19 01                 Usage Minimum (1)
  29 03                 Usage Maximum (3)
  15 00                 Logical Minimum (0)
  25 01                 Logical Maximum (1)
  95 03                 Report Count (3)
  75 01                 Report Size (1)
  81 02                 Input (Var)
  95 01                 Report Count (1)
  75 05                 Report Size (5)
  81 03                 Input (Const, Var)
  05 01                 Usage Page (Generic Desktop Controls)
  09 30                 Usage (Direction-X)
  09 31                 Usage (Direction-Y)
  09 38                 Usage (Wheel)
  15 81                 Logical Minimum (-127)
  25 7F                 Logical Maximum (127)
  75 08                 Report Size (8)
  95 03                 Report Count (3)
  81 06                 Input (Var, Rel)
  C0                  End Collection
  C0                End Collection
  05 01             Usage Page (Generic Desktop Controls)
  09 06             Usage (Keyboard)
  A1 01             Collection (Application)
  85 02               Report ID (0x02)
  05 07               Usage Page (Keyboard)
  19 E0               Usage Minimum (-32)
  29 E7               Usage Maximum (-25)
  15 00               Logical Minimum (0)
  25 01               Logical Maximum (1)
  75 01               Report Size (1)
  95 08               Report Count (8)
  81 02               Input (Var)
  95 01               Report Count (1)
  75 08               Report Size (8)
  81 03               Input (Const, Var)
  95 06               Report Count (6)
  75 08               Report Size (8)
  15 00               Logical Minimum (0)
  25 65               Logical Maximum (101)
  05 07               Usage Page (Keyboard)
  19 00               Usage Minimum (0)
  29 65               Usage Maximum (101)
  81 00               Input ()
  C0                End Collection

        ----------------- Endpoint Descriptor -----------------
bLength                  : 0x07 (7 bytes)
bDescriptorType          : 0x05 (Endpoint Descriptor)
bEndpointAddress         : 0x84 (Direction=IN  EndpointID=4)
bmAttributes             : 0x03 (TransferType=Interrupt)
wMaxPacketSize           : 0x0040 (64 bytes) (64 bytes)
bInterval                : 0x01 (1 ms)
