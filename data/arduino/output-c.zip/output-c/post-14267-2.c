Field::Field(const FieldDefinition* fp ) : _fp(fp) {
  _ndx = 0;
  char * _value = new char[getLength()];
 _copyitem(_ndx);
};
char * Field::selectItem(uint8_t ndx){
  _ndx = ndx;
  _copyitem(_ndx);
  // display item
  // do more here . . .
 return _value;
}
uint8_t Field::getLength(){
  return pgm_read_byte(&_fp->length);
}
void Field::_copyitem(uint8_t ndx){
  PGM_VOID_P plist = pgm_read_ptr(&_fp->list);
  PGM_P pitem = (PGM_P)pgm_read_ptr(plist + ndx * sizeof(char*));
  strlcpy_P(_value, pitem, getLength());
}
