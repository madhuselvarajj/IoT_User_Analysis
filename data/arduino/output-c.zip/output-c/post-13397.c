char array[50] = "hello";
// strlen(array) = 5.
char *array_p = array;
// strlen(array_p) = 5.
char single = 'a';
// strlen(single) = ERROR!  strlen() doesn't operate on single characters.
char string[] = "hello";
// strlen(string) = 5.
