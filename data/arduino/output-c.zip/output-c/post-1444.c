char z = '*';
int s=0;

void setup()
{ 
  // usual initialization  
} 

void loop()
{
  if (client.available())  
  {
    char c = client.read();
    // Serial.print(c);
    if (z == c)
    {
      s=1;
    }

  if(s == 1)
  {
    int i=0;
    k[i] = c;
    i=i+1;
    // Serial.print(k);
  }

  place +=k;

  Serial.print(place);

  }

.......
}
