#include "Timer.h"
[...]
digitalWrite(3, HIGH);
int afterEvent = t.after(5000, doAfter);
[...]
void doAfter() {
  digitalWrite(3, LOW);
}
