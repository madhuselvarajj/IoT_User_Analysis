function pairsByKeys (t, f)
  local a = {}
  -- build temporary table of the keys
  for n in pairs (t) do
    table.insert (a, n)
  end
  table.sort (a, f)  -- sort using supplied function, if any
  local i = 0        -- iterator variable
  return function () -- iterator function
    i = i + 1
    return a[i], t[a[i]]
  end  -- iterator function
end -- pairsByKeys


nums = {233,636,17884,3032,8944,
-- and so on ... 
548,444,552,444,556,444,548,444,552,1440,548,1440,552,1464,500,1496,548}

uniq = { }

for k, v in ipairs (nums) do
  if uniq [v] then
    uniq [v] = uniq [v] + 1
  else
    uniq [v] = 1
  end -- else
end -- for

count = 0

for k, v in pairsByKeys (uniq) do
  print (string.format ("%8i = %3i", k, v))
  count = count + 1
end


print ("count = ", count)
