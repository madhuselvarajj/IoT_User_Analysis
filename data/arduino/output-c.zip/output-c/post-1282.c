Legend:
line 12 = button state check
line 16 = button pressed turn on LED
line 20 = button not pressed turn off LED

=================OUTPUT====================
14:01:04.372 SeeedDuinoPlayground.ino, line 12  loop() 
14:01:04.372 SeeedDuinoPlayground.ino, line 16  loop() 
14:01:04.481 SeeedDuinoPlayground.ino, line 10
14:01:04.481 SeeedDuinoPlayground.ino, line 12  loop()
14:01:04.592 SeeedDuinoPlayground.ino, line 16  loop()
14:01:04.592 SeeedDuinoPlayground.ino, line 10
14:01:04.696 SeeedDuinoPlayground.ino, line 12  loop()
14:01:04.697 SeeedDuinoPlayground.ino, line 20  loop()
14:01:04.804 SeeedDuinoPlayground.ino, line 10
14:01:04.804 SeeedDuinoPlayground.ino, line 12  loop()
14:01:04.912 SeeedDuinoPlayground.ino, line 20  loop()
