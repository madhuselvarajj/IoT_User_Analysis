#include "TinyGPS.h"

#define GPS_BAUD 115200
#define PC_BAUD 115200

TinyGPS gps;

int led1 = 13;

long lat, lon;

unsigned long fix_age, time, date, speed, course;

unsigned long chars;
unsigned short sentences, failed_checksum;

void setup()
{
  pinMode(led1, OUTPUT);
  Serial1.begin(GPS_BAUD);
  Serial.begin(PC_BAUD);
  Serial1.println("");
  Serial1.println("Initializing");
  Serial1.println("");
  digitalWrite(led1, HIGH);
  delay(2000);
  digitalWrite(led1, LOW);
  delay(500);
}

void loop()
{
  while(Serial1.available()){
    if(gps.encode(Serial1.read())){
      digitalWrite(led1, HIGH);
      gps.get_position(&lat, &lon, &fix_age);
      gps.get_datetime(&date, &time);
      Serial.print("    ");
      Serial.print(lat);
      Serial.print(" ");
      Serial.print(long);
    }
  }
}
