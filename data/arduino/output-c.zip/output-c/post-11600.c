pwm.setPWMFreq(1000);//put this in setup()
...
// enable relay at channel 15
pwm.setPWM(15, 1, 0);
...
// disable relay at channel 15
pwm.setPWM(15, 1, 1);
