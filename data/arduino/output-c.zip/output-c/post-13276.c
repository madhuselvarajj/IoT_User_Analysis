volatile unsigned long Data1;//this is the data you are sending
volatile byte SendCount;
volatile uint8_t sendByte;

void requestEvent()
{  

  SendCount++; //increment this
  switch (SendCount)
  {
    case 1:
      Data1 = GetMyData();
      //Data1 = 55555;
      sendByte = Data1 & 0xFF;
      break;
    case 2:
      sendByte = Data1 >> 8;
      break;
    case 3:
      sendByte = Data1 >> 16;
      break;
    case 4:
      sendByte = Data1 >> 24;
      SendCount=0;
      break;
  }

  TinyWireS.send(sendByte);
}
