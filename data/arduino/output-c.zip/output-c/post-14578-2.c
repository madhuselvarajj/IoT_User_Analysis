class Esp8266 {
  public:
    Esp8266(HardwareSerial & wifiCom, HardwareSerial & debugCom);
    void begin();
  private:
    HardwareSerial & wifiCom;
    HardwareSerial & debugCom;
  };

// constructor
Esp8266::Esp8266(HardwareSerial &wifiCom_, HardwareSerial &debugCom_)
  : wifiCom (wifiCom_), debugCom (debugCom_)
  {
  }

// initialize stuff
void Esp8266::begin()
{
  debugCom.begin(115200);
  while (!debugCom)
  {
  }
}

Esp8266 esp (Serial, Serial1);

void setup ()
{
  esp.begin ();
}  // end of setup

void loop ()
{
}  // end of loop
