enum WhatArduinoIs {
  Easy, But, Insane, Obsolete, And, Far, Worse, Than, mBed
};

void TellMe(WhatArduinoIs pls);  // prototype
void TellMe(WhatArduinoIs pls) 
  {
  }
void setup() { }
void loop() { }
