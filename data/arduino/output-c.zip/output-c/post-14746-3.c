for k, v in ipairs (nums) do

  v = math.floor (v / 50)    -- <--- add this
  v = v * 50                 -- <--- add this
  if uniq [v] then
    uniq [v] = uniq [v] + 1
  else
    uniq [v] = 1
  end -- else
end -- for
