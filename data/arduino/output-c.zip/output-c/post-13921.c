void setup ()
  {
  pinMode (13, OUTPUT);
  delay (5000);
  digitalWrite (13, HIGH);
  int foo = analogRead (0);
  }  // end of setup

void loop ()
  {
  }  // end of loop
