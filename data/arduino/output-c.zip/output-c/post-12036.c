template<typename T>
void lcdPositionPrint(int x, int y, T content) throw() {
  lcdPosition(row, col);
  LCD.print(content);
}
