#include "Charliplexing.h"
#include "Myfont.h"

char * test = "full ASCII charset: $ % & ! [ ] { }";
int len; // length of this string

void setup()                    // run once, when the sketch starts
{
  LedSign::Init();
  len = strlen (test);
}

void loop()                     // run over and over again
{
  // start empty
  LedSign::Clear(); 

  int potReading = analogRead (0);  // read A0
  int i = map (potReading, 0, 1023, 0, len * 6);  // starting pixel

  for (int j = 0; j < 14; j += 6) 
    Myfont::Draw(j, test[(i + j) / 6]); 

  delay(100);   // hold that image for a moment

}
