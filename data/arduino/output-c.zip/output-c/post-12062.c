void control()
{
    boolean task1 = digitalRead(led1);
    boolean task2 = digitalRead(led2);

    // Note that the if isn't needed
    digitalWrite(led3, (task1 || task2));

    // If your buttons use negative logic
    // digitalWrite(led3, (!task1 || !task2));
}
