static void waveBitDelay(unsigned baud, unsigned bits, unsigned *bitDelay)
{
   unsigned fullBit, halfBit, s, e, d, m, i, err, t;

   /* scaled 100X */

   fullBit = 100000000 / baud;
   halfBit =  50000000 / baud;

   d = (fullBit/200)*200;

   s = 0;

   e = d;

   t = d/100;
   bitDelay[0] = t ? t : 1;

   err = d / 3;

   for (i=0; i<bits; i++)
   {
      s = e;

      m = halfBit + (i+1)*fullBit;

      e = s + d;

      if ((e-m) < err) e+=200;

      t = (e-s)/100;
      bitDelay[i+1] = t ? t : 1;
   }

   s = e;

   e = ((100*(bits+2)*1000000 / baud)+100)/200*200;

   t = (e-s)/100;
   bitDelay[bits+1] = t ? t : 1;
}
