#include <stdio.h>
#include <stdint.h>

#include <pigpio.h>

#define GPIO 14

int main(int argc, char *argv[])
{
   uint16_t buf[1024];
   int i, wid;

   if (gpioInitialise() < 0) return 1;

   gpioSetMode(GPIO, PI_OUTPUT);

   for (i=0; i<600; i++) buf[i] = i;

   gpioWaveAddSerialX(GPIO, 1000000, 9, 2, 0, 1200, (char*)buf);

   wid = gpioWaveCreate();

   if (wid >= 0)
   {
      printf("ready recorder, then return\n");

      getchar();

      if (wid >= 0) gpioWaveTxSend(wid, 0);

      printf("stop recorder, then return\n");

      getchar();
   }
   else printf("error %d\n", wid);

   gpioTerminate();
}
