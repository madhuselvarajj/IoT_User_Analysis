#include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <pigpio.h>
    #include <string.h>
    #include <time.h>
    #include <sys/time.h>
    
    #define TXD 5 // GPS's TXD to RPI's RX
    #define RXD 17 //  RPI's TX to GPS's RXD
    
    int main()
    {
       char *buf, *errstr;
       gpioPulse_t pulse[2];
       int wave_id, count;
    
       pulse[0].gpioOn = (1<<RXD);
       pulse[0].gpioOff = 0;
       pulse[0].usDelay = 10;
    
       pulse[1].gpioOn = 0;
       pulse[1].gpioOff = (1<<RXD);
       pulse[1].usDelay = 10;
    
       buf = malloc(8);
       errstr = malloc(80);
    
    
       if((buf == NULL) || (errstr == NULL)) /* no memory */ exit(EXIT_FAILURE);
    
       if (gpioInitialise() < 0)
       {
          // pigpio initialisation failed.
          fprintf(stderr, "PIGPIO INITIALISATION FAILED\n");
          return 1;
       }
    
       gpioWaveClear();
    
       gpioSetMode(TXD, PI_INPUT);
    
       gpioSetMode(RXD, PI_OUTPUT);
    
       gpioSerialReadOpen(TXD, 9600, 8);
    
       gpioWaveAddGeneric(2, pulse);
    
       wave_id = gpioWaveCreate();
    
       sprintf(errstr, "%d", wave_id);
    
       strcat(errstr, ":PIGPIO WAVE WASN'T ESTABLISHED\n");
    
       if (wave_id < 0)
       {
          fprintf(stderr, errstr);
          return 1;
       }
    
      // pigpio initialised okey.
    
       gpioWaveTxSend(wave_id, PI_WAVE_MODE_ONE_SHOT); 
    
       while(1)
       {
          count = gpioSerialRead(TXD, buf, 8);
          if (count > 0) fwrite(buf, 8, 1, stdout);
          sleep(1);
       }
    
       gpioWaveTxStop();
    
       gpioSerialReadClose(TXD);
    
       gpioWaveTxStop();
    
       // release memory
       gpioTerminate();
    
       return 0;
    }