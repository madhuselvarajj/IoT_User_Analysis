#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>

#include <pigpio.h>

#define GPIO 4
#define ON   10
#define OFF  10

static int gpio = GPIO;
static int on   = ON;
static int off  = OFF;

gpioPulse_t pulse[2];

void fatal(char *fmt, ...)
{
   char buf[256];
   va_list ap;

   va_start(ap, fmt);
   vsnprintf(buf, sizeof(buf), fmt, ap);
   va_end(ap);

   fprintf(stderr, "%s\n", buf);

   exit(EXIT_FAILURE);
}

void usage()
{
   fprintf(stderr, "\n" \
      "Usage: sudo ./square [OPTION] ...\n" \
      "   -f value, off micros, 1- (%d)\n" \
      "   -g value, gpio, 0-31     (%d)\n" \
      "   -n value, on micros, 1-  (%d)\n" \
      "EXAMPLE\n" \
      "sudo ./square -g 23\n" \
      "  Generate square wave on gpio 23.\n" \
   "\n", OFF, GPIO, ON);
}

static void initOpts(int argc, char *argv[])
{
   int i, opt;

   while ((opt = getopt(argc, argv, "f:g:n:")) != -1)
   {
      i = -1;

      switch (opt)
      {
         case 'f':
            i = atoi(optarg);
            if (i >= 1) off = i;
            else fatal("invalid -f option (%d)", i);
            break;

         case 'g':
            i = atoi(optarg);
            if ((i >= 1) && (i <= 31)) gpio = i;
            else fatal("invalid -g option (%d)", i);
            break;

         case 'n':
            i = atoi(optarg);
            if (i >= 1) on = i;
            else fatal("invalid -n option (%d)", i);
            break;

         default: /* '?' */
            usage();
            exit(EXIT_FAILURE);
        }
    }
}

int main(int argc, char *argv[])
{
   int wid;

   initOpts(argc, argv);

   printf("gpio #%d, on %dus, off %dus\n", gpio, on, off);

   if (gpioInitialise()<0) return -1;

   gpioSetMode(gpio, PI_OUTPUT);

   pulse[0].gpioOn = (1<<gpio);
   pulse[0].gpioOff = 0;
   pulse[0].usDelay = on;

   pulse[1].gpioOn = 0;
   pulse[1].gpioOff = (1<<gpio);
   pulse[1].usDelay = off;

   gpioWaveClear();

   gpioWaveAddGeneric(2, pulse);

   wid = gpioWaveCreate();

   if (wid >= 0)
   {
      gpioWaveTxSend(wid, PI_WAVE_MODE_REPEAT);

      while (1) sleep(1);
   }

   gpioTerminate();
}
