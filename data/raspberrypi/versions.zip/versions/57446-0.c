#include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <pigpio.h>
    #include <string.h>
    #include <time.h>
    #include <sys/time.h>
    
    #define TXD 5 // GPS's TXD to RPI's RX
    #define RXD 17 //  RPI's TX to GPS's RXD
    
    int main()
    {
       //  gpioTerminate();
       char *buf;
       gpioPulse_t pulse[2];
       pulse[0].gpioOn = (1<<RXD);
       pulse[0].gpioOff = 0;
       pulse[0].usDelay = 10;
    
       pulse[1].gpioOn = 0;
       pulse[1].gpioOff = (1<<RXD);
       pulse[1].usDelay = 10;
    
       buf = malloc(8);
    
       int wave_id;
    
       if(buf == NULL) /* no memory */ exit(EXIT_FAILURE);
    
       if (gpioInitialise() < 0)
       {
          // pigpio initialisation failed.
          fprintf(stderr, "PIGPIO INITIALISATION FAILED\n");
           return 1;
       }
    
       gpioWaveClear();
    
       gpioSetMode(TXD, PI_INPUT);
    
       gpioSetMode(RXD, PI_OUTPUT);
    
       gpioSerialReadOpen(TXD, 9600, 8);
    
       gpioWaveAddNew();
    
       gpioWaveAddGeneric(2, pulse);
    
       wave_id = gpioWaveCreate();
    
       char* errstr;
    
       errstr = malloc(100);
       sprintf(errstr, "%d", wave_id);
    
       strcat(errstr, ":PIGPIO WAVE WASN'T ESTABLISHED\n");
    
       if(wave_id < 0)
       {
          fprintf(stderr, errstr);
          return 1;
       }
    
      // pigpio initialised okey.
    
       gpioWaveTxSend(wave_id, PI_WAVE_MODE_ONE_SHOT); 
    
       while(1)
       {
          gpioSerialRead(TXD, buf, 8);
          fwrite(buf, 8, 1, stdout);
          sleep(100);
       }
    
       gpioWaveTxStop();
    
       gpioSerialReadClose(TXD);
    
       gpioWaveTxStop();
    
       // release memory
       gpioTerminate();
    
       return 0;
    }