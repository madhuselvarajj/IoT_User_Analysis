int gpioInitialise(void)
{
   int status;

   if (libInitialised) return PIGPIO_VERSION;

   DBG(DBG_STARTUP, "not initialised, initialising");

   runState = PI_STARTING;

   status = initInitialise();

   if (status < 0)
   {
      runState = PI_ENDING;
      initReleaseResources();
   }
   else
   {
      libInitialised = 1;

      runState = PI_RUNNING;

      if (!(gpioCfg.ifFlags & PI_DISABLE_ALERT))
      {
         while (pthAlertRunning != PI_THREAD_RUNNING) myGpioDelay(1000);
      }

   }

   return status;
}
