var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var gpio = require('pi-gpio');
var app = express();
var mysql = require('mysql');
var dateFormat = require('dateformat');

app.use(bodyParser.json());
app.set('port', process.env.PORT || 3030);

dateFormat(now);

var now = new Date().toLocaleString();

var conn = mysql.createConnection({
    host: 'localhost',
    user: 'user',
    password: 'password',
    database: 'rest_api'
});

app.get('/:pin/1', function(req, res) {
    var pin = req.params.pin;

    gpio.open(pin, 'input', function(err) {
        //Set switch for turning on LED as pin 12
        if (pin === '12') {
            gpio.open(pin, 'output', function(err) {
                if (pin === '7') {
                    //Set pin 7 high (1)
                        gpio.write(7, 1, function(err) {
                        conn.query('INSERT INTO sensorLog(sensorId, logTime, sensorValue) VALUES(1, current_timestamp(), 1)', function(err){
                            if (err) throw err;
                                else {
                                console.log("Successfully store to mySQL database");
                            }
                        });
                    res.send(200, now);
                        gpio.close(7);
                });
                } if (pin === '11') {
                    //Set pin 11 high (1)
                        gpio.write(11, 1, function(err) {
                        conn.query('INSERT INTO sensorLog(sensorId, logTime, sensorValue) VALUES(2, current_timestamp(), 1)', function(err){
                            if (err) throw err;
                                else {
                                console.log("Successfully store to mySQL database");
                            }
                        });
                        res.send(200, now);
                            gpio.close(11);
                    });
                } if (pin === '13') {
                    //Set pin 13 high (1)
                        gpio.write(13, 1, function(err) {
                        conn.query('INSERT INTO sensorLog(sensorId, logTime, sensorValue) VALUES(3, current_timestamp(), 1)', function(err){
                            if (err) throw err;
                                else {
                                console.log("Successfully store to mySQL database");
                            }
                        });
                        res.send(200, now);
                            gpio.close(13);
                    });
                }
            });
        };
    });
});

app.get('/:pin/0', function(req, res) {
    var pin = req.params.pin;

    gpio.open(pin, 'input', function(err) {
        //Set switch for turning off LED as pin 15
        if (pin === '15') {
            gpio.open(pin, 'output', function(err) {
                if (pin === '7') {
                    //Set pin 7 low (0)
                        gpio.write(7, 0, function(err) {
                        conn.query('INSERT INTO sensorLog(sensorId, logTime, sensorValue) VALUES(1, current_timestamp(), 0)', function(err){
                                if (err) throw err;
                                    else {
                                    console.log("Successfully store to mySQL database");
                                }
                            });
                        res.send(200, now);
                        gpio.close(7);
                        });
                } if (pin === '11') {
                    //Set pin 11 low (0)
                        gpio.write(11, 0, function(err) {
                        conn.query('INSERT INTO sensorLog(sensorId, logTime, sensorValue) VALUES(2, current_timestamp(), 0)', function(err){
                            if (err) throw err;
                                else {
                                console.log("Successfully store to mySQL database");
                            }
                        });
                        res.send(200, now);
                            gpio.close(11);
                    });
                } if (pin === '13') {
                    //Set pin 13 low (0)
                        gpio.write(13, 0, function(err) {
                        conn.query('INSERT INTO sensorLog(sensorId, logTime, sensorValue) VALUES(3, current_timestamp(), 0)', function(err){
                            if (err) throw err;
                                else {
                                console.log("Successfully store to mySQL database");
                            }
                        });
                        res.send(200, now);
                            gpio.close(13);
                    });
                }
            });
        }
    });
});

var server = app.listen(app.get('port'), function() {
  console.log('Listening on port %d', server.address().port);
});
