[EDID=ACR-Acer_KA210HQ]
#DVI DMT (82) RGB full 16:9, 1920x1080 @ 60.00Hz
hdmi_group=2
hdmi_mode=82
[all]
