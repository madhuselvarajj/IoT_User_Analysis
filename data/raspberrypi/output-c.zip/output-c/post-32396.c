    if keypressed[pygame.K_w]:
      forward = True
    if keypressed[pygame.K_a]:
      left = True
    if keypressed[pygame.K_s]:
      reverse = True
    if keypressed[pygame.K_d]:
      right = True
