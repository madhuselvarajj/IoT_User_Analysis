#include <gpiod.h>
#include <stdio.h>
#include <unistd.h>

#ifndef CONSUMER
#define CONSUMER        "Consumer"
#endif

int main(int argc, char *argv[])
{
    char *chipname = "gpiochip0";
    unsigned int line_num = 27;     // GPIO Pin #27
    struct timespec ts = { 1, 0 };
    struct gpiod_line_event event;
    struct gpiod_chip *chip;
    struct gpiod_line *line;
    int i, ret;


    chip = gpiod_chip_open_by_name(chipname);
    if (!chip) {
        perror("Open chip failed\n");
        return -1;
    }
    else
        printf("%s: opened.\n", chipname);

    line = gpiod_chip_get_line(chip, line_num);
    if (!line) {
        perror("Get line failed\n");
        gpiod_chip_close(chip);
        return -2;
    }
    else
        printf("line number: %d\n", line_num);


    ret = gpiod_line_request_rising_edge_events(line, CONSUMER);
    if (ret < 0) {
        perror("Request event notification failed\n");
        gpiod_line_release(line);
        gpiod_chip_close(chip);
        return -3;
    }

    /* Notify event up to 20 times */
    i = 0;
    while (i <= 20) {
        ret = gpiod_line_event_wait(line, &ts);
        if (ret < 0) {
            perror("Wait event notification failed\n");
            gpiod_line_release(line);
            gpiod_chip_close(chip);
            return -4;
        }
        else if (ret == 0) {
            printf("Wait event notification on line #%u timeout\n", line_num);
            continue;
        }

        ret = gpiod_line_event_read(line, &event);
        printf("Get event notification on line #%u %d times\n", line_num, i);
        if (ret < 0) {
            perror("Read last event notification failed\n");
            gpiod_line_release(line);
            gpiod_chip_close(chip);
            return -5;
        }
        sleep(1);

        i++;
    }

    gpiod_line_release(line);
    gpiod_chip_close(chip);

    return 0;
}
