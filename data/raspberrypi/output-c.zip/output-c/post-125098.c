AIN1 - 5V, 0V

AIN2 - 5V, 0V

BIN1 - N.C.

BIN2 - N.C

nSleep - 5V, 0V

nFault - N.C

AOUT1 - serial current protecting resistor, to status LED Anode.

AOUT2 - LED Cathode

BOUT1 - N.C.

BOUT2 - N.C.

ASEN  - Ground 

BSEN  - Ground
