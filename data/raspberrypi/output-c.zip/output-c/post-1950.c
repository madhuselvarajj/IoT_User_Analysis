=====================ORIGINAL BYTEMARK RESULTS=====================
INTEGER INDEX       : 15.668
FLOATING-POINT INDEX: 5.021
Baseline (MSDOS*)   : Pentium* 90, 256 KB L2-cache, ...
=========================LINUX DATA BELOW==========================
CPU                 :
L2 Cache            :
OS                  : Linux 3.2.27+
C compiler          : gcc version 4.6.3 (Debian 4.6.3-8+rpi1)
libc                : libc-2.13.so
MEMORY INDEX        : 3.442
INTEGER INDEX       : 4.302
FLOATING-POINT INDEX: 2.780
Baseline (LINUX)    : AMD K6/233*, 512 KB L2-cache, gcc 2.7.2.3, ..
