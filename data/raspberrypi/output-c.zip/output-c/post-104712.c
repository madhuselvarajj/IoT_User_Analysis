Used + root-reserved space =               32768 - 28468 = 4300 MB  # size from `blockdev`
5% of the initial size =                   32276 * 5% = 1613 MB     # size from `df`
Used space without root reserve =          4300 - 1613 = 2687 MB
5% of the used space =                     2687 * 5% = 134 MB
Used space including 5% reserve =          2687 + 134 = 2821 MB
Image size incl. boot and 100 MB quota =   2821 + 250 + 100 = 3171 MB
