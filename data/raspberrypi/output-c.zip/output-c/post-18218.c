EnterNotify event, serial 25, synthetic NO, window 0x2c00001,
    root 0xc5, subw 0x0, time 41235311, (174,139), root:(176,212),
    mode NotifyNormal, detail NotifyAncestor, same_screen YES,
    focus YES, state 0

MotionNotify event, serial 25, synthetic NO, window 0x2c00001,
    root 0xc5, subw 0x0, time 41235321, (174,139), root:(176,212),
    state 0x0, is_hint 0, same_screen YES

MotionNotify event, serial 25, synthetic NO, window 0x2c00001,
    root 0xc5, subw 0x0, time 41235338, (164,123), root:(166,196),
    state 0x0, is_hint 0, same_screen YES
