/dts-v1/;
/plugin/;
 
 
/ {
        compatible = "brcm,bcm2835";
 
        fragment@0 {
                target = <&amp;spi0_cs_pins>;
                frag0: __overlay__ {
                        brcm,pins = <8>;
                };
        };
 
        fragment@1 {
                target = <&amp;spi0>;
                frag1: __overlay__ {
                        cs-gpios = <&amp;gpio 8 1>;
                        status = "okay";
                };
        };
 
        __overrides__ {
                cs0_pin  = <&amp;frag0>,"brcm,pins:0",
                           <&amp;frag1>,"cs-gpios:4";
        };
};
