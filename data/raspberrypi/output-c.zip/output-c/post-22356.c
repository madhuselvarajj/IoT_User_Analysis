# The loopback network interface
auto lo
iface lo inet loopback

# The primary (wired) network interface
iface eth0 inet dhcp

# The wifi (wireless) network interface
auto wlan0
allow-hotplug wlan0
iface wlan0 inet dhcp
        wpa-ssid "ssid"
        wpa-psk "password"
