    def reset(self):
        global started
        global belowLow
        global seconds
        self.t.set(0)
        started = False
        seconds = 0
        belowLow = 0
        self.listen() <-- should not be included
