$ ip addr
.... <snip>
3: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP qlen 1000
    link/ether e8:4e:06:xx:xx:xx brd ff:ff:ff:ff:ff:ff
    inet 10.3.2.8/24 brd 10.3.2.255 scope global wlan0
       valid_lft forever preferred_lft forever
    inet 10.3.2.101/24 brd 10.3.2.255 scope global secondary wlan0
       valid_lft forever preferred_lft forever
