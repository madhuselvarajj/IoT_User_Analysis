The Java Sound API specifies the following abstract subclasses of Control:

BooleanControl— represents a binary-state (true or false) control. For example, mute, solo, and on/off switches would be good candidates for BooleanControls. 
[...]
Each subclass of Control above has methods appropriate for its underlying data type. 
Most of the classes include methods that set and get the control's current value(s), get the control's label(s), and so on.\

Of course, each class has methods that are particular to it and the data model represented by the class. 
For example, EnumControl has a method that lets you get the set of its possible values, and FloatControl permits you to get its minimum and maximum values, as well as the precision (increment or step size) of the control.

Each subclass of Control has a corresponding Control.Type subclass, which includes static instances that identify specific controls.

The following table shows each Control subclass, its corresponding Control.Type subclass, and the static instances that indicate specific kinds of controls:

Control         Control.Type         Control.Type instances
BooleanControl  BooleanControl.Type  MUTE – Mute status of line
[...]
