/*
This program toggles a GPIO pin and measures rate.
Using pigpio C Interface

TO BUILD

gcc -Wall -o bench-pigpio bench-pigpio.c -lpigpio

*/

// 2021-09-21

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <pigpio.h>

int SigOUT = 12;
#define LOOPS 20000

int main(int argc, char *argv[]) {
  int i;
  double t0, t1;

  if(gpioInitialise() < 0)  return 1;

  gpioSetMode(SigOUT, PI_OUTPUT);

  t0 = time_time();

  for (i = 0; i < LOOPS; i++) {
    gpioWrite(SigOUT, 0);
    gpioWrite(SigOUT, 1);
  }
  t1 = time_time();

  printf("pigpio C\t%10.0f toggles per second\n", (1.0 * LOOPS) / (t1 - t0));

  return 0;
}
