root@pitest:~# ifconfig -a
eth0: flags=4099<UP,BROADCAST,MULTICAST>  mtu 1500
        ether b8:27:eb:92:87:21  txqueuelen 1000  (Ethernet)
        RX packets 0  bytes 0 (0.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 0  bytes 0 (0.0 B)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 0  bytes 0 (0.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 0  bytes 0 (0.0 B)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.1.112  netmask 255.255.255.0  broadcast 192.168.1.255
        inet6 2404:9400:218b:2f02:d594:ce48:6b42:62cc  prefixlen 64  scopeid 0x0<global>
        inet6 fe80::62f2:4123:c13d:355b  prefixlen 64  scopeid 0x20<link>
        ether 00:36:76:b0:23:61  txqueuelen 1000  (Ethernet)
        RX packets 36282  bytes 7932636 (7.5 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 3519  bytes 517860 (505.7 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

