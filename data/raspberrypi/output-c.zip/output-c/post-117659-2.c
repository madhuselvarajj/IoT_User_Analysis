var startDate = Date.now(); // Date in MS since 1/1/1970
var displayDate = 0;

setInterval(() => {
  displayDate = (Date.now() - startDate) / 1000;
}, 1000);
