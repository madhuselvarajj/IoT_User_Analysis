  C:\Users\SAMRUDDHI>ping 192.168.1.222

  Pinging 192.168.1.222 with 32 bytes of data:
  Reply from 192.168.1.222: bytes=32 time=1ms TTL=64
  Reply from 192.168.1.222: bytes=32 time<1ms TTL=64
  Reply from 192.168.1.222: bytes=32 time<1ms TTL=64
  Reply from 192.168.1.222: bytes=32 time<1ms TTL=64

  Ping statistics for 192.168.1.222:
  Packets: Sent = 4, Received = 4, Lost = 0 (0% loss),
  Approximate round trip times in milli-seconds:
  Minimum = 0ms, Maximum = 1ms, Average = 0ms

  C:\Users\SAMRUDDHI>ping 192.168.10.71

  Pinging 192.168.10.71 with 32 bytes of data:
  Reply from 192.168.10.71: bytes=32 time=3ms TTL=64
  Reply from 192.168.10.71: bytes=32 time=1ms TTL=64
  Reply from 192.168.10.71: bytes=32 time=1ms TTL=64
  Reply from 192.168.10.71: bytes=32 time=3ms TTL=64

  Ping statistics for 192.168.10.71:
  Packets: Sent = 4, Received = 4, Lost = 0 (0% loss),
  Approximate round trip times in milli-seconds:
  Minimum = 1ms, Maximum = 3ms, Average = 2ms
