/*
This program toggles a GPIO pin and measures rate.
Using pigpiod C Interface

TO BUILD

gcc -Wall -o bench-pigpiod bench-pigpiod.c -lpigpiod_if2

*/

// 2021-09-21

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <pigpiod_if2.h>

char *optHost = NULL;
char *optPort = NULL;
int SigOUT = 12;
#define LOOPS 20000

void usage() {
  fprintf(stderr,
          "\n"
          "Usage: bench-pigpio [OPTION] ...\n"
          "   -o value, output pin, 0-31,                 default %d\n"
          "   -h string, host name,                       default NULL\n"
          "   -p value, socket port, 1024-32000,          default 8888\n"
          "EXAMPLE\n"
          "bench-pigpio -i20 -o26\n",
          SigOUT);
}

static uint64_t getNum(char *str, int *err) {
  uint64_t val;
  char *endptr;

  *err = 0;
  val = strtoll(str, &endptr, 0);
  if (*endptr) {
    *err = 1;
    val = -1;
  }
  return val;
}

static void initOpts(int argc, char *argv[]) {
  int opt, err;

  while ((opt = getopt(argc, argv, "g:h:i:m:p:")) != -1) {
    switch (opt) {

    case 'o':
      SigOUT = getNum(optarg, &err);
      break;

    case 'h':
      optHost = malloc(sizeof(optarg) + 1);
      if (optHost)
        strcpy(optHost, optarg);
      break;

      optPort = malloc(sizeof(optarg) + 1);
      if (optPort)
        strcpy(optPort, optarg);
      break;

    default: /* '?' */
      usage();
      exit(-1);
    }
  }
}

int main(int argc, char *argv[]) {
  int i;
  int pi;
  double t0, t1;

  initOpts(argc, argv);

  pi = pigpio_start(optHost, optPort); /* Connect to Pi. */

  if (pi >= 0) {
    set_mode(pi, SigOUT, PI_OUTPUT);

    t0 = time_time();

    for (i = 0; i < LOOPS; i++) {
      gpio_write(pi, SigOUT, 0);
      gpio_write(pi, SigOUT, 1);
    }
    t1 = time_time();

    printf("pigpio C\t%10.0f toggles per second\n", (1.0 * LOOPS) / (t1 - t0));

    pigpio_stop(pi); /* Disconnect from Pi. */
  }
  return 0;
}
