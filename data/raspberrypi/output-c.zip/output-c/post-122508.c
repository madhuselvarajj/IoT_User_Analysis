network={
    ssid="OriginalWifi"
    psk="passwordSchool"
    id="school"
}

network={
    ssid="NewWifi"
    psk="passwordHome"
    id="home"
} 
