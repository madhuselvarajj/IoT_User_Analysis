    <control type="group" id="4250">
        <include>Window_OpenClose_Animation_Zoom</include>
        <posx>560r</posx>
        <posy>165</posy>
        <include>VisibleFadeEffect</include>
        <visible>false</visible>
        <control type="button" id="4251">
        ...
