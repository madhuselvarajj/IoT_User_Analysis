System.load("/opt/opencv-4.4.0/lib/libopencv_core.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_imgproc.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_imgcodecs.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_img_hash.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_photo.so");

System.load("/opt/opencv-4.4.0/lib/libopencv_xphoto.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_flann.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_features2d.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_calib3d.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_phase_unwrapping.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_structured_light.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_xfeatures2d.so");

System.load("/opt/opencv-4.4.0/lib/libopencv_video.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_ximgproc.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_aruco.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_bgsegm.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_bioinspired.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_objdetect.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_face.so");

System.load("/opt/opencv-4.4.0/lib/libopencv_dnn.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_tracking.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_plot.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_ml.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_ml.so");
System.load("/opt/opencv-4.4.0/lib/libopencv_text.so");
System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
