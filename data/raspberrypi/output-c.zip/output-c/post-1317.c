[autoexec]
mount c ~
c:
imgmount a w95.img
boot w95.img
