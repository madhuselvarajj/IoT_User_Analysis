#include <bcm2835.h>
#include <iostream>
int main(int argc, char **argv)
{
    if (!bcm2835_init()) return 1;
    std::cout << "BCM2835 is all set!" << std::endl
    return 0;
}
