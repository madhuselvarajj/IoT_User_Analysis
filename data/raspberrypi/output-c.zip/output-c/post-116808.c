[main]
plugins=ifupdown,keyfile
dhcp=internal

[ifupdown]
managed=true
