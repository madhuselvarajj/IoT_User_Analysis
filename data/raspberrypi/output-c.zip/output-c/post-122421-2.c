#include "stdio.h"

int doit(){
        printf ("Hello, world\n");
}
