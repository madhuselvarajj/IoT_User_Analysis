#include <iostream>
#include <boost/array.hpp>
#include <boost/asio.hpp>    

int main(){

    std::cout << "Hello World!" << std::endl;
    std::cout << "Opening TCP socket on port 9999..." << std::endl;
    // > 1.66
    boost::asio::io_context io_context;
    // < 1.66
    //io_service io_service;

    boost::asio::ip::tcp::endpoint endpoint(boost::asio::ip::tcp::v4(), 9999);
    boost::asio::io_context.run();
    std::cout << "Socket opened!" << std::endl;
    boost::asio::io_context.stop();
    std::cout << "Socket closed." << std::endl;
    return 0;
}
