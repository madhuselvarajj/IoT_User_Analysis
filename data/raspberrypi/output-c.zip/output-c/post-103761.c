# ftime69.py  tlfong01 2019sep08hkt1158
# Rpi4B buster 2019jul10 python 3.7.3 Thronny 1.1

import  inspect
from    time     import   sleep
from    datetime import  datetime
import  fprint53 as      fprint

# ********************************************************************************
# ********************************************************************************

# *** Date Time Functions ***

def delaySeconds(secondsNum):
    sleep(secondsNum)
    return

def oneSecondDelay():
    delaySeconds(1)
    return

def tenMillionPasses():
    totalCount = 10000000
    for count in range(totalCount):
        pass
    return

def oneMillionPasses():
    totalCount = 1000000
    for count in range(totalCount):
        pass
    return

def oneThousandPasses():
    totalCount = 1000
    for count in range(totalCount):
        pass
    return

def printDateTimeNow():
    timeNowLong  = datetime.now()
    timeNowShort = str(timeNowLong)[0:16]
    fprint.printTitleString('timeNowLong',  fprint.indentFormat640, timeNowLong)
    fprint.printTitleString('timeNowShort', fprint.indentFormat640, timeNowShort)
    return

def printStartTimeFinishTimeDifferenceLong(startTime, finishTime):  
    elapsedTime = finishTime - startTime
    elapsedSeconds = elapsedTime.seconds
    elapsedMicroSeconds = (elapsedSeconds * 1000000) + elapsedTime.microseconds
    elapsedMilliSeconds = int(elapsedMicroSeconds / 1000)
    fprint.printTitleString('Start Time',           fprint.indentFormat640, startTime)
    fprint.printTitleString('Finish Time',          fprint.indentFormat640, finishTime)
    fprint.printTitleString('Elapsed Time',         fprint.indentFormat640, elapsedTime)    
    fprint.printTitleString('Elapsed Seconds',      fprint.indentFormat640, elapsedSeconds)    
    fprint.printTitleString('Elapsed MilliSeconds', fprint.indentFormat640, elapsedMilliSeconds)
    fprint.printTitleString('Elapsed MicroSeconds', fprint.indentFormat640, elapsedMicroSeconds) 
    return

def printStartTimeFinishTimeDifferenceMilliSeconds(startTime, finishTime):  
    elapsedTime = finishTime - startTime
    elapsedSeconds = elapsedTime.seconds
    elapsedMicroSeconds = (elapsedSeconds * 1000000) + elapsedTime.microseconds
    elapsedMilliSeconds = int(elapsedMicroSeconds / 1000)
    fprint.printTitleString('Elapsed MilliSeconds', fprint.indentFormat640, elapsedMilliSeconds)
    return

def printStartTimeFinishTimeDifferenceMicroSeconds(startTime, finishTime):  
    elapsedTime = finishTime - startTime
    elapsedSeconds = elapsedTime.seconds
    elapsedMicroSeconds = (elapsedSeconds * 1000000) + elapsedTime.microseconds
    elapsedMilliSeconds = int(elapsedMicroSeconds / 1000)
    fprint.printTitleString('Elapsed MicroSeconds', fprint.indentFormat640, elapsedMicroSeconds)
    return

def printFunctionElapseTime(function, functionName):
    fprint.printBeginExecFunction()
    printDateTimeNow()
    printElapsedTime()
    fprint.printEndExecFunction()
    return

# *** Test Functions ***

def testPrintDateTimeNow():
    fprint.printBeginExecFunction()
    printDateTimeNow()
    fprint.printEndExecFunction()
    return

def testPrintOneSecondElapsedTime():
    fprint.printBeginExecFunction()
    startTime = datetime.now()
    delaySeconds(1)
    finishTime = datetime.now()
    printStartTimeFinishTimeDifferenceLong(startTime, finishTime)
    fprint.printEndExecFunction()
    return

def testPrintTwoSecondsElapsedTime():
    fprint.printBeginExecFunction()
    startTime = datetime.now()
    delaySeconds(2)
    finishTime = datetime.now()
    printStartTimeFinishTimeDifferenceLong(startTime, finishTime)
    fprint.printEndExecFunction()
    return

def testPrintFunctionExecTimeLong(function):
    #fprint.printBeginExecFunction()
    startTime = datetime.now()
    function()
    finishTime = datetime.now()
    printStartTimeFinishTimeDifferenceLong(startTime, finishTime)
    #fprint.printEndExecFunction()
    return

def testPrintFunctionExecTimeMilliSeconds(function):
    #fprint.printBeginExecFunction()
    startTime = datetime.now()
    function()
    finishTime = datetime.now()
    printStartTimeFinishTimeDifferenceMilliSeconds(startTime, finishTime)
    #fprint.printEndExecFunction()
    return

def testPrintFunctionExecTimeMicroSeconds(function):
    #fprint.printBeginExecFunction()
    startTime = datetime.now()
    function()
    finishTime = datetime.now()
    printStartTimeFinishTimeDifferenceMicroSeconds(startTime, finishTime)
    #fprint.printEndExecFunction()
    return


def testPrintOneSecondDelayFunctionLong():
    fprint.printBeginExecFunction()
    testPrintFunctionExecTimeLong(oneSecondDelay)
    fprint.printEndExecFunction()
    return

def testPrintOneSecondDelayFunctionMilliSeconds():
    fprint.printBeginExecFunction()
    testPrintFunctionExecTimeMilliSeconds(oneSecondDelay)
    fprint.printEndExecFunction()
    return

def testPrintTenMillionPassesFunctionMilliSeconds():
    fprint.printBeginExecFunction()
    testPrintFunctionExecTimeMilliSeconds(tenMillionPasses)
    fprint.printEndExecFunction()
    return

def testPrintOneMillionPassesFunctionMicroSeconds():
    fprint.printBeginExecFunction()
    testPrintFunctionExecTimeMicroSeconds(oneMillionPasses)
    fprint.printEndExecFunction()
    return

def testPrintOneThousandPassesFunctionMicroSeconds():
    fprint.printBeginExecFunction()
    testPrintFunctionExecTimeMicroSeconds(oneThousandPasses)
    fprint.printEndExecFunction()
    return

def printOneLineTenTimes():
    printLine = 'abcxyz' 
    repeatCount = 10

    for i in range(10):
        print('         abcxyz')
    return

def testPrintPrintOneLineTenTimesFunctionMilliSeconds():
    fprint.printBeginExecFunction()
    testPrintFunctionExecTimeMilliSeconds(printOneLineTenTimes)
    fprint.printEndExecFunction()
    return

# ********************************************************************************
# ********************************************************************************

# *** Main Tests ***

def mainTests():
    #testPrintDateTimeNow()
    #testPrintOneSecondElapsedTime()
    #testPrintTwoSecondsElapsedTime()
    #testPrintOneSecondDelayFunctionLong()
    #testPrintOneSecondDelayFunctionMilliSeconds()
    #testPrintTenMillionPassesFunctionMilliSeconds()
    #testPrintOneMillionPassesFunctionMicroSeconds()
    #testPrintOneThousandPassesFunctionMicroSeconds()
    testPrintPrintOneLineTenTimesFunctionMilliSeconds()
    return

# ********************************************************************************
# ********************************************************************************

# *** Init/Main Functions ***

# *** Init Function ***

def init():
    pass
    return

#*** Main Function ***

def main():
    init()
    mainTests()    
    return

# ********************************************************************************
# ********************************************************************************

# *** Main ***

if __name__ == '__main__':
    main()

# *** End of Program ***

# ********************************************************************************
# ********************************************************************************

''' Sample Output 2019sep08hkt1208
>>> %Run ftime69.py

     ********************************************************************************

     Begin Execute Function testPrintPrintOneLineTenTimesFunctionMilliSeconds tlfong01 

       Function Name                           = testPrintPrintOneLineTenTimesFunctionMilliSeconds
         abcxyz
         abcxyz
         abcxyz
         abcxyz
         abcxyz
         abcxyz
         abcxyz
         abcxyz
         abcxyz
         abcxyz
       Elapsed MilliSeconds                    = 3

     End   Execute Function testPrintPrintOneLineTenTimesFunctionMilliSeconds tlfong01 

     ********************************************************************************

>>> 
'''
