#include <pigpio.h>

const int pinDRDY = 2;
const int pinCLK = 3;
const int pinData = 4;

bool myDRDY;
int myData;

sub init() {
    gpioInitialise();

    # Set pins to input
    gpioSetMode(pinDRDY, 0);
    gpioSetMode(pinCLK, 0);
    gpioSetMode(pinData, 0);

    # Set "interrupt" handler for data ready pin
    if (gpioSetAlertFunc(pinDRDY, interruptDataRready()) != 0) {
        # Bad GPIO, gracefully crash
        exit;
    }
    # GPIO "interrupt" pin is set, wait for callback for data ready
}

sub interruptDataReady(GPIO, level, tick) {
    myDRDY = level;

    if (myDRDY == true) {
        # Transition low to high, prepare for receiving new data
        # Set "interrupt" handler for clock
        if (gpioSetAlertFunc(pinCLK, interruptClockPulse()) != 0) {
            # A different bad GPIO, turn off data handler, gracefully crash
            gpioSetAlertFunc(pinCLK, null);
            exit;
        }
        else {
            # Set "interrupt" handler for clock, initialize for new data byte
            myData = 0
        }
    else {
        # Transition high to low, first disable the clock handler
        gpioSetAlertFunc(pinCLK, null);

        # Next, send the data out somewhere
        doSomething();
    }
}

sub interruptClockPulse(GPIO, level, tick) {
    # For example purposes, reads data upon the rising edge
    int intNewBit;

    if (level == 1) {
        # Rising clock edge, reads one bit of data

        # Shift data left one bit
        myData << 1;

        # Read data
        intNewBit = gpioRead(pinData);
        if (intNewBit == 1) {
            myData = myData | 1;
        else {
            # Either bad GPIO pin or zero bit, nothing to do
        }
    else {
        # Falling clock edge, nothing to do
    }
}

sub doSomething(){
    # Do something
    debug.print(myData);
}
