subnet 192.168.2.0 netmask 255.255.255.0 {
    range 192.168.2.21 192.168.2.70;
    option broadcast-address 192.168.2.255;
    option subnet-mask 255.255.255.0;
    option routers 192.168.2.1;
    option domain-name-servers 192.168.2.10;
    option domain-search "lan";
}
