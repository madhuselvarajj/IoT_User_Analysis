Sony Xperia Z5:
connectivitycheck.gstatic.com:80
clients3.google.com:80
---------------------
Samsung Galaxy J3 2016:
172.217.21.14:80
connectivitycheck.android.com
---------------------
Samsung Galaxy J7 2015:
172.16.98.10:80
connectivitycheck.gstatic.com:80
---------------------
galaxy note4:
nothing!
---------------------
iOS 11:
captive.apple.com/hotspot-detect.html
---------------------
Windows 10:
www.msftconnecttest.com
