rpi ~$ ip -br link
lo               UNKNOWN        00:00:00:00:00:00 <LOOPBACK,UP,LOWER_UP>
eth0             UP             dc:a6:32:01:db:ec <BROADCAST,MULTICAST,UP,LOWER_UP>
wlan0            DOWN           dc:a6:32:01:db:ed <BROADCAST,MULTICAST>
wlan1            DOWN           00:0e:00:20:08:13 <NO-CARRIER,BROADCAST,MULTICAST,UP>
