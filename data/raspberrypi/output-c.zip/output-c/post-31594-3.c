{
  "name": "Raspbian",
  "version": "wheezy",
  "release_date": "2015-02-16",
  "kernel": "3.18",
  "description": "A community-created port of Debian wheezy, optimised for the Raspberry Pi",
  "url": "http://www.raspbian.org/",
  "username": "pi",
  "password": "raspberry",
  "supported_hex_revisions": "2,3,4,5,6,7,8,9,d,e,f,10,11,12,14,19,1040,1041"
}
