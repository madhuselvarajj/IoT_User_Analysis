~$ sudo iw dev wlan0 scan | grep -B5 'SSID: RpiAP'
        freq: 2462
        beacon interval: 100 TUs
        capability: ESS Privacy ShortPreamble ShortSlotTime RadioMeasure (0x1431)
        signal: -52.00 dBm
        last seen: 0 ms ago
        SSID: RpiAP
--
        freq: 5500
        beacon interval: 100 TUs
        capability: ESS Privacy SpectrumMgmt ShortSlotTime RadioMeasure (0x1511)
        signal: -56.00 dBm
        last seen: 0 ms ago
        SSID: RpiAP
