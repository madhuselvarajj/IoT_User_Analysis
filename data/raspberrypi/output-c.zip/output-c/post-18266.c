$ gdb-multiarch
(gdb) set architecture arm
(gdb) target remote localhost:1234
(gdb) si            # to debug step by step
(gdb) x/i <address> # to disassemble code
