#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
int main()
{
    int i;
    for (i=0; i<1024; i++) close(i);
    open("/dev/null", O_RDONLY);
    open("/dev/null", O_WRONLY);
    open("/dev/null", O_WRONLY);
    usleep(500000);
    /* system("/usr/bin/sudo /sbin/reboot"); */
    execl("/usr/bin/sudo", "sudo", "/sbin/reboot", NULL);
    return 0;
}
