Jan 15 19:31:03 raspberrypi dhcpcd[647]: wlan0: carrier lost
Jan 15 19:31:03 raspberrypi dhcpcd[647]: wlan0: deleting address fe80::dfd3:f31e:1538:b9b6
Jan 15 19:31:03 raspberrypi avahi-daemon[497]: Withdrawing address record for fe80::dfd3:f31e:1538:b9b6 on wlan0.
Jan 15 19:31:03 raspberrypi avahi-daemon[497]: Leaving mDNS multicast group on interface wlan0.IPv6 with address fe80::dfd3:f31e:1538:b9b6.
Jan 15 19:31:03 raspberrypi avahi-daemon[497]: Interface wlan0.IPv6 no longer relevant for mDNS.
Jan 15 19:31:03 raspberrypi avahi-daemon[497]: Withdrawing address record for 192.168.50.194 on wlan0.
Jan 15 19:31:03 raspberrypi avahi-daemon[497]: Leaving mDNS multicast group on interface wlan0.IPv4 with address 192.168.50.194.
Jan 15 19:31:03 raspberrypi avahi-daemon[497]: Interface wlan0.IPv4 no longer relevant for mDNS.
Jan 15 19:31:03 raspberrypi dhcpcd[647]: wlan0: deleting route to 192.168.50.0/24
Jan 15 19:31:03 raspberrypi dhcpcd[647]: wlan0: deleting default route via 192.168.50.1
