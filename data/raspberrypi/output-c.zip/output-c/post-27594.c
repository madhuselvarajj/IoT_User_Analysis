int fd = open("/sys/class/gpio/export", O_WRONLY);
write(fd, "252\n", 4);
close(fd);
fd = open("/sys/class/gpio/gpio252", O_WRONLY);
write(fd, "out\n", 5);
close(fd);
