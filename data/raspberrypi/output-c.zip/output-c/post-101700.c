def cbf(gpio, level, tick):
   print(gpio, level, tick)

cb1 = pi.callback(22, pigpio.EITHER_EDGE, cbf)

cb2 = pi.callback(4, pigpio.EITHER_EDGE)

cb3 = pi.callback(17)

print(cb3.tally())

cb3.reset_tally()

cb1.cancel() # To cancel callback cb1.
