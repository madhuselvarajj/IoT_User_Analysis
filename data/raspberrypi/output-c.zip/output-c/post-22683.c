#include <SPI.h>
#include "nRF24L01.h"
#include "RF24.h"
#include "printf.h"

int LedOn = 8;
RF24 radio(9,10);//uno

const uint64_t pipes[2] = { 0xF0F0F0F0E9LL, 0xF0F0F0F0D2LL };

typedef enum { role_ping_out = 1, role_pong_back } role_e;

const char* role_friendly_name[] = { "invalid", "Ping out", "Pong back"};

role_e role = role_pong_back;

void setup(void)
{

  pinMode(LedOn, OUTPUT);

  Serial.begin(57600);
  printf_begin();
  printf("\n\rRF24/examples/GettingStarted/\n\r");
  printf("ROLE: %s\n\r",role_friendly_name[role]);
  printf("*** PRESS 'T' to begin transmitting to the other node\n\r");

  radio.begin();

  radio.setRetries(15,15);
  radio.openReadingPipe(1,pipes[1]);
  radio.startListening();
  radio.printDetails();
}

void loop(void)
{

  if (role == role_ping_out)
  {   
    radio.stopListening();
    unsigned long time = millis();
    printf("Now sending %lu...",time);
    bool ok = radio.write( &time, sizeof(unsigned long) );

    if (ok)
      printf("ok...");
    else
      printf("failed.\n\r");


    radio.startListening();

    unsigned long started_waiting_at = millis();
    bool timeout = false;
    while ( ! radio.available() && ! timeout )
      if (millis() - started_waiting_at > 200 )
        timeout = true;

    if ( timeout )
    {
      printf("Failed, response timed out.\n\r");
       digitalWrite(LedOn, LOW);
    }
    else
    {

      char* mess;
      radio.read( &mess, sizeof(char*) );     
      printf("Got response %s, message is: %s\n\r",mess);      
    }

    delay(1000);
  }


  unsigned int mess;
  if ( role == role_pong_back )
  {

    if ( radio.available() )
    {
      digitalWrite(LedOn, HIGH);     
      unsigned long got_time;

      bool done = false;
      while (!done)
      {
        done = radio.read( &mess, sizeof(unsigned int) );

        printf("Got payload %lu...", mess);

        delay(30);

      }

      radio.stopListening();

      radio.write( &got_time, sizeof(unsigned long) );
      printf("Sent response.\n\r");

      radio.startListening();
    }else{
       digitalWrite(LedOn, LOW);
    }
  }

  if ( Serial.available() )
  {
    char c = toupper(Serial.read());
    if ( c == 'T' && role == role_pong_back )
    {
      printf("*** CHANGING TO TRANSMIT ROLE -- PRESS 'R' TO SWITCH BACK\n\r");

      role = role_ping_out;
      radio.openWritingPipe(pipes[0]);
      radio.openReadingPipe(1,pipes[1]);

    }
    else if ( c == 'R' && role == role_ping_out )
    {
      printf("*** CHANGING TO RECEIVE ROLE -- PRESS 'T' TO SWITCH BACK\n\r");

      role = role_pong_back;
      radio.openWritingPipe(pipes[1]);
      radio.openReadingPipe(1,pipes[0]);
      radio.printDetails();
    }
  }
}
// vim:cin:ai:sts=2 sw=2 ft=cpp
