$ apt-cache search veyon
libveyon-core - Computer Monitoring and Classroom Management Software - libraries
veyon-configurator - Computer Monitoring and Classroom Management Software - configurator
veyon-master - Computer Monitoring and Classroom Management Software - master
veyon-plugins - Computer Monitoring and Classroom Management Software - plugins
veyon-service - Computer Monitoring and Classroom Management Software - client service
