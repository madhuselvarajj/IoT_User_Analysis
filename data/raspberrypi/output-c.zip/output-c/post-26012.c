apt-cache search gnuradio
gnuradio - GNU Radio Software Radio Toolkit
gnuradio-dev - GNU Software Defined Radio toolkit development
gnuradio-doc - GNU Software Defined Radio toolkit documentation
libgnuradio-analog3.7.5 - gnuradio analog functions
libgnuradio-atsc3.7.5 - gnuradio atsc functions
libgnuradio-audio3.7.5 - gnuradio audio functions
libgnuradio-blocks3.7.5 - gnuradio blocks functions
libgnuradio-channels3.7.5 - gnuradio channels functions
libgnuradio-comedi3.7.5 - gnuradio comedi instrument control functions
libgnuradio-digital3.7.5 - gnuradio digital communications functions
libgnuradio-dtv3.7.5 - gnuradio digital TV signal processing blocks
libgnuradio-fcd3.7.5 - gnuradio FunCube Dongle support
libgnuradio-fec3.7.5 - gnuradio forward error correction support
libgnuradio-fft3.7.5 - gnuradio fast Fourier transform functions
libgnuradio-filter3.7.5 - gnuradio filter functions
libgnuradio-noaa3.7.5 - gnuradio noaa satellite signals functions
libgnuradio-pager3.7.5 - gnuradio pager radio functions
libgnuradio-pmt3.7.5 - gnuradio pmt container library
libgnuradio-qtgui3.7.5 - gnuradio Qt graphical user interface functions
libgnuradio-runtime3.7.5 - gnuradio core runtime
libgnuradio-trellis3.7.5 - gnuradio trellis modulation functions
libgnuradio-uhd3.7.5 - gnuradio universal hardware driver functions
libgnuradio-video-sdl3.7.5 - gnuradio video functions
libgnuradio-vocoder3.7.5 - gnuradio vocoder functions
libgnuradio-wavelet3.7.5 - gnuradio wavelet functions
libgnuradio-wxgui3.7.5 - gnuradio wxgui functions
libgnuradio-zeromq3.7.5 - gnuradio zeromq functions
libvolk-bin - vector optimized runtime tools
libvolk-dev - gnuradio vector optimized function headers
libvolk0.0.0 - gnuradio vector optimized functions
gr-air-modes - Gnuradio Mode-S/ADS-B radio
libair-modes0 - Gnuradio Mode-S/ADS-B radio
gr-fcdproplus - Funcube Dongle Pro Plus controller for GNU Radio
libgnuradio-fcdproplus0 - Funcube Dongle Pro Plus controller for GNU Radio
libgnuradio-iqbalance0 - GNU Radio Blind IQ imbalance estimator and correction
gr-osmosdr - Gnuradio blocks from the OsmoSDR project
libgnuradio-osmosdr0.1.3 - Gnuradio blocks from the OsmoSDR project
