    if keypressed[pygame.K_w]:
      forward = True
    elif keypressed[pygame.K_a]:
      left = True
    elif keypressed[pygame.K_s]:
      reverse = True
    elif keypressed[pygame.K_d]:
      right = True
