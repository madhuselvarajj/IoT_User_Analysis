#include <sys/mount.h>
#include <stdio>
#include <string>
#include <errno.h>

if (mount (
    "/dev/sda1",
    "/media/usbstick",
    "vfat",
    0,
    "uid=1000,gid=1000"
) == -1) puts(strerror(errno));
else puts("Okay.");
