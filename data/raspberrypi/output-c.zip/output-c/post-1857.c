    [    3.181011] usb 1-1.2: new high-speed USB device number 4 using dwc_otg
    [    3.308976] usb 1-1.2: New USB device found, idVendor=148f, idProduct=5370
    [    3.318423] usb 1-1.2: New USB device strings: Mfr=1, Product=2, SerialNumber=3
    [    3.328287] usb 1-1.2: Product: 802.11 n WLAN
    [    3.335089] usb 1-1.2: Manufacturer: Ralink
    [    3.341716] usb 1-1.2: SerialNumber: 1.0
    [    3.431060] usb 1-1.3: new low-speed USB device number 5 using dwc_otg
    [    3.544469] usb 1-1.3: New USB device found, idVendor=1d57, idProduct=ad02
    [    3.553826] usb 1-1.3: New USB device strings: Mfr=0, Product=0, SerialNumber=0
    [    3.575628] input: HID 1d57:ad02 as /devices/platform/bcm2708_usb/usb1/1-1/1-1.3/1-1.3:1.0/input/input0
    [    3.591806] generic-usb 0003:1D57:AD02.0001: input,hiddev0: USB HID v1.10 Keyboard [HID 1d57:ad02] on usb-bcm2708_usb-1.3/input0
    [    3.614598] input: HID 1d57:ad02 as /devices/platform/bcm2708_usb/usb1/1-1/1-1.3/1-1.3:1.1/input/input1
    [    3.630092] generic-usb 0003:1D57:AD02.0002: input,hiddev0: USB HID v1.10 Mouse [HID 1d57:ad02] on usb-bcm2708_usb-1.3/input1
