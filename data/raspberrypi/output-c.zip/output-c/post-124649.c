if $programname == 'kernel' then {
   if $msg contains 'IR event FIFO is full!'
   then {
       stop
   }
}
