int MCP3221= open("/dev/i2c-1", O_RDWR); // open I2C1
ioctl(MCP3221, I2C_SLAVE, 0x4D); // use MCP device address

unsigned char buf[2];
read(MCP3221, buf, 2); // read 2 byte value
int adc = (buf[0] << 8) | buf[1];
