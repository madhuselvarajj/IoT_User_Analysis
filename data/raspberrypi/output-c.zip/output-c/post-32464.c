p = pyaudio.PyAudio()

stream = p.open(format = pyaudio.paInt16,
    channels = 1,
    rate = sRate,
    input = True,
    frames_per_buffer = fPerBuffer,
    input_device_index = 2)

recog = sr.Recognizer("en-GB")
r = array('h')

## You will need to loop this next bit until you are finished recording
data = array('h',stream.read(framesPerBuffer))
rms = audioop.rms(data,2)
r.extend(data)
r.append(data)
########
