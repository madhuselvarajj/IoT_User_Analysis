wlan0     Link encap:Ethernet  HWaddr 6c:19:8f:9a:26:0e
          inet addr:192.168.3.101  Bcast:192.168.3.255  Mask:255.255.255.0
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:2917 errors:0 dropped:37 overruns:0 frame:0
          TX packets:2911 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:380554 (371.6 KiB)  TX bytes:356183 (347.8 KiB)
