root@rpi_server:/etc/php# aptitude install php7.2-curl
The following NEW packages will be installed:
  php7.2-curl{b}
0 packages upgraded, 1 newly installed, 0 to remove and 873 not upgraded.
Need to get 0 B/25.8 kB of archives. After unpacking 93.2 kB will be used.
The following packages have unmet dependencies:
 php7.2-curl : Depends: libcurl3 (>= 7.44.0) which is a virtual package and is not provided by any available package

The following actions will resolve these dependencies:

     Keep the following packages at their current version:
1)     php7.2-curl [Not Installed]



Accept this solution? [Y/n/q/?] n
The following actions will resolve these dependencies:

      Install the following packages:
1)      php7.2-curl [7.2.9-1+b2 (stable)]

      Downgrade the following packages:
2)      libapache2-mod-php7.2 [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
3)      php7.2-cgi [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
4)      php7.2-cli [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
5)      php7.2-common [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
6)      php7.2-gd [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
7)      php7.2-intl [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
8)      php7.2-json [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
9)      php7.2-ldap [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
10)     php7.2-mbstring [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
11)     php7.2-mysql [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
12)     php7.2-opcache [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
13)     php7.2-readline [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
14)     php7.2-xml [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
15)     php7.2-xmlrpc [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]
16)     php7.2-zip [7.2.19-1+0~20190531112637.22+stretch~1.gbp75765b (<NULL>, now) -> 7.2.9-1+b2 (stable)]

