 <!-- Control Mouse using Keyboard via XWIT and XDOTOLL -->

   <!-- MOUSE CLICKS WITHOUT NUMLOCK -->

      <!-- Keybinding for MOUSE CONTROL RIGHT CLICK-->
      <keybind key="C-A-KP_Enter">
       <action name="Execute">
             <command>xdotool click 3</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL MIDDLE CLICK-->
      <keybind key="C-A-KP_Delete">
       <action name="Execute">
             <command>xdotool click 2</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT CLICK-->
      <keybind key="C-A-KP_Insert">
       <action name="Execute">
             <command>xdotool click 1</command>
       </action>
      </keybind>

   <!-- MOUSE MOVEMENTS WITHOUT NUMLOCK -->

      <!-- Keybinding for MOUSE CONTROL UP-->
      <keybind key="C-A-KP_Up">
       <action name="Execute">
             <command>xwit -root -rwarp 0 -5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL DOWN-->

      <keybind key="C-A-KP_Down">
       <action name="Execute">
                <command>xwit -root -rwarp 0 5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT-->
      <keybind key="C-A-KP_Left">
       <action name="Execute">
             <command>xwit -root -rwarp -5 0</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT UP-->
      <keybind key="C-A-KP_Home">
       <action name="Execute">
             <command>xwit -root -rwarp -5 -5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT DOWN-->
      <keybind key="C-A-KP_End">
       <action name="Execute">
             <command>xwit -root -rwarp -5 5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT-->
      <keybind key="C-A-KP_Right">
       <action name="Execute">
             <command>xwit -root -rwarp 5 0</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT UP-->
      <keybind key="C-A-KP_Prior">
       <action name="Execute">
             <command>xwit -root -rwarp 5 -5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT DOWN-->
      <keybind key="C-A-KP_Next">
       <action name="Execute">
             <command>xwit -root -rwarp 5 5</command>
       </action>
      </keybind>


   <!-- FAST MOUSE MOVEMENTS WITHOUT NUMLOCK -->

      <!-- Keybinding for MOUSE CONTROL UP FAST-->
      <keybind key="S-C-A-KP_Up">
       <action name="Execute">
             <command>xwit -root -rwarp 0 -25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL DOWN FAST-->

      <keybind key="S-C-A-KP_Down">
       <action name="Execute">
                <command>xwit -root -rwarp 0 25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT FAST-->
      <keybind key="S-C-A-KP_Left">
       <action name="Execute">
             <command>xwit -root -rwarp -25 0</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT UP FAST-->
      <keybind key="S-C-A-KP_Home">
       <action name="Execute">
             <command>xwit -root -rwarp -25 -25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT DOWN FAST-->
      <keybind key="S-C-A-KP_End">
       <action name="Execute">
             <command>xwit -root -rwarp -25 25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT FAST-->
      <keybind key="S-C-A-KP_Right">
       <action name="Execute">
             <command>xwit -root -rwarp 25 0</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT UP FAST-->
      <keybind key="S-C-A-KP_Prior">
       <action name="Execute">
             <command>xwit -root -rwarp 25 -25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT DOWN FAST-->
      <keybind key="S-C-A-KP_Next">
       <action name="Execute">
             <command>xwit -root -rwarp 25 25</command>
       </action>
      </keybind>


      <!-- MOUSE CLICKS WITH NUMLOCK ON -->

      <!-- Keybinding for MOUSE CONTROL RIGHT CLICK-->
      <keybind key="C-A-KP_Enter">
       <action name="Execute">
             <command>xdotool click 3</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL MIDDLE CLICK-->
      <keybind key="C-A-KP_Decimal">
       <action name="Execute">
             <command>xdotool click 2</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT CLICK-->
      <keybind key="C-A-KP_0">
       <action name="Execute">
             <command>xdotool click 1</command>
       </action>
      </keybind>

   <!-- MOUSE MOVEMENTS WITH NUMLOCK ON -->

      <!-- Keybinding for MOUSE CONTROL UP-->
      <keybind key="C-A-KP_8">
       <action name="Execute">
             <command>xwit -root -rwarp 0 -5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL DOWN-->

      <keybind key="C-A-KP_2">
       <action name="Execute">
                <command>xwit -root -rwarp 0 5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT-->
      <keybind key="C-A-KP_4">
       <action name="Execute">
             <command>xwit -root -rwarp -5 0</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT UP-->
      <keybind key="C-A-KP_7">
       <action name="Execute">
             <command>xwit -root -rwarp -5 -5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT DOWN-->
      <keybind key="C-A-KP_1">
       <action name="Execute">
             <command>xwit -root -rwarp -5 5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT-->
      <keybind key="C-A-KP_6">
       <action name="Execute">
             <command>xwit -root -rwarp 5 0</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT UP-->
      <keybind key="C-A-KP_9">
       <action name="Execute">
             <command>xwit -root -rwarp 5 -5</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT DOWN-->
      <keybind key="C-A-KP_3">
       <action name="Execute">
             <command>xwit -root -rwarp 5 5</command>
       </action>
      </keybind>


   <!-- Fast Mouse Movements -->

      <!-- Keybinding for MOUSE CONTROL UP FAST-->
      <keybind key="S-C-A-KP_8">
       <action name="Execute">
             <command>xwit -root -rwarp 0 -25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL DOWN FAST-->

      <keybind key="S-C-A-KP_2">
       <action name="Execute">
                <command>xwit -root -rwarp 0 25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT FAST-->
      <keybind key="S-C-A-KP_4">
       <action name="Execute">
             <command>xwit -root -rwarp -25 0</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT UP FAST-->
      <keybind key="S-C-A-KP_7">
       <action name="Execute">
             <command>xwit -root -rwarp -25 -25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL LEFT DOWN FAST-->
      <keybind key="S-C-A-KP_1">
       <action name="Execute">
             <command>xwit -root -rwarp -25 25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT FAST-->
      <keybind key="S-C-A-KP_6">
       <action name="Execute">
             <command>xwit -root -rwarp 25 0</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT UP FAST-->
      <keybind key="S-C-A-KP_9">
       <action name="Execute">
             <command>xwit -root -rwarp 25 -25</command>
       </action>
      </keybind>

      <!-- Keybinding for MOUSE CONTROL RIGHT DOWN FAST-->
      <keybind key="S-C-A-KP_3">
       <action name="Execute">
             <command>xwit -root -rwarp 25 25</command>
       </action>
      </keybind>

    <!--
          Adriano H. Hedler - LXDE Translation to Portuguese-BR Helper
          Accessibility Option on LXDE
          Brasil - Paraná - Curitiba
          Site: www.templosite.com 
    -->

 <!-- End Control Mouse using Keyboard -->
