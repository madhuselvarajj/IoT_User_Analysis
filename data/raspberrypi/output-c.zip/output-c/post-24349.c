apt-cache search mosquitto
libmosquitto-dev - MQTT version 3.1 client library, development files
libmosquitto1 - MQTT version 3.1 client library
libmosquittopp-dev - MQTT version 3.1 client C++ library, development files
libmosquittopp1 - MQTT version 3.1 client C++ library
mosquitto - MQTT version 3.1/3.1.1 compatible message broker
mosquitto-clients - Mosquitto command line MQTT clients
mosquitto-dbg - debugging symbols for mosquitto binaries
python-mosquitto - MQTT version 3.1 Python client library
python3-mosquitto - MQTT version 3.1 Python 3 client library
libmosquitto0 - MQTT version 3.1 client library
libmosquitto0-dev - MQTT version 3.1 client library, development files
libmosquittopp0 - MQTT version 3.1 client C++ library
libmosquittopp0-dev - MQTT version 3.1 client C++ library, development files
