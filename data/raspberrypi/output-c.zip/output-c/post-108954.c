def mycallback(gpio, level, tick):
   read_adc(adc, lsb)

cb = pi.callback(19,pigpio.RISING_EDGE, mycallback)
while(pwm_p.is_alive()):
   time.sleep(1)
