rpi ~$ iw dev
phy#1
    Interface wlan1
        ifindex 5
        wdev 0x100000001
        addr 9a:9f:4d:64:fa:0d
        ssid TestNet
        type managed
        channel 6 (2437 MHz), width: 20 MHz, center1: 2437 MHz
        txpower 30.00 dBm
phy#0
    Unnamed/non-netdev interface
        wdev 0x2
        addr aa:66:d1:aa:f6:19
        type P2P-device
        txpower 31.00 dBm
    Interface wlan0
        ifindex 4
        wdev 0x1
        addr dc:a6:32:01:db:ed
        ssid RPiNet
        type AP
        channel 6 (2437 MHz), width: 20 MHz, center1: 2437 MHz
        txpower 31.00 dBm
