{
  "flavours": [
    {
      "name": "Raspbian - Boot to Scratch",
      "description": "A version of Raspbian that boots straight into Scratch",
      "supported_hex_revisions": "2,3,4,5,6,7,8,9,d,e,f,10,11,12,14,19,1040,1041"
    },
    {
      "name": "Raspbian",
      "description": "A Debian wheezy port, optimised for the Raspberry Pi",
      "supported_hex_revisions": "2,3,4,5,6,7,8,9,d,e,f,10,11,12,14,19,1040,1041"
    }
  ]
}
