wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
    inet 192.168.178.86  netmask 255.255.255.0  broadcast 192.168.178.255
    ether b8:27:eb:0c:d8:21  txqueuelen 1000  (Ethernet)
    RX packets 8  bytes 1842 (1.7 KiB)
    RX errors 0  dropped 0  overruns 0  frame 0
    TX packets 11  bytes 1601 (1.5 KiB)
    TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
