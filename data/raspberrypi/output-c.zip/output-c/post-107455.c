rpi ~$ resolvectl query google.com
google.com: 172.217.169.14                     -- link: eth0

-- Information acquired via protocol DNS in 79.9ms.
-- Data is authenticated: no

rpi ~$ resolvectl query robotNo7.local
robotNo7.local: fe80::217:9aff:feb9:6ea9%3         -- link: wlan0

-- Information acquired via protocol mDNS/IPv6 in 124.5ms.
-- Data is authenticated: no

rpi ~$ resolvectl -4 query robotNo7.local
robotNo7.local: 192.168.4.253                      -- link: wlan0

-- Information acquired via protocol mDNS/IPv4 in 205.1ms.
-- Data is authenticated: no

rpi ~$ resolvectl query robotNo7
robotNo7: 192.168.4.253                            -- link: wlan0

-- Information acquired via protocol LLMNR/IPv4 in 123.4ms.
-- Data is authenticated: no

rpi ~$ ping -c3 robotNo7
PING robotNo7 (192.168.4.253) 56(84) bytes of data.
64 bytes from robotNo7.local (192.168.4.253): icmp_seq=1 ttl=64 time=5.47 ms
64 bytes from robotNo7.local (192.168.4.253): icmp_seq=2 ttl=64 time=1.40 ms
64 bytes from robotNo7.local (192.168.4.253): icmp_seq=3 ttl=64 time=2.51 ms

rpi ~$ ssh pi@robotNo7.local hostname
pi@robotNo7.local's password:
robotNo7
rpi ~$
