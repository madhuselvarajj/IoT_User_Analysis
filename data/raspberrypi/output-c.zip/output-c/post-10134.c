0.2.8.3.2-1 dedicated game server for Armagetron Advanced</li>
<h3>blobby-server</h3>
1.0~rc1-2 Volleyball game with blobs (server)</li>
<h3>bzflag-server</h3>
2.0.16.20100405+nmu1 bzfs - BZFlag game server</li>
1.70.0-1 Architecture independent common files for Crossfire server</li>
<h3>darkplaces-server</h3>
0~20110628+svn11619-3 Standalone server for Quake-based games</li>
<h3>freeciv-server</h3>
2.3.2-1 Civilization turn based strategy game (server files)</li>
