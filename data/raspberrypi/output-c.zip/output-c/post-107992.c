Pin                             WM8960      Raspberry
------------------------------------------------------
VCC (+3V3 OUT)                  1 + 2          4 + Voltage regulator to 3.3 V           
GND                             3 + 4          6 (GND)
SDA (I2C1 SDA)                    5            3 (GPIO 2)
SCL (I2C1 SCL)                    7            5 (GPIO 3)
CLK (I2S)                        10           12 (GPIO 18)            
LRCLK (I2S)                      11           35 (GPIO 19)         
I2S  DAC                         13           40 (GPIO 21)
I2S  ADC                         14           38 (GPIO 20)
