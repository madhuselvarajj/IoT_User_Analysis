a22082 == 1 010 0010 0010 00001000 0010

F = 1 (new format revision code)
MMM = 010 (2) (1GB) 
CCCC = 0010 (2) (Embest)
PPPP = 0010 (2) (BCM2837)
TTTTTTTT = 00001000 (08) (3B)
RRRR = 0010 (2) (rev2)
