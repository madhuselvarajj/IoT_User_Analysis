#include <errno.h>;
#include <string.h>;  // for strerror()
[...]

const char *dev = "/dev/ttyAMA0";

if ((handle = serialOpen (dev, 19200)) < 0) {
    printf("Could not open %s: %s\n", dev, strerror(errno));
    return -1;
}
