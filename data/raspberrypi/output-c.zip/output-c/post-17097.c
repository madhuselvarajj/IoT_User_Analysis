$ free
             total       used       free     shared    buffers     cached
Mem:        496948     260252     236696          0       6560     210968
-/+ buffers/cache:      42724     454224
Swap:       102396      21940      80456
$
