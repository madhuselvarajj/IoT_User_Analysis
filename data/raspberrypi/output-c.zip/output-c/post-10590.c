   var times = 0;

    var refreshId = window.setInterval(function(){
      // check refresh!
      $.ajax({
        type : "GET",
        url : "check.php",
        cache : false,
        success: function(data){
          var data = $.parseJSON(data);
          var refresh = data.refresh;

          if(refresh == 1){
            location.reload();
          }
...
