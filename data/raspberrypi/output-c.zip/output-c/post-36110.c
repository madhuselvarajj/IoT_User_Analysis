pcm.!default {
    type hw
    card 0
}

ctl.!default {
    type hw
    card 0
}
