Bit Number    Reason that got the kernel tainted
 0       1    proprietary module was loaded
 1       2    module was force loaded
 2       4    kernel running on an out of specification system
 3       8    module was force unloaded
 4      16    processor reported a Machine Check Exception (MCE)
 5      32    bad page referenced or some unexpected page flags
 6      64    taint requested by userspace application
 7     128    kernel died recently, i.e. there was an OOPS or BUG
 8     256    ACPI table overridden by user
 9     512    kernel issued warning
10    1024    staging driver was loaded
11    2048    workaround for bug in platform firmware applied
12    4096    externally-built (“out-of-tree”) module was loaded
13    8192    unsigned module was loaded
14   16384    soft lockup occurred
15   32768    kernel has been live patched
16   65536    auxiliary taint, defined for and used by distros
17  131072    kernel was built with the struct randomization plugin
