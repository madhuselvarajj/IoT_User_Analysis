pcm.usb
{
    type hw
    card 1
}
pcm.internal
{
    type hw
    card 0
}

pcm.!default {
    type asym
    playback.pcm {
        type plug
        slave.pcm "internal"
    }
    capture.pcm {
        type plug
        slave.pcm "usb"
    }
}
ctl.!default {
    type asym
    playback.pcm {
        type plug
        slave.pcm "internal"
    }
    capture.pcm {
        type plug
        slave.pcm "usb"
    }
}    
