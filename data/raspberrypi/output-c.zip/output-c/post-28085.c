network={
    ssid="Chupavi D-Link"
    psk="xxx"
    proto=RSN
    key_mgmt=WPA-PSK
    pairwise=CCMP
    auth_alg=OPEN
    id_str="wifi_oslo"
}

network={
    ssid="rudani"
    psk="xxx"
    proto=RSN
    key_mgmt=WPA-PSK
    pairwise=CCMP
    auth_alg=OPEN
    id_str="wifi_bg"
}
