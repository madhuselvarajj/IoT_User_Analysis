version: '3.6'
services:
  nextcloud:
    volumes:
    - ./volumes/nextcloud/html:/var/www/html

    image: nextcloud
    container_name: nextcloud
    ports:
    - "9321:80"
    restart: unless-stopped
    depends_on:
    - nextcloud_db
    links:
    - nextcloud_db
    networks:
    - iotstack_nw
    - nextcloud_internal
    environment:
    - MYSQL_HOST=nextcloud_db
    - MYSQL_PASSWORD=mySQL_password
    - MYSQL_DATABASE=nextcloud
    - MYSQL_USER=nextcloud

  nextcloud_db:
    environment:
    - MYSQL_ROOT_PASSWORD=root_password
    - MYSQL_PASSWORD=mySQL_password
    - MYSQL_DATABASE=nextcloud
    - MYSQL_USER=nextcloud

    image: linuxserver/mariadb
    container_name: nextcloud_db
    volumes:
    - ./volumes/nextcloud/db:/config
    restart: unless-stopped
    networks:
    - nextcloud_internal

  mariadb:
    environment:
    - MYSQL_ROOT_PASSWORD=root_password
    - MYSQL_PASSWORD=mySQL_password
    - MYSQL_DATABASE=nextcloud
    - MYSQL_USER=nextcloud
    image: linuxserver/mariadb
    container_name: mariadb
    volumes:
    - ./volumes/mariadb/config:/config
    ports:
    - "3306:3306"
    restart: unless-stopped
    networks:
    - iotstack_nw
  portainer-ce:
    container_name: portainer-ce
    image: portainer/portainer-ce
    restart: unless-stopped
    ports:
    - "8000:8000"
    - "9000:9000"
    volumes:
    - /var/run/docker.sock:/var/run/docker.sock
    - ./volumes/portainer-ce/data:/data
  pihole:
    container_name: pihole
    image: pihole/pihole:latest
    restart: unless-stopped
    ports:
    - "5053:53/udp"
    - "5053:53/tcp"
    - "9322:80"
    - "8443:443"
    environment:
    - TZ:America/Chicago
    volumes:
    - ./etc-pihole/:/etc/pihole/
    - ./etc-dnsmasq.d/:/etc/dnsmasq.d/
    dns:
    - 127.0.0.1
    - 1.1.1.1
  apacheserver:
    container_name: apache
    image: httpd:2.4
    restart: unless-stopped
    ports:
    - "9320:80"
    - "9443:443"
    volumes:
    - ./volumes/apache/:/usr/local/apache2/htdocs

networks:
  iotstack_nw: # Exposed by your host.
    # external: true
    name: IOTstack_Net
    driver: bridge
    ipam:
      driver: default
      config:
      - subnet: 10.77.60.0/24
        # - gateway: 10.77.60.1

  iotstack_nw_internal: # For interservice communication. No access to outside
    name: IOTstack_Net_Internal
    driver: bridge
    internal: true
    ipam:
      driver: default
      config:
      - subnet: 10.77.76.0/24
        # - gateway: 10.77.76.1 
  nextcloud_internal: # Network for NextCloud service
    name: IOTstack_NextCloud
    driver: bridge
    internal: true

  # default:
  #   external: true
  #   name: iotstack_nw

  # hosts_nw:
  #   driver: hosts
