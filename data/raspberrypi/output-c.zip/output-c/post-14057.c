// Old                                  
  for (rep=0; rep<10; rep++)            
  {                     
    for (g=7; g<=11; g++)     // Delete    
     {                        // Delete    
       GPIO_SET = 1<<g;       // Delete    
       sleep(1);              // Delete    
     }                        // Delete    
     for (g=7; g<=11; g++)    // Delete    
     {                        // Delete    
       GPIO_CLR = 1<<g;       // Delete    
       sleep(1);              // Delete    
     }                        // Delete    
  }                     

  // New                    
  for (rep=0; rep<10; rep++)            
  {                     
    // Toggle GPIO 7 & 8 concurrently       
    GPIO_SET = 3<<7;       // Added         
    sleep(1);              // Added         
    GPIO_CLR = 3<<7;       // Added         
    sleep(1);              // Added         
  }     
