Creating network "IOTstack_NextCloud" with driver "bridge"
Creating network "IOTstack_Net" with driver "bridge"
Creating network "iotstack_default" with the default driver
Creating pihole       ... done
Creating nextcloud_db ... done
Creating portainer-ce ... done
Creating mariadb      ... done
Creating apache       ... done
Creating nextcloud    ... done
