rpi ~$ wpa_cli
--- snip ---
Selected interface 'p2p-dev-wlan0'
Interactive mode

> p2p_group_add freq=5
OK
<3>P2P-GROUP-STARTED p2p-wlan0-0 GO ssid="DIRECT-Vv" freq=5220 passphrase="i9rEDnPw" go_dev_addr=a6:78:e7:1f:37:2f
> quit
