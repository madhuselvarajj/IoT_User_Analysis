def getFile(self, gotPath, packageSize):
    """
    Collects arriving packets
    """
    if (packageSize == None):
        packageSize = 1024
    name = self.socket.recv(packageSize)
    f = open(name, wb)
    packet = 1
    while packet:
        packet = self.socket.recv(packageSize)
        f.write(packet)
    self.isFileGot= True
    f.close()
    print ("File GOT")
