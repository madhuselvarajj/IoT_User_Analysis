var rpio = require('rpio');
rpio.init({mapping: 'gpio'});
var exec = require('child_process').exec;
rpio.open(17, rpio.INPUT, rpio.PULL_DOWN);
rpio.open(18, rpio.INPUT, rpio.PULL_DOWN);

var z = "";
var xTime;
function y(pin)
{

clearTimeout(xTime)

if (pin == 17) {
    z = z + "0";
    }
    if (pin == 18) {
        z = z + "1";
    }
xTime = setTimeout(CheckAccessMain,1000)
}

rpio.poll(17, y, rpio.POLL_LOW);
rpio.poll(18, y, rpio.POLL_LOW);

function CheckAccessMain() {
if (z.length != 26) {
z="";
return;
}
if (z == "10111011000000110010001111") { //check if access card is correct
console.log("access granted!");
exec('omxplayer /root/rfid_make_sound/LOZ_Secret.wav', function callback(error, stdout, stderr){})

rpio.mode(21, rpio.OUTPUT);  //open lock

setTimeout(function() {
rpio.mode(21, rpio.INPUT); //close lock after 3 seconds
    }, 3000);

} else {
console.log("Access Denied!");
exec('omxplayer /root/rfid_make_sound/jurass01.mp3', function callback(error, stdout, stderr){})
}

clearTimeout(xTime)
console.log(z);
console.log(z.length)
z = "";
}
z="";
