arm_freq=800
gpu_mem=128
h264_freq=350
force_turbo=1
core_freq=500
