sudo modinfo g_mass_storage|grep parm|awk -F ':' '{print $2}'
           idVendor
           idProduct
           bcdDevice
           iSerialNumber
           iManufacturer
           iProduct
           file
           ro
           removable
           cdrom
           nofua
           luns
           stall
