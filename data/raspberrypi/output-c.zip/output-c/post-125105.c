eth_led0                Set mode of LED0 - amber on Pi3B+ (default "1"),
                        green on Pi4 (default "0").
                        The legal values are:
                        Pi3B+
                        0=link/activity          1=link1000/activity
                        2=link100/activity       3=link10/activity
                        4=link100/1000/activity  5=link10/1000/activity
                        6=link10/100/activity    14=off    15=on
                        Pi4
                        0=Speed/Activity         1=Speed
                        2=Flash activity         3=FDX
                        4=Off                    5=On
                        6=Alt                    7=Speed/Flash
                        8=Link                   9=Activity
eth_led1                Set mode of LED1 - green on Pi3B+ (default "6"),
                        amber on Pi4 (default "8"). See eth_led0 for
                        legal values.
