Current Input = 1A to 1.2A  (if you did not purchase a higher rated adapter with the B+)

Current Required = Keyboard + Wifi + Uno + Mega + RFID + Pi
                 = 100 + 100 + 200 + 200 + 20 + 700 (Taking conservative values)
                 = 1320 mA
