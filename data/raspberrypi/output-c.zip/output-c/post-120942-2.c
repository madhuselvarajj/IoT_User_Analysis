root@pi-admin:~# cryptsetup benchmark
# Tests are approximate using memory only (no storage IO).

PBKDF2-sha1       477493 iterations per second for 256-bit key
PBKDF2-sha256     776722 iterations per second for 256-bit key
PBKDF2-sha512     639375 iterations per second for 256-bit key
PBKDF2-ripemd160  395987 iterations per second for 256-bit key
PBKDF2-whirlpool  143091 iterations per second for 256-bit key
argon2i       4 iterations, 328696 memory, 4 parallel threads (CPUs) for 256-bit key (requested 2000 ms time)
argon2id      4 iterations, 329115 memory, 4 parallel threads (CPUs) for 256-bit key (requested 2000 ms time)
#     Algorithm |       Key |      Encryption |      Decryption
        aes-cbc        128b        30.6 MiB/s        61.0 MiB/s
    serpent-cbc        128b               N/A               N/A
    twofish-cbc        128b               N/A               N/A
        aes-cbc        256b        22.8 MiB/s        44.5 MiB/s
    serpent-cbc        256b               N/A               N/A
    twofish-cbc        256b               N/A               N/A
        aes-xts        256b        69.9 MiB/s        60.1 MiB/s
    serpent-xts        256b               N/A               N/A
    twofish-xts        256b               N/A               N/A
        aes-xts        512b        52.4 MiB/s        44.1 MiB/s
    serpent-xts        512b               N/A               N/A
    twofish-xts        512b               N/A               N/A
root@pi-admin:~# 
