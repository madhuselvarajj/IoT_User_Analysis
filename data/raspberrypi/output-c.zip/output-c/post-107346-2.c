Jan 15 19:32:59 raspberrypi dhcpcd[647]: wlan0: carrier acquired
Jan 15 19:32:59 raspberrypi dhcpcd[647]: wlan0: IAID 32:01:db:ed
Jan 15 19:32:59 raspberrypi dhcpcd[647]: wlan0: adding address fe80::dfd3:f31e:1538:b9b6
Jan 15 19:32:59 raspberrypi avahi-daemon[497]: Joining mDNS multicast group on interface wlan0.IPv6 with address fe80::dfd3:f31e:1538:b9b6.
Jan 15 19:32:59 raspberrypi avahi-daemon[497]: New relevant interface wlan0.IPv6 for mDNS.
Jan 15 19:32:59 raspberrypi avahi-daemon[497]: Registering new address record for fe80::dfd3:f31e:1538:b9b6 on wlan0.*.
Jan 15 19:32:59 raspberrypi dhcpcd[647]: wlan0: soliciting an IPv6 router
Jan 15 19:33:00 raspberrypi dhcpcd[647]: wlan0: rebinding lease of 192.168.50.194
Jan 15 19:33:00 raspberrypi dhcpcd[647]: wlan0: probing address 192.168.50.194/24
Jan 15 19:33:05 raspberrypi dhcpcd[647]: wlan0: leased 192.168.50.194 for 3600 seconds
Jan 15 19:33:05 raspberrypi avahi-daemon[497]: Joining mDNS multicast group on interface wlan0.IPv4 with address 192.168.50.194.
Jan 15 19:33:05 raspberrypi avahi-daemon[497]: New relevant interface wlan0.IPv4 for mDNS.
Jan 15 19:33:05 raspberrypi avahi-daemon[497]: Registering new address record for 192.168.50.194 on wlan0.IPv4.
Jan 15 19:33:05 raspberrypi dhcpcd[647]: wlan0: adding route to 192.168.50.0/24
Jan 15 19:33:05 raspberrypi dhcpcd[647]: wlan0: adding default route via 192.168.50.1
Jan 15 19:33:12 raspberrypi dhcpcd[647]: wlan0: no IPv6 Routers available
