def somefunction(anchor, sequence)
    if sequence <= anchor :
        camera.capture_sequence(outputs ,'jpeg' , use_video_port=True)
        somefunction(anchor, sequence +1)
        #Save, or whatever, your photo here, be cautious about setting too large anchor, it might hang.
