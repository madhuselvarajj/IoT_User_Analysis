rpi ~$ sudo iw dev wlan0 set txpower fixed 100
rpi ~$ iw dev wlan0 info
Interface wlan0
        ifindex 3
        wdev 0x1
        addr dc:a6:32:01:db:ed
        ssid TestNet
        type managed
        wiphy 0
        channel 6 (2437 MHz), width: 20 MHz, center1: 2437 MHz
        txpower 1.00 dBm
