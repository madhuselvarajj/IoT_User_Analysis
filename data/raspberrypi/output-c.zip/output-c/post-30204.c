> git log Makefile
commit c963de6d8caec6278c0dde76831f9fdab5bace52
Author: Sasha Levin <sasha.levin@oracle.com>
Date:   Mon Apr 20 15:48:02 2015 -0400

    Linux 3.18.12

    Signed-off-by: Sasha Levin <sasha.levin@oracle.com>

commit f154a14e3efa547025d014d0a3f29396f03b1f74
Author: Sasha Levin <sasha.levin@oracle.com>
Date:   Fri Apr 3 22:46:37 2015 -0400

    Linux 3.18.11

    Signed-off-by: Sasha Levin <sasha.levin@oracle.com>

commit 96e199f1751e707a7a8c04d9b079f84df2e0d4ff
Author: Sasha Levin <sasha.levin@oracle.com>
Date:   Mon Mar 23 21:05:12 2015 -0400

    Linux 3.18.10

    Signed-off-by: Sasha Levin <sasha.levin@oracle.com>

[...]
