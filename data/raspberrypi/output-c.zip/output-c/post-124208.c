def countRain(rainPin):
    global totalRain
    global currentRain

    if (GPIO.input(rainPin) == False) :
        totalRain += .012
        currentRain += .012
   
GPIO.add_event_detect(rainPin, GPIO.FALLING, callback=countRain, bouncetime=100)
