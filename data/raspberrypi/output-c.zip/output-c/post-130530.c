/*
This program toggles a GPIO pin and measures rate.
Using wiringPi

TO BUILD

gcc -Wall -o bench-wiringPi bench-wiringPi.c -lwiringPi

sudo ./bench-wiringPi

*/

// 2021-08-06

#define SigOUT 12
#define LOOPS 20000

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <wiringPi.h>

int main(void) {
  unsigned t0, t1;
  unsigned i;

  wiringPiSetupGpio();
  pinMode(SigOUT, OUTPUT);

  t0 = micros();

  for (i = 0; i < LOOPS + 1; i++) {
    digitalWrite(SigOUT, HIGH);
    digitalWrite(SigOUT, LOW);
  }
  t1 = micros();

    printf("WiringPi\t%10.0f toggles per second\n", (1.0e6 * LOOPS) / (t1 - t0));

  return 0;
}
