void software_reset()
{
    watchdog_enable(1, 1);
    while(1);
}
