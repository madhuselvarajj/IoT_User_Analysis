May 21 16:50:22 raspberrypi dhcpcd[418]: wlan0: carrier acquired
May 21 16:50:22 raspberrypi dhcpcd[418]: wlan0: connected to Access Point `T'

May 21 16:51:22 raspberrypi dhcpcd[418]: wlan0: carrier lost

May 21 16:51:23 raspberrypi dhcpcd[418]: wlan0: carrier acquired
May 21 16:51:23 raspberrypi dhcpcd[418]: wlan0: connected to Access Point `H'
