$ apt-cache search arduino
arduino - AVR development board IDE and built-in libraries
arduino-core - Code, examples, and libraries for the Arduino platform
arduino-mighty-1284p - Platform files for Arduino to run on ATmega1284P
arduino-mk - Program your Arduino from the command line
$ 
