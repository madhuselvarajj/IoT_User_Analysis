var http = require('http');
let cmdQueue=[];
function proc()
{
  while(cmdQueue.length>0)
  {
        let cmd = cmdQueue.pop();
    cmd.res.writeHead(200, {'Content-Type': 'text/plain'});
    cmd.res.end('Hello World\n');
  }
  setTimeout(function(){ proc(); },1);
};
proc();
http.createServer(function (req, res) {
  setTimeout(function(){
    cmdQueue.push({res:res,req:req});
  },0);
}).listen(1337, '127.0.0.1');
console.log('Server running at http://127.0.0.1:1337/');
