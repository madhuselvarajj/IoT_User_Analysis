If Revision < 4
   pinout type 1
else if Revision < 16
   pinout type 2
else
   pinout type 3

          0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15
Type.1    X  X  -  -  X  -  -  X  X  X  X  X  -  -  X  X
Type.2    -  -  X  X  X  -  -  X  X  X  X  X  -  -  X  X
Type.3          X  X  X  X  X  X  X  X  X  X  X  X  X  X

         16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31
Type.1    -  X  X  -  -  X  X  X  X  X  -  -  -  -  -  -
Type.2    -  X  X  -  -  -  X  X  X  X  -  X  X  X  X  X
Type.3    X  X  X  X  X  X  X  X  X  X  X  X  -  -  -  -
