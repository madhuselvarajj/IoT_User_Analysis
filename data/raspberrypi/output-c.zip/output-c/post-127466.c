ttt.c: In function ‘main’:
ttt.c:13:21: error: ‘THERMO_BUTTON_PIN’ undeclared (first use in this function)
         gpioSetMode(THERMO_BUTTON_PIN, PI_INPUT);
                     ^~~~~~~~~~~~~~~~~
ttt.c:13:21: note: each undeclared identifier is reported only once for each function it appears in
ttt.c:14:21: error: ‘AUDIO_BUTTON_PIN’ undeclared (first use in this function)
         gpioSetMode(AUDIO_BUTTON_PIN, PI_INPUT);
                     ^~~~~~~~~~~~~~~~
ttt.c:17:43: error: ‘HIGH’ undeclared (first use in this function)
         if(gpioRead(THERMO_BUTTON_PIN) == HIGH){
                                           ^~~~
