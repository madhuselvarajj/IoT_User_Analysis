while(1)
{
   // Code to send a pulse
   delay(50);
}
