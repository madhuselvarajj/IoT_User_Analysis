void servo(int servo, int angle) {
switch (servo) {
    case 0:
        servo = SERVO_0;
        break;
    case 1:
        servo = SERVO_1;
        break;  
    default:
        servo = -1;
        break;
}
switch (angle) {
    case 90:
        value = 25;
        break;
    case -90:
        value = 10;
        break;
    case 0:
        value = 14;
        break;  
    default:
        break;
}
if (servo == -1) return;
pwmWrite(servo, value);}
