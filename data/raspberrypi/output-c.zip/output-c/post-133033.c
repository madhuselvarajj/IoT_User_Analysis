pi@raspberrypi:~ $ stat /piusb.bin 
  File: /piusb.bin
  Size: 4294967296  Blocks: 8388616    IO Block: 4096   regular file
Device: b302h/45826d    Inode: 24135       Links: 1
Access: (0644/-rw-r--r--)  Uid: (    0/    root)   Gid: (    0/    root)
Access: 2021-11-02 21:11:48.831225005 +0000
Modify: 2021-11-03 08:23:56.869005088 +0000
Change: 2021-11-03 08:23:56.869005088 +0000
 Birth: -
