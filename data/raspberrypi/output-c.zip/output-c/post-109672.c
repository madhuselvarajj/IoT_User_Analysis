rpi ~$ lsblk
NAME                    MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
sda                       8:0    1  7.5G  0 disk
├─sda1                    8:1    1 43.2M  0 part
└─sda2                    8:2    1  7.5G  0 part
mmcblk0                 179:0    0  3.7G  0 disk
├─mmcblk0p1             179:1    0  256M  0 part /boot
└─mmcblk0p2             179:2    0  3.4G  0 part /
