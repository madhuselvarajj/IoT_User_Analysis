sudo mount -av
/proc                    : already mounted
/boot                    : already mounted
/                        : ignored
/home/pi/mntThumbDrv     : already mounted
/home/pi/mntBackupDrv    : already mounted
/home/pi/mntPassport     : already mounted
/home/pi/mntNetgearNAS-3 : already mounted
