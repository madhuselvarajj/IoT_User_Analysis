int main(int argc, char *argv[])
{
   int done = 0;

   Pi_Wieg_t * w1;
   Pi_Wieg_t * w2;
   if (gpioInitialise() < 0) return 1;
   w1 = Pi_Wieg(14, 15, callback1, 5);
   w2 = Pi_Wieg(23, 24, callback2, 5);
   while (!done)
   {
      sleep(1);

      /* add code here to detect the exit condition (if any)
         and set done = 1
      */
   }
   Pi_Wieg_cancel(w1);
   Pi_Wieg_cancel(w2);
   gpioTerminate();
}
