   -f    Force checking even if the file system seems clean.

   -c    This option causes e2fsck to use badblocks(8) program to do
         a read-only scan of the device in order to find any bad blocks.
         If any bad blocks are found, they are added to the bad block
         inode to prevent them from being allocated to a file or direc‐
         tory.  If this option is specified twice, then the bad block scan
         will be done using a non-destructive read-write test.

   -k    When combined with the -c option, any existing bad blocks in the
         bad blocks list are preserved, and any new bad blocks found by
         running badblocks(8) will be added to the existing bad blocks
         list.

   -y    Assume an answer of `yes' to all questions; allows e2fsck to be
         used non-interactively. This option may not be specified at the
         same time as the -n or -p options.
