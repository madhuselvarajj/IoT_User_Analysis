pi@raspberrypi:~ $ busctl introspect org.freedesktop.timesync1 /org/freedesktop/timesync1
NAME                                TYPE      SIGNATURE          RESULT/VALUE                             FLAGS
org.freedesktop.DBus.Introspectable interface -                  -                                        -
.Introspect                         method    -                  s                                        -
org.freedesktop.DBus.Peer           interface -                  -                                        -
.GetMachineId                       method    -                  s                                        -
.Ping                               method    -                  -                                        -
org.freedesktop.DBus.Properties     interface -                  -                                        -
.Get                                method    ss                 v                                        -
.GetAll                             method    s                  a{sv}                                    -
.Set                                method    ssv                -                                        -
.PropertiesChanged                  signal    sa{sv}as           -                                        -
org.freedesktop.timesync1.Manager   interface -                  -                                        -
.FallbackNTPServers                 property  as                 4 "0.debian.pool.ntp.org" "1.debian.poo… const
.Frequency                          property  x                  -9162                                    -
.LinkNTPServers                     property  as                 0                                        -
.NTPMessage                         property  (uuuuittayttttbtt) 0 4 4 2 -21 137 14465 4 129 215 32 239 … emits-c
.PollIntervalMaxUSec                property  t                  2048000000                               const
.PollIntervalMinUSec                property  t                  32000000                                 const
.PollIntervalUSec                   property  t                  2048000000                               -
.RootDistanceMaxUSec                property  t                  5000000                                  const
.ServerAddress                      property  (iay)              2 4 129 215 160 240                      -
.ServerName                         property  s                  "2.debian.pool.ntp.org"                  -
.SystemNTPServers                   property  as                 0                                        const
