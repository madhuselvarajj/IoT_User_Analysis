network:
    version: 2
    ethernets:
        eth0:
            dhcp4: true
            match:
                driver: bcmgenet smsc95xx lan78xx
            optional: true
            set-name: eth0
wifis:
    wlan0:
      optional: true
      dhcp4: true
      access-points:
         <Your ESSID>:
           password: <Your Pass-Phrase>
