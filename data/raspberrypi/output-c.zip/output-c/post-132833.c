# import all the necessary Adafruit CircuitPython compatibility libraries
# import the gpsd library
import time

# let's assume there's lots of magic code in here that sets up two objects
# 1. display - the interface to the e-ink screen
# 2. gpsd    - the interface to the gpsd daemon

while True:
    sat_count = str(gpsd.sats)                        # get number of satellites seen
    display.fill(Adafruit_EPD.WHITE)                  # clear screen
    display.text(sat_count, 5, 5, Adafruit_EPD.BLACK) # draw your text
    display.display()                                 # update screen
    time.sleep(30)
