    GPIO.setmode(GPIO.BOARD)

    GPIO.setup(redPin, GPIO.OUT)
    GPIO.setup(greenPin, GPIO.OUT)
    GPIO.setup(bluePin, GPIO.OUT)
    
    pR = GPIO.PWM(redPin, 50)
    pG = GPIO.PWM(greenPin, 50)
    pB = GPIO.PWM(bluePin, 50)
    
    pR.start(0)
    pG.start(0)
    pB.start(0)
