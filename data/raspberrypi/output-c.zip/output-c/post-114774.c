<Stream live.flv>
    Feed feed1.ffm
    Format swf
    NoAudio
</Stream>
