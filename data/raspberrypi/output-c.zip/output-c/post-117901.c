struct sched_param param;

param.sched_priority = sched_get_priority_max(SCHED_FIFO);

sched_setscheduler(0, SCHED_FIFO, &param);
