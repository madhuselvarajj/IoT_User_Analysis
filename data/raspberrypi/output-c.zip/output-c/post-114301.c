network:
   ethernets:
        eth0:
           dhcp4: true
            optional: true

    version: 2
    wifis:
      wlan0:
          optional: true
          access-points:
                  "SSID":
                       password: "password"
          dhcp4: true
