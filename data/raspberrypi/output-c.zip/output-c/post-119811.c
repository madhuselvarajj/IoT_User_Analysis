NAME        FSTYPE LABEL       UUID                                 FSAVAIL FSUSE% MOUNTPOINT
sda
└─sda1      ext4   PASSPORT2TB 86645948-d127-4991-888c-a466b7722f05    1.5T    11% /mnt/Passport2TB
sdc
├─sdc1      vfat   boot        592B-C92C
└─sdc2      ext4   rootfs      706944a6-7d0f-4a45-9f8c-7fb07375e9f7
mmcblk0
├─mmcblk0p1 vfat               6969-16D1                             200.4M    22% /boot
└─mmcblk0p2 ext4               f6ea6ef9-68be-479d-b447-5f76391cc02f     23G    16% /
