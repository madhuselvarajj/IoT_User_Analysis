import os
# import other modules

#do other works.

os.system("gpio write 0 0")
