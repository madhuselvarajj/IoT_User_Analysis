Private key: !PRIVATE!

String to hash: rpiserial!PRIVATE!macaddres!PRIVATE!sdserial!PRIVATE!timestamp!PRIVATE!  etc...

HASH : SHA256 recommended
