#include <stdio.h>

int main (int argc, const char *argv[]) 
{
        printf("%d\n", sizeof(char*));
        return 0;
}
