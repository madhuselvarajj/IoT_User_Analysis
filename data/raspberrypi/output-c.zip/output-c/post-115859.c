defaults.bluealsa {
    interface "hci0"            # host Bluetooth adapter
    device "${REQUESTED_BT}"   # ${REQUESTED_BT_NAME}
    profile "a2dp"
}


pcm.hubcap {
    type plug
    slave {
        pcm "hw:Loopback,1,0"
        rate 48000
        format S32_LE
    }
}

pcm.!default {
    type plug
    slave.pcm {
        type dmix
        ipc_key 2867
        slave {
            pcm "hw:Loopback,0,0"
            rate 48000
            format S32_LE
            channels 2
            period_size 1024
            buffer_size 8192
        }
    }
}
