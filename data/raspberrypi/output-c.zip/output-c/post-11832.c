#include <stdio.h>
#include <curl/curl.h>

int main(void)
{
  CURL *curl;
  CURLcode res;
  struct curl_slist *headers = NULL;

  curl = curl_easy_init();
  if(curl) 
  {
    headers = curl_slist_append(headers, "Host: www.google.com");
    headers = curl_slist_append(headers, "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0");
    headers = curl_slist_append(headers, "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
    headers = curl_slist_append(headers, "Accept-Language: en-us,en;q=0.5");
    /* Add more headers here */
    curl_easy_setopt(curl, CURLOPT_URL, "http://www.google.com/");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    res = curl_easy_perform(curl);

    /* Always cleanup */ 
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
  }
  return 0;
}
