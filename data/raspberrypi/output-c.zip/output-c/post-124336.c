#[homes]
#   comment = Home Directories
#   browseable = no
#   read only = yes
#   create mask = 0700
#   valid users = %S
