sda
├─sda1      vfat     FAT32 system-boot A935-223B
└─sda2      ext4     1.0   writable    208c7994-eefe-41da-8c3b-46f745b8a370  207.9G     5% /
mmcblk0
├─mmcblk0p1 vfat     FAT32 system-boot A935-223B                             124.9M    50% /boot/firmware
└─mmcblk0p2 ext2     1.0               413c013b-e740-4ec4-87f6-a5e57866e2ef
