pi       pts/0        10.1.2.100       Mon Jan 11 17:32   still logged in
pi       pts/0        10.1.2.100       Sat Jan  9 18:06 - 13:08 (1+19:01)
pi       pts/0        fe80::1ca4:d038: Fri Jan  8 21:31 - 15:37  (18:06)
runlevel (to lvl 5)   5.4.83-v7l+      Fri Jan  8 21:31   still running
pi       tty1                          Fri Jan  8 21:30   still logged in
pi       tty7         :0               Fri Jan  8 21:30   still logged in
reboot   system boot  5.4.83-v7l+      Thu Jan  1 10:00   still running
shutdown system down  5.4.79-v7l+      Fri Jan  8 21:30 - 10:00 (-18635+10:30)
pi       pts/0        10.1.2.100       Wed Jan  6 17:28 - 21:28 (2+04:00)
pi       pts/0        fe80::1ca4:d038: Tue Jan  5 17:36 - 14:29  (20:52)
pi       pts/0        10.1.2.100       Tue Jan  5 10:06 - 12:22  (02:16)
pi       tty7         :0               Mon Jan  4 16:29 - 21:28 (4+04:59)
pi       tty1                          Mon Jan  4 16:29 - down  (4+05:01)
runlevel (to lvl 5)   5.4.79-v7l+      Mon Jan  4 16:29 - 21:30 (4+05:01)
reboot   system boot  5.4.79-v7l+      Thu Jan  1 10:00 - 21:30 (18635+10:30)
