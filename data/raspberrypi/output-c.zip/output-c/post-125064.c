1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
    link/ether dc:a6:32:6b:06:a2 brd ff:ff:ff:ff:ff:ff
    inet 10.8.42.2/32 scope global eth0
       valid_lft forever preferred_lft forever
    inet6 fe80::dea6:32ff:fe6b:6a2/64 scope link 
       valid_lft forever preferred_lft forever
3: wlanA: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether dc:a6:32:6b:06:a3 brd ff:ff:ff:ff:ff:ff
    inet 192.168.100.124/24 brd 192.168.100.255 scope global noprefixroute wlanA
       valid_lft forever preferred_lft forever
    inet6 fe80::dea6:32ff:fe6b:6a3/64 scope link 
       valid_lft forever preferred_lft forever
