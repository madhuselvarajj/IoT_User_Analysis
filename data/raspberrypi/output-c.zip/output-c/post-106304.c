  Ethernet adapter Ethernet:

  Connection-specific DNS Suffix  . :
  Link-local IPv6 Address . . . . . : fe80::7d8d:1cb5:ec81:51c5%18
  IPv4 Address. . . . . . . . . . . : 192.168.1.59
  Subnet Mask . . . . . . . . . . . : 255.255.255.0
  Default Gateway . . . . . . . . . : 192.168.1.254  

  Wireless LAN adapter Wi-Fi:

  Connection-specific DNS Suffix  . :
  Link-local IPv6 Address . . . . . : fe80::ecad:bd0e:738d:e3ac%3
  IPv4 Address. . . . . . . . . . . : 192.168.10.98
  Subnet Mask . . . . . . . . . . . : 255.255.255.0
  Default Gateway . . . . . . . . . : 192.168.10.1
