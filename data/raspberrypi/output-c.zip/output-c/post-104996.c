diff -Naur bluetooth_usb_driver/rtk_bt.c bluetooth_usb_driver_new/rtk_bt.c
--- bluetooth_usb_driver/rtk_bt.c   2018-09-04 17:51:50.000000000 +0800
+++ bluetooth_usb_driver_new/rtk_bt.c   2019-10-27 10:49:47.840823000 +0800
@@ -2093,7 +2093,7 @@

    if (config_len != filelen - BT_CONFIG_HDRLEN) {
        RTKBT_ERR("config length %d is not right %d", config_len,
-             filelen - BT_CONFIG_HDRLEN);
+             filelen - (int)BT_CONFIG_HDRLEN);
        return 0;
    }

@@ -2287,6 +2287,7 @@
 static int request_bdaddr(u8 *buf)
 {
    int size;
+   loff_t pos=0;
    int rc;
    struct file *file;
    u8 tbuf[BDADDR_STRING_LEN + 1];
@@ -2310,7 +2311,11 @@
        size = BDADDR_STRING_LEN;

    memset(tbuf, 0, sizeof(tbuf));
+#if 0
    rc = kernel_read(file, 0, tbuf, size);
+#else
+   rc = kernel_read(file, tbuf, size, &pos);
+#endif
    fput(file);
    if (rc != size) {
        if (rc >= 0)
diff -Naur bluetooth_usb_driver/rtk_bt.h bluetooth_usb_driver_new/rtk_bt.h
--- bluetooth_usb_driver/rtk_bt.h   2017-12-28 21:22:28.000000000 +0800
+++ bluetooth_usb_driver_new/rtk_bt.h   2019-10-27 10:53:06.151664000 +0800
@@ -43,12 +43,14 @@

 #define BTCOEX

-#if 1
+#if 0
 #define RTKBT_DBG(fmt, arg...) printk(KERN_INFO "rtk_btusb: " fmt "\n" , ## arg)
 #define RTKBT_INFO(fmt, arg...) printk(KERN_INFO "rtk_btusb: " fmt "\n" , ## arg)
 #define RTKBT_WARN(fmt, arg...) printk(KERN_WARNING "rtk_btusb: " fmt "\n", ## arg)
 #else
 #define RTKBT_DBG(fmt, arg...)
+#define RTKBT_INFO(fmt, arg...)
+#define RTKBT_WARN(fmt, arg...)
 #endif

 #if 1
diff -Naur bluetooth_usb_driver/rtk_coex.c bluetooth_usb_driver_new/rtk_coex.c
--- bluetooth_usb_driver/rtk_coex.c 2017-12-28 21:22:28.000000000 +0800
+++ bluetooth_usb_driver_new/rtk_coex.c 2019-10-27 10:52:46.379780000 +0800
@@ -33,10 +33,21 @@

 #define RTK_VERSION "1.2"

+#if 0
 #define RTKBT_DBG(fmt, arg...) printk(KERN_INFO "rtk_btcoex: " fmt "\n" , ## arg)
 #define RTKBT_INFO(fmt, arg...) printk(KERN_INFO "rtk_btcoex: " fmt "\n" , ## arg)
 #define RTKBT_WARN(fmt, arg...) printk(KERN_WARNING "rtk_btcoex: " fmt "\n", ## arg)
+#else
+#define RTKBT_DBG(fmt, arg...)
+#define RTKBT_INFO(fmt, arg...)
+#define RTKBT_WARN(fmt, arg...)
+#endif
+
+#if 1
 #define RTKBT_ERR(fmt, arg...) printk(KERN_WARNING "rtk_btcoex: " fmt "\n", ## arg)
+#else
+#define RTKBT_ERR(fmt, arg...)
+#endif

 static struct rtl_coex_struct btrtl_coex;

@@ -44,9 +55,16 @@
 #define is_profile_busy(profile)        ((btrtl_coex.profile_status & BIT(profile)) > 0)

 static void rtk_handle_event_from_wifi(uint8_t * msg);
+
+#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
 static void count_a2dp_packet_timeout(unsigned long data);
 static void count_pan_packet_timeout(unsigned long data);
 static void count_hogp_packet_timeout(unsigned long data);
+#else
+static void count_a2dp_packet_timeout(struct timer_list *t);
+static void count_pan_packet_timeout(struct timer_list *t);
+static void count_hogp_packet_timeout(struct timer_list *t);
+#endif

 static int rtl_alloc_buff(struct rtl_coex_struct *coex)
 {
@@ -541,8 +559,12 @@
 {
    if (profile_index == profile_a2dp) {
        btrtl_coex.a2dp_packet_count = 0;
+   #if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
        setup_timer(&(btrtl_coex.a2dp_count_timer),
                count_a2dp_packet_timeout, 0);
+   #else
+       timer_setup(&(btrtl_coex.a2dp_count_timer), count_a2dp_packet_timeout, 0);
+   #endif 
        btrtl_coex.a2dp_count_timer.expires =
            jiffies + msecs_to_jiffies(1000);
        add_timer(&(btrtl_coex.a2dp_count_timer));
@@ -550,8 +572,12 @@

    if (profile_index == profile_pan) {
        btrtl_coex.pan_packet_count = 0;
+   #if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
        setup_timer(&(btrtl_coex.pan_count_timer),
                count_pan_packet_timeout, 0);
+   #else
+       timer_setup(&(btrtl_coex.pan_count_timer), count_pan_packet_timeout, 0);
+   #endif
        btrtl_coex.pan_count_timer.expires =
            jiffies + msecs_to_jiffies(1000);
        add_timer(&(btrtl_coex.pan_count_timer));
@@ -563,8 +589,13 @@
            && (0 == btrtl_coex.profile_refcount[profile_voice])) {
            btrtl_coex.hogp_packet_count = 0;
            btrtl_coex.voice_packet_count = 0;
+       #if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
            setup_timer(&(btrtl_coex.hogp_count_timer),
                    count_hogp_packet_timeout, 0);
+       #else
+           timer_setup(&(btrtl_coex.hogp_count_timer),
+                   count_hogp_packet_timeout, 0);
+       #endif 
            btrtl_coex.hogp_count_timer.expires =
                jiffies + msecs_to_jiffies(1000);
            add_timer(&(btrtl_coex.hogp_count_timer));
@@ -954,7 +985,11 @@
    }
 }

+#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
 static void count_a2dp_packet_timeout(unsigned long data)
+#else
+static void count_a2dp_packet_timeout(struct timer_list *t)
+#endif
 {
    RTKBT_DBG("%s: a2dp_packet_count %d", __func__,
            btrtl_coex.a2dp_packet_count);
@@ -971,7 +1006,11 @@
          jiffies + msecs_to_jiffies(1000));
 }

+#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
 static void count_pan_packet_timeout(unsigned long data)
+#else
+static void count_pan_packet_timeout(struct timer_list *t)
+#endif
 {
    RTKBT_DBG("%s: pan_packet_count %d", __func__,
            btrtl_coex.pan_packet_count);
@@ -991,7 +1030,11 @@
          jiffies + msecs_to_jiffies(1000));
 }

+#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
 static void count_hogp_packet_timeout(unsigned long data)
+#else
+static void count_hogp_packet_timeout(struct timer_list *t)
+#endif
 {
    RTKBT_DBG("%s: hogp_packet_count %d", __func__,
            btrtl_coex.hogp_packet_count);
@@ -2299,7 +2342,11 @@
    //}
 }

+#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
 static void polling_bt_info(unsigned long data)
+#else
+static void polling_bt_info(struct timer_list *data)
+#endif
 {
    uint8_t temp_cmd[1];
    RTKBT_DBG("polling timer");
@@ -2325,7 +2372,11 @@

    if (ctl->polling_enable && !btrtl_coex.polling_enable) {
        /* setup polling timer for getting bt info from firmware */
+   #if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
        setup_timer(&(btrtl_coex.polling_timer), polling_bt_info, 0);
+   #else
+       timer_setup(&(btrtl_coex.polling_timer), polling_bt_info, 0);       
+   #endif
        btrtl_coex.polling_timer.expires =
            jiffies + msecs_to_jiffies(ctl->polling_time * 1000);
        add_timer(&(btrtl_coex.polling_timer));
@@ -2541,11 +2592,12 @@
              (void *)udpsocket_recv_data);
    INIT_DELAYED_WORK(&btrtl_coex.l2_work, (void *)rtl_l2_work);

+#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
    init_timer(&btrtl_coex.polling_timer);
    init_timer(&btrtl_coex.a2dp_count_timer);
    init_timer(&btrtl_coex.pan_count_timer);
    init_timer(&btrtl_coex.hogp_count_timer);
-
+#endif
    btrtl_coex.hdev = hdev;
    btrtl_coex.wifi_on = 0;
