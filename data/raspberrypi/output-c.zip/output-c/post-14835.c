// Provisions the pin.
GpioPinDigitalMultipurpose mypin = gpio.provisionDigitalMultipurposePin(RaspiPin.GPIO_04, PinMode.DIGITAL_INPUT);

// Sets it as an Output pin.
mypin.setMode(PinMode.DIGITAL_OUTPUT);

// Sets the state to "high".
mypin.high();

// Sets the state to "low".
mypin.low();

// Sets it as an Input pin.
mypin.setMode(PinMode.DIGITAL_INPUT);
