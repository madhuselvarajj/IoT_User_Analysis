network={
    ssid="wifi_A"
    psk="passwordOfA"
    priority=1 #lower priority
}
network={
   ssid="wifi_B"
   psk="passwordOfB"
   priority=2 #higher priority
}
