network={
      ssid="open"
      key_mgmt=NONE
      id_str="open"
      priority=3
}

network={
        ssid="secure"
        key_mgmt=WPA-EAP
        proto=WPA2
        group=CCMP
        pairwise=CCMP
        eap=TLS
        ca_cert="/etc/certs/cacert.pem"
        client_cert="/etc/certs/client.pem"
        private_key="/etc/certs/client.key"
        private_key_passwd="somepwd"
        identity="me"
        priority=5
}

network={
        ssid="AndroidAP"
        key_mgmt=WPA-PSK
        proto=WPA2
        pairwise=CCMP
        group=CCMP
        psk="SomeP4ssw0rd"
        priority=4
}


network={
        ssid="Spooky"
        key_mgmt=NONE
        group=WEP104
        psk="A4ABC2FC27412D4D23CAEBCA23"
        priority=2
}

network={
        ssid="another"
        key_mgmt=WPA-PSK
        proto=WPA2
        pairwise=CCMP
        group=CCMP
        psk="A very long and secret passphrase here"
        priority=1
}
