Manufacturer    Model               Style            Driver
Anker           AK-A7610011         USB3->GbE        r8152
Belkin          B2B048              USB3->GbE        r8152
CableMatters    202023-BLK          USB2->10/100     r8152, smsc95xx
CableMatters    202013-BLK          UBS3->GbE        r8152
Linksys         USB3GIG-EJ          USB3->GbE        r8152
Trendnet        TU3-ETG             USB3->GbE        ax88179_178a
