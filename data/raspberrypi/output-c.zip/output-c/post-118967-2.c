#include <stdio.h>
#include <stdlib.h>


#include <lgpio.h>
#include <rgpio.h>

/*
gcc -o rt1 rt1.c -lrgpio
./rt1
*/

#define G1 12
#define G2 13

#define FREQ 1000
#define DUTY 50

#define ON_MICS (int)(1e6 / FREQ * DUTY / 100.0)

#define LFLAGS 0

int main(int argc, char *argv[])
{
   int sbc;
   int h;

   sbc = rgpiod_start(NULL, NULL);

   if (sbc < 0)
   {
      printf("connection failed\n");
      exit(-1);
   }

   h = gpiochip_open(sbc, 0);

   if (h < 0)
   {
      printf("gpiochip open failed\n");
      exit(-1);
   }

   if (gpio_claim_output(sbc, h, LFLAGS, G1, 0) != LG_OKAY)
   {
      printf("gpio claim output failed\n");
      exit(-1);
   }

   if (gpio_claim_output(sbc, h, LFLAGS, G2, 0) != LG_OKAY)
   {
      printf("gpio claim output failed\n");
      exit(-1);
   }

   tx_pwm(sbc, h, G1, FREQ, DUTY, 0, 0);
   tx_pwm(sbc, h, G2, FREQ, DUTY, ON_MICS, 0);

   lgu_sleep(30);

   gpiochip_close(sbc, h);

   rgpiod_stop(sbc);
}
