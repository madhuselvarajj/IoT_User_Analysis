module (
        load="imjournal"
        PersistStateInterval="100"
        # So the entire journal isn't read all over again
        # when the rsyslog is restarted.
        StateFile="/run/rsyslog.state"
)
