# Force HDMI-output on,
# and set VNC screen resolution when headless.
# ar - 21-09-2019, 04-10-2019
hdmi_force_hotplug:0=1
hdmi_drive:0=2
hdmi_group:0=2
hdmi_mode:0=82
#core_freq_min=500
# Not yet implemented for RPi4B
hdmi_blanking:0=1
