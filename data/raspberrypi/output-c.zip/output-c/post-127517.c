pcm.hdmi {
    type hw
    card 0
    device 0
} 
pcm.headphones {
    type hw
    card 1
    device 0
}
