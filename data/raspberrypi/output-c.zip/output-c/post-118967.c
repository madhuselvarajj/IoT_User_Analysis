#include <stdio.h>
#include <stdlib.h>

#include <lgpio.h>

/*
gcc -o lt1 lt1.c -llgpio
./lt1
*/

#define G1 12
#define G2 13

#define FREQ 1000
#define DUTY 50

#define ON_MICS (int)(1e6 / FREQ * DUTY / 100.0)

#define LFLAGS 0

int main(int argc, char *argv[])
{
   int h;

   h = lgGpiochipOpen(0);

   if (h < 0)
   {
      printf("gpiochip open failed\n");
      exit(-1);
   }

   if (lgGpioClaimOutput(h, LFLAGS, G1, 0) != LG_OKAY)
   {
      printf("gpio claim output failed\n");
      exit(-1);
   }

   if (lgGpioClaimOutput(h, LFLAGS, G2, 0) != LG_OKAY)
   {
      printf("gpio claim output failed\n");
      exit(-1);
   }

   lgTxPwm(h, G1, FREQ, DUTY, 0, 0);
   lgTxPwm(h, G2, FREQ, DUTY, ON_MICS, 0);

   lguSleep(30);

   lgGpiochipClose(h);
}
