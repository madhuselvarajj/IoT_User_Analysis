Pin Used        Spare
 1  3.3V
 2  5V
 3  --          gpio2 SDA
 4  5V
 5  --          gpio3 SCL
 6  GND
 7  --          gpio4
 8  --          gpio14 TXD
 9  GND
10  --          gpio15 RXD
11  TP IRQ
12  --          gpio18
13  --          gpio27
14  GND
15  --          gpio22
16  --          gpio23
17  3.3V
18  LCD RS
19  MOSI
20  GND
21  MISO
22  Reset
23  SCLK
24  LCD CS
25  GND
26  TP CS
