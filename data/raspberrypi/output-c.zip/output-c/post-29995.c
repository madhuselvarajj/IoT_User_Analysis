{
  "ref": "refs/heads/master",
  "url": "https://api.github.com/repos/Hexxeh/rpi-firmware/git/refs/heads/master",
  "object": {
    "sha": "5b0cbedacf45e111f02d925fa5b1cec9041fb279",
    "type": "commit",
    "url": "https://api.github.com/repos/Hexxeh/rpi-firmware/git/commits/5b0cbedacf45e111f02d925fa5b1cec9041fb279"
  }
}
