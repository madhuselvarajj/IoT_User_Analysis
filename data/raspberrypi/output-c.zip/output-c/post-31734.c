2 - sets the combined flag 
4 0x53 - sets the I2C address (ADXL345) 
7 1 0x32 - writes 1 byte (0x32) 
6 6 - reads six bytes 
3 - clears the combined flag 
0 - end command
