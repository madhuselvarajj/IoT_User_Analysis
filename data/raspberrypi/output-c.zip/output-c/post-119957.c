# demo script showing use of 2 different I2C bus
# I2C-1 has devices 0X48 & 0X4b, I2C-4 has device 0X48
 
import board, busio, time, traceback
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn
from adafruit_extended_bus import ExtendedI2C as I2C
 
# Create two I2C bus, default & custom #4 per /boot/config.txt
i2c_1 = busio.I2C(board.SCL, board.SDA)
i2c_4 = I2C(4) # custom #4 per /boot/config.txt
 
# Create the ADC objects using two I2C bus
ads10 = ADS.ADS1115(i2c_1, address=0x48)
ads13 = ADS.ADS1115(i2c_1, address=0x4b)
ads40 = ADS.ADS1115(i2c_4, address=0x48)
 
# Create single-ended inputs on i2c-1 bus
ch1_48_0 = AnalogIn(ads10, ADS.P0)
ch1_48_1 = AnalogIn(ads10, ADS.P1)
ch1_48_2 = AnalogIn(ads10, ADS.P2)
ch1_48_3 = AnalogIn(ads10, ADS.P3)
 
ch1_4b_0 = AnalogIn(ads13, ADS.P0)
ch1_4b_1 = AnalogIn(ads13, ADS.P1)
ch1_4b_2 = AnalogIn(ads13, ADS.P2)
ch1_4b_3 = AnalogIn(ads13, ADS.P3)
 
# Create single-ended inputs on i2c-4 bus
ch4_48_0 = AnalogIn(ads40, ADS.P0)
ch4_48_1 = AnalogIn(ads40, ADS.P1)
ch4_48_2 = AnalogIn(ads40, ADS.P2)
ch4_48_3 = AnalogIn(ads40, ADS.P3)
 
