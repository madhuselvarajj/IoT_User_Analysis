#TFT to RPi connections 
# PIN TFT RPi 
# 1 backlight 3v3 
# 2 MISO <none> 
# 3 CLK GPIO 24 
# 4 MOSI GPIO 23 
# 5 CS-TFT GND 
# 6 CS-CARD <none> 
# 7 D/C GPIO 25 
# 8 RESET <none> 
# 9 VCC 3V3 
# 10 GND GND 

SCLK = 24 
SDAT = 23 
DC = 25 
pins = [SCLK,SDAT,DC] 
