var noble = require('noble'); // or '@abandonware/noble' if you're using the fork

noble.on('stateChange'), function(state) {
    if (state === 'poweredOn') {
        noble.startScanning();
    }
    else {
        noble.stopScanning();
    }
});

noble.on('discover', function(device) {
    var mac = device.address; // retrieves the MAC address
    ... do something with the MAC address ...
});
