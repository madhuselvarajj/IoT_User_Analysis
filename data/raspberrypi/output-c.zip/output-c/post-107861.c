freq: 5300
beacon interval: 100 TUs
capability: ESS Privacy SpectrumMgmt ShortSlotTime RadioMeasure (0x1511)
signal: -71.00 dBm
last seen: 0 ms ago
SSID: RPiNet
