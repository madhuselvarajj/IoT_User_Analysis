interface wlan0
request 192.168.1.99

interface eth0
request 192.168.1.98
