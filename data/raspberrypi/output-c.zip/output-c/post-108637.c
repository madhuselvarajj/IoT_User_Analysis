wifis:
        wlan0:
            optional: true
            access-points:
                    "SSID-NAME":
                            password: "WIFI-PASSORD"
            dhcp4: yes
