[global]
    workgroup = WORKGROUP
    usershare allow guests = yes
    security=share
    follow symlinks = yes
    wide links = yes
    unix extensions = no
 [pi]
    browsable = yes
    read only = no
    guest ok = yes
    path = /home/pi
    force user = pi
[devices]
    browsable = yes
    read only = no
    guest ok = yes
    path = /media
    force user = root
