FLASK THREAD     
------------

-->REQUEST
FLASK CALLBACK
SERIAL IO (May take up to 1s + more for writes and retries)
PROCESS DATA  
RESPONSE-->

