#include <wiringPi.h>
#include <time.h>
#include <string.h>
#include "gvoice.h"

int sendSMS(void);

#define MOTION_PIN 0
#define MINUTES_TO_WAIT 5

// some made-up error codes for SMS result
#define SUCCESS 0
#define LOGIN_ERROR 1
#define SMS_ERROR 2

static char *number = "2125551212", *message = "Motion detected!";

int main(int argc, char** argv) {
    time_t lastSent, now;
    int result;

    // track the time we sent the last SMS
    lastSent = time(NULL) - 60*(MINUTES_TO_WAIT + 1)

    // set up motion pin
    wiringPiSetup();
    pinMode(MOTION_PIN, INPUT);

    while (true) {
        if (digitalRead(MOTION_PIN)==HIGH) { // motion detected
            // get the current time
            time(&now);

            // if we've waited long enough, send a message
            if (difftime(now, lastSent)/60) > MINUTES_TO_WAIT) {
                if (result = sendSMS()) {
                    print("Message sent!\n");
                    lastSent = now;
                } else {
                    printf("Error %d. Message not sent!\n", result);
                }
            }
        }
    }

}

int sendSMS(void) {
    // Uses the Google Voice C++ API by Steven Hickson
    GoogleVoice gv;
    char *username = "username", *password = "password";

    if (gv.Login(username, password)) {
        if (gv.SendSMS(number, message)) {
            return SUCCESS;
        } else {
            return SMS_ERROR;
        }
    } else {
        return LOGIN_ERROR;
    }
}
