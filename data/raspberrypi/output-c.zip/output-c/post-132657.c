             __spi_sync() {    
3.386 us      __spi_validate();    
2.291 us      _raw_spin_lock_irqsave();    
1.406 us      _raw_spin_unlock_irqrestore();    
2.136 us      _raw_spin_lock_irqsave();    
1.407 us      _raw_spin_unlock_irqrestore();    
2.135 us      _raw_spin_lock_irqsave();    
              __spi_queued_transfer() {    
1.146 us        _raw_spin_lock_irqsave();    
1.042 us        _raw_spin_unlock_irqrestore();    
5.417 us      }  //__spi_queued_transfer    
1.458 us      _raw_spin_unlock_irqrestore();    
2.239 us      _raw_spin_lock_irqsave();    
1.510 us      _raw_spin_unlock_irqrestore();    
2.187 us      _raw_spin_lock_irqsave();    
1.354 us      _raw_spin_unlock_irqrestore();    
              __spi_pump_messages() {    
2.188 us        _raw_spin_lock_irqsave();    
1.562 us        _raw_spin_unlock_irqrestore();    
                mutex_lock() {    
                  _cond_resched() {    
1.718 us            rcu_all_qs();    
5.156 us          }    
8.646 us        }    
                bcm2835_spi_prepare_message [spi_bcm2835]() {    
