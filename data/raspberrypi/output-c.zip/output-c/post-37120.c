#include <GLES2/gl2.h>
...
static void SetGLAttribute(SDL_GLattr attr, int value)
{
    if( SDL_GL_SetAttribute(attr, value) != 0 )
        fprintf( stderr, "SDL_GL_SetAttr failed: %s\n", SDL_GetError() );
}
static void PrintGLString(GLenum name)
{
    const GLubyte* ret = glGetString(name);
    if( ret == 0 )
        fprintf( stderr, "Failed to get GL string: %d\n", name );
    else
        printf( "%s\n", ret );
}
#endif // GL_ES_VERSION_2_0
...
// Let's see if we can use OpenGL ES 2 on Raspberry Pi
SDL_GLContext gl_context = SDL_GL_CreateContext(m_pWindow);
printf("GL_VERSION: "); 
PrintGLString(GL_VERSION);
printf("GL_RENDERER: ");
PrintGLString(GL_RENDERER);
printf("GL_SHADING_LANGUAGE_VERSION: ");
PrintGLString(GL_SHADING_LANGUAGE_VERSION);
printf("GL_EXTENSIONS: ");
PrintGLString(GL_EXTENSIONS);
SDL_GL_DeleteContext(gl_context);
...
static void PrintRendererInfo(SDL_RendererInfo& rendererInfo)
{
    printf( "Renderer: %s software=%d accelerated=%d, presentvsync=%d targettexture=%d\n", 
        rendererInfo.name,
        (rendererInfo.flags & SDL_RENDERER_SOFTWARE) != 0, 
        (rendererInfo.flags & SDL_RENDERER_ACCELERATED) != 0, 
        (rendererInfo.flags & SDL_RENDERER_PRESENTVSYNC) != 0, 
        (rendererInfo.flags & SDL_RENDERER_TARGETTEXTURE) != 0 );
}
...
int numRenderDrivers = SDL_GetNumRenderDrivers();
printf( "%d render drivers:\n", numRenderDrivers );
for( int i = 0; i < numRenderDrivers; ++i )
{
    SDL_RendererInfo rendererInfo;
    SDL_GetRenderDriverInfo(i, &rendererInfo);
    printf( "%d ", i );
    PrintRendererInfo(rendererInfo);
}

Uint32 rendererFlags = SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;
m_pSdlRenderer = SDL_CreateRenderer( &window, -1, rendererFlags );
if(!m_pSdlRenderer)
{
    fprintf( stderr, "SDL_CreateRenderer failed: %s\n", SDL_GetError() );
}

SDL_RendererInfo rendererInfo;
if( SDL_GetRendererInfo(m_pSdlRenderer, &rendererInfo) != 0 )
{
    fprintf( stderr, "SDL_GetRendererInfo failed: %s\n", SDL_GetError() );
}
printf( "Created renderer:\n" );
PrintRendererInfo(rendererInfo);
