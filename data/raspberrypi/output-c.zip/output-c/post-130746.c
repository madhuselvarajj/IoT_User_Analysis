// Overlay for max30102 heart rate sensor

/dts-v1/; 
/plugin/; 

/ {
    compatible = "brcm,bcm2835";

    fragment@0 {
        target = <&i2c_arm>;

        __overlay__ {
            #address-cells = <1>;
            #size-cells = <0>;

            max30102: heart-rate@57 {
                compatible = "maxim,max30102";
                reg = <0x57>;
                maxim,red-led-current-microamp = <7000>;
                maxim,ir-led-current-microamp  = <7000>;
                interrupt-parent  = <&gpio>;
                interrupts = <4 2>;
            };
        };
    };

    __overrides__ {
        int_pin = <&max30102>, "interrupts:0";
    };
};
