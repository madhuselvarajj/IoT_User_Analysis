while True:
    try:
        if (GPIO.input(23)):               #When switched high
            soundChannelA.queue(sndA)      #Play sound a
            while (GPIO.input(23))         #While switch remains high
                soundChannelA.queue(sndb)  #Play sound b
            soundChannelA.queue(sndc)      #Play sound c
        sleep(.01)
    except KeyboardInterrupt:
        exit()
