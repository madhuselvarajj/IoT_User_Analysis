   {
     "name": "Raspbian",
     "url": "http://www.raspbian.org/",
     "version": "wheezy",
     "release_date": "2014-01-07",
     "kernel": "3.10",
     "description": "A community-created port of Debian wheezy, optimised for the Raspberry Pi",
     "username": "pi",
     "password": "raspberry"
   }
