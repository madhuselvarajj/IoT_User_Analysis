bool printb = 0;

if(printb = 0)
{
  println(a);
  printb = 1;
}
else
{
 println(b);
 printb = 0;
}
