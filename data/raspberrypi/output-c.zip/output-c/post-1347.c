server.modules = (
            "mod_access",
            "mod_alias",
            "mod_accesslog",
            "mod_auth",
            "mod_ssi",
            "mod_cgi",
            "mod_compress",
            "mod_fastcgi",
            "mod_rewrite",
            "mod_magnet",
)
