#set file name
filename = "input.xls"
outputfilename = "output.pdf"

#upload file to aspose cloud storage
storageApi.PutCreate(Path=filename)

#convert file to pdf
response = cellsApi.PostDocumentSaveAs(name=filename, body=body, newfilename=outputfilename)
destfilename = response.SaveResult.DestDocument.Href

#download converted file from storage server
response = storageApi.GetDownload(Path=destfilename)

