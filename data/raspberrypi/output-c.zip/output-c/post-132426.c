#include <stdio.h>
#include <pigpio.h>

// Default BANK = 0 sequential addressing

#define GPPUA   0x0C   // Pull up resistors, bank A
#define GPPUB   0x0D   // Pull up resistors, bank B
#define GPIOA   0x12   // GPIO bank A
#define GPIOB   0x13   // GPIO bank B
#define ADDRESS 0x00   // A0, A1 and A2 are low 

// Commands are of the form 0 1 0 0 A2 A1 A0 R/W
#define WRITE_COMMAND 0x40 | (ADDRESS << 1); 
#define READ_COMMAND  0x40 | (ADDRESS << 1) | 0x01;  

#define CS   24
#define MISO 16
#define MOSI 20
#define SCLK 21
#define BAUD 250000
#define FLAGS 0

void initialise();
void enablePullUp();

int main()
{
    unsigned char buffer[4];
    char command[4];

    initialise();
    enablePullUp();

    // Read from both banks
    command[0] = READ_COMMAND;
    command[1] = GPIOA;
    command[2] = GPIOB;
    command[3] = 0;

    bbSPIXfer(CS, command, (char *)buffer, sizeof(command)); 

    printf("GPIOA: %d\n", buffer[2]);
    printf("GPIOB: %d\n", buffer[3]);

    // Pin values are present in buffer[2] and buffer[3]. 
    // Store both banks in a single combined value.
    int combinedValue = (buffer[2] << 8) | buffer[3];

    // Convert to bits
    unsigned char values[16];
    for (int i = 0; i < 16; i++)
    {
        // Invert bit value for display so 1 is on
        values[i] = (combinedValue & (1 << i)) != 0 ? 0 : 1;
    }

    printf("Bits:  ");

    for (int i = 0; i < 16; i++)
    {
        printf("%d", values[i]);
    }
    printf("\n");

    bbSPIClose(CS);
    gpioTerminate();
}

void initialise() 
{
     // Use PWM for timing DMA transfers, as PCM is used for audio
    gpioCfgClock(5, 0, 0);

    gpioInitialise();
    bbSPIOpen(CS, MISO, MOSI, SCLK, BAUD, FLAGS);
}

/*
 * Enables pull-up resistors on all pins.
 */
void enablePullUp() 
{
    unsigned char buffer[4];
    char command[4]; 

    command[0] = WRITE_COMMAND;
    command[1] = GPPUA;
    command[2] = 0xFF;   // Enable on all GPIO pins
    command[3] = 0xFF;   // Sequential mode, write GPUUB

    bbSPIXfer(CS, command, (char *)buffer, sizeof(command)); 
}
