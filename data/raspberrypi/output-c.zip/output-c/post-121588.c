<!DOCTYPE RCC> <RCC version="1.0">
<qresource>
    <file>images/b2.png</file>
</qresource>
 </RCC>
