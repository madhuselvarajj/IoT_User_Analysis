auto wlan0
allow-hotplug wlan0
iface wlan0 inet static
    address 192.168.0.12  #your static ip address here
    netmask 255.255.255.0 #if you don't want subnets use this
    gateway 192.168.0.1   #ip address of router-gateway here
    wpa-scan-ssid 1
    wpa-ap-scan 1
    wpa-key-mgmt WPA-PSK
    wpa-proto RSN WPA
    wpa-pairwise CCMP TKIP
    wpa-group CCMP TKIP
    wpa-ssid <"your ssid here">
    wpa-psk <psk value here>
