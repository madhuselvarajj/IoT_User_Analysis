make mrproper
git reset --hard 'HEAD@{1}'
make bcmrpi_defconfig
make
make modules_install
