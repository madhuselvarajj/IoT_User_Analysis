radio.begin();
radio.setChannel(0x4c);
radio.setRetries(0,15);                 // Smallest time between retries, max no. of retries
radio.setAutoAck(1);                    // Ensure autoACK is enabled
radio.enableDynamicPayloads(); // feature 0x4
radio.enableAckPayload(); // feature 0x2
radio.enableDynamicAck(); // feature 0x1

//radio.setPayloadSize(1);                // Here we are sending 1-byte payloads to test the call-response speed
radio.setCRCLength(RF24_CRC_16);
radio.openWritingPipe(pipes[1]);        // Both radios listen on the same pipes by default, and switch when writing
radio.openReadingPipe(1,pipes[0]);
radio.startListening();                 // Start listening
