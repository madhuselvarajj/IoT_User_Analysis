auto eth0
allow-hotplug eth0
iface eth0 inet static
    address 192.168.0.10
    netmask 255.255.255.0
#    gateway 192.168.2.14
    dns-nameservers 192.168.2.1

auto wlan0
allow-hotplug wlan0
iface wlan0 inet static
    wpa-ssid "XXXXX"
    wpa-psk "XXXXXXXX"
    address 192.168.2.14
    netmask 255.255.255.0
    gateway 192.168.2.1
    dns-nameservers 192.168.2.1
