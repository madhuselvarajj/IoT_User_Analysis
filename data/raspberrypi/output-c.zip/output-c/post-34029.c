#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cstdint>
#include <cstring>
#include <winscard.h>
#include <reader.h>

int main(int argc, char* argv[]) {
    SCARDCONTEXT context = 0;
    LONG ret = SCardEstablishContext(SCARD_SCOPE_SYSTEM, nullptr, nullptr, &context);

    if (ret != SCARD_S_SUCCESS) {
        std::cout << "SCardEstablishContext: " << pcsc_stringify_error(ret) << std::endl;
    } else {
        LPTSTR allReaderNames = nullptr;
        DWORD readerCount = SCARD_AUTOALLOCATE;

        ret = SCardListReaders(context, nullptr, reinterpret_cast<LPTSTR>(&allReaderNames), &readerCount);

        if (ret != SCARD_S_SUCCESS) {
            std::cout << "SCardListReaders: " << pcsc_stringify_error(ret) << std::endl;
        } else {
            std::string readerName{ allReaderNames };
            DWORD activeProtocol = 0;
            SCARDHANDLE card = 0;

            ret = SCardConnect(context, readerName.c_str(), SCARD_SHARE_DIRECT, 0, &card, &activeProtocol);

            if (ret != SCARD_S_SUCCESS) {
                std::cout << "SCardConnect: " << pcsc_stringify_error(ret) << std::endl;
            } else {
                std::vector<std::uint8_t> outputBuffer{ 0xE0, 0x0, 0x0, 0x28, 0x1, 0xFF };
                std::vector<std::uint8_t> inputBuffer(64, 0);
                DWORD bytesReturned = 0;

                ret = SCardControl(card, SCARD_CTL_CODE(3500), outputBuffer.data(), outputBuffer.size(), inputBuffer.data(), inputBuffer.size(), &bytesReturned);

                if (ret != SCARD_S_SUCCESS) {
                    std::cout << "SCardControl: " << pcsc_stringify_error(ret) << std::endl;
                } else {
                    std::cout << "Response: " << std::hex << std::setfill('0');
                    for (std::size_t i = 0; i < bytesReturned; ++i) {
                        std::cout << std::setw(2) << static_cast<std::uint32_t>(inputBuffer[i]) << " ";
                    }
                    std::cout << std::dec << std::endl;

                    SCardDisconnect(card, SCARD_LEAVE_CARD);
                }
            }

            // Release the memory that SCardListReaders allocated for us
            SCardFreeMemory(context, allReaderNames);
        }

        ret = SCardReleaseContext(context);

        if (ret != SCARD_S_SUCCESS) {
            std::cout << "SCardReleaseContext: " << pcsc_stringify_error(ret) << std::endl;
        }
    }

    return 0;
}
