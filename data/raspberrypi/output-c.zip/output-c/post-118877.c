        Unnamed/non-netdev interface
                wdev 0x2
                addr ee:11:6c:59:a3:d4
                type P2P-device
                txpower 31.00 dBm
