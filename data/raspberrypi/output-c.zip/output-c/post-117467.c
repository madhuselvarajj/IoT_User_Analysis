Get-Service ssh-agent

Get-Service ssh-agent | Select StartType

Get-Service -Name ssh-agent | Set-Service -StartupType Manual

Start-Service ssh-agent

ssh-add [path to your private ssh key]
