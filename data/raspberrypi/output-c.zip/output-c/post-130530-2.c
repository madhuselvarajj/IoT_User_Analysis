/*
bench.c
This program toggles a GPIO pin and measures rate.

Using lgpio C API

gcc -Wall -o bench-lgpio bench-lgpio.c -llgpio

./bench
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>

#include <lgpio.h>

#define LFLAGS 0

#define SigOUT 12
#define LOOPS 20000

int main(int argc, char *argv[]) {
  int h;
  int i;
  double t0, t1;
  int status;

  h = lgGpiochipOpen(0);

  if (h >= 0) {
    if ((status = lgGpioClaimOutput(h, LFLAGS, SigOUT, 0)) == LG_OKAY) {
      t0 = lguTime();

      for (i = 0; i < LOOPS; i++) {
        lgGpioWrite(h, SigOUT, 0);
        lgGpioWrite(h, SigOUT, 1);
      }

      t1 = lguTime();

      printf("lgpio\t\t%10.0f toggles per second\n", (1.0 * LOOPS) / (t1 - t0));
    } else {
      printf("lgGpioClaimSigOUTput FAILED on Pin %d\n", SigOUT);
      lgLineInfo_t lInfo;

      status = lgGpioGetLineInfo(h, SigOUT, &lInfo);

      if (status == LG_OKAY) {
        if (lInfo.lFlags & 1) {
          printf("GPIO in use by the kernel ");
          printf("name=%s  user=%s\n", lInfo.name, lInfo.user);
        }
      }
    }
        lgGpioFree(h, SigOUT);
    lgGpiochipClose(h);
  } else
    printf("Unable to open gpiochip 0\n");
}
