** (lxpanel:1262): WARNING **: 10:29:58.402: init context: err:6 Connection refused

Assertion 'pthread_mutex_lock(&m->mutex) == 0' failed at pulsecore/mutex-posix.c:90, 
function pa_mutex_lock(). Aborting.
** Message: 10:29:58.411: app.vala:130: lxpanel exit with this type of exit: 6
** Message: 10:29:58.411: app.vala:148: Exit not normal, try to reload
