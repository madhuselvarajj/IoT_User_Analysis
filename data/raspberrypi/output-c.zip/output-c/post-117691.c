begin remote

  name  myremote
 #<sniped...remote stuff here...>
      begin codes
 #    <sniped other codes>

          KEY_DOWN                 0x00FF

 #    <sniped other codes>
      end codes

end remote
