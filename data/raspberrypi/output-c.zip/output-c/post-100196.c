country=FR
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1
ap_scan=1

### your access point/hotspot ###                           
network={ 
    ssid="RaspberrypiAP"    # your hotspot's name                  
    mode=2
    key_mgmt=WPA-PSK
    psk="passphrase"        # your hotspot's password
    frequency=2462
}

### your network(s) ###
network={
    priority=10       # add a priority higher then 0 to any networks
    ssid="yourWifi"   # except the access point's one!
    psk="passphrase"  
} 
