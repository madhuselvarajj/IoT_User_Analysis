$.get('192.168.1.78/cv?pw=xxx&rsn=x&rbt=x&en=x&rd=x', fucntion(returnData){
   //returns an error code which are defined in the first chapter of the API Manual
   var r = $.jQuery.parseJSON(returnData);
   if (r.result == 1)
        alert('wohoo! It worked');
   //etc....
   if (r.result == 16)
      alert('Data was missing!');
});
