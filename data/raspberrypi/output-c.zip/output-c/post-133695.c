[11:49:00.593516] [fujitsu] sane_get_devices: looking for 'usb 0x04c5 0x132b'
[11:49:00.593573] [fujitsu] attach_one: start
[11:49:00.593628] [fujitsu] attach_one: looking for 'libusb:001:004'
[11:49:00.593688] [fujitsu] connect_fd: start
[11:49:00.593741] [fujitsu] connect_fd: opening USB device
[11:49:00.593974] [fujitsu] connect_fd: could not open device: 3
[11:49:00.594033] [fujitsu] connect_fd: finish
