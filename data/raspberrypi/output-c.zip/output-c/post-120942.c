# Tests are approximate using memory only (no storage IO).

PBKDF2-sha1       357631 iterations per second for 256-bit key
PBKDF2-sha256     571742 iterations per second for 256-bit key
PBKDF2-sha512     471482 iterations per second for 256-bit key
PBKDF2-ripemd160  296207 iterations per second for 256-bit key
PBKDF2-whirlpool  107084 iterations per second for 256-bit key
argon2i       4 iterations, 322760 memory, 4 parallel threads (CPUs) for 256-bit key (requested 2000 ms time)
argon2id      4 iterations, 323296 memory, 4 parallel threads (CPUs) for 256-bit key (requested 2000 ms time)
#     Algorithm |       Key |      Encryption |      Decryption
        aes-cbc        128b        23.8 MiB/s        46.7 MiB/s
    serpent-cbc        128b               N/A               N/A
    twofish-cbc        128b               N/A               N/A
        aes-cbc        256b        17.4 MiB/s        34.1 MiB/s
    serpent-cbc        256b               N/A               N/A
    twofish-cbc        256b               N/A               N/A
        aes-xts        256b        54.1 MiB/s        46.0 MiB/s
    serpent-xts        256b               N/A               N/A
    twofish-xts        256b               N/A               N/A
        aes-xts        512b        40.1 MiB/s        33.7 MiB/s
    serpent-xts        512b               N/A               N/A
    twofish-xts        512b               N/A               N/A
