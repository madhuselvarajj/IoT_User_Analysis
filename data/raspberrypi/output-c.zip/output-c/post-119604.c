[www]
    path = /var/www
    read only = no
    public = yes
    writable = yes
