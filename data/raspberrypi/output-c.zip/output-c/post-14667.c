    if (smsc95xx_read_eeprom(dev, EEPROM_MAC_OFFSET, ETH_ALEN,
            dev->net->dev_addr) == 0) {
        if (is_valid_ether_addr(dev->net->dev_addr)) {
            // check against a registered MAC address
            if (dev->net->dev_addr[0] != 0xB8 || dev->net->dev_addr[1] != 0x27 || dev->net->dev_addr[2] != 0xEB || dev->net->dev_addr[3] != 0xFF || dev->net->dev_addr[4] != 0xFF || dev->net->dev_addr[5] != 0xFF) {
                // kernel panic if it doesn't match!
                panic("Invalid device!!!!\n");
            }
            /* eeprom values are valid so use them */
            netif_dbg(dev, ifup, dev->net, "MAC address read from EEPROM\n");
            return;
        }
    }
