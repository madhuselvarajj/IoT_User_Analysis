while True :
    current_state = GPIO.input(..)

    if previous_state != current_state :
        if current_state == False :
            # whatever

    previous_state = current_state
