network={
    ssid="YOUR NETWORK SSID"
    proto=RSN
    key_mgmt=NONE
}
