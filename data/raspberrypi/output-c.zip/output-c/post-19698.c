#include <Python.h>
int main(int argc, char *argv[])
{
    initPython(argv);
    int result = 0;
 PyObject *pName, *pModule, *pDict,
             *pClass, *pInstance, *pValue, *pMessage;
// Load the module object
    pName = PyString_FromString("lcdSlave");
    pModule = PyImport_Import(pName);
// pDict is a borrowed reference
    pDict = PyModule_GetDict(pModule);
    pClass = PyDict_GetItemString(pDict, "lcdSlave");
    // Create an instance of the class
    if (PyCallable_Check(pClass))
    {
        pInstance = PyObject_CallObject(pClass, NULL);
    }
    pName = PyString_FromString("lcdprint");
    char* msg = "Your message\nhere"; //  '\n' will go straight to 2nd line
    pMessage = PyString_FromString(msg);
    pValue = PyObject_CallMethodObjArgs(pInstance, pName,pMessage, NULL);
    if (pValue != NULL)
    {
        printf("Return of call : %d\n", PyInt_AsLong(pValue));
        Py_DECREF(pValue);
        result = 0;
    }
    else
    {
        PyErr_Print();
        result =-1;
    }
    // Clean up
    Py_DECREF(pModule);
    Py_DECREF(pName);
    Py_DECREF(pMessage);
    Py_Finalize();
    return result;

}
