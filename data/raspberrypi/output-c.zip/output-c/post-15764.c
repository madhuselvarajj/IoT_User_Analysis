                                    P
                              ______P______
                             P             P
Pennies == P                 P             P
RPi Board --> _____________-----_________-----______

                             ^             ^                
                             |             |
                            SOC         Ethernet
