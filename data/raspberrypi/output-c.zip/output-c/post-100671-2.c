void servo_close(int servo) {

switch (servo) {
    case 0:
        pinMode(SERVO_0, INPUT);
        pullUpDnControl(SERVO_0, PUD_DOWN);
        break;
    case 1:
        pinMode(SERVO_1, INPUT);
        pullUpDnControl(SERVO_1, PUD_DOWN);
        break;  
    default:

        break;
}}
