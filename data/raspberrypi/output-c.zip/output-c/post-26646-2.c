pi@seafile ~ $ free
             total       used       free     shared    buffers     cached
Mem:        496592     484912      11680          0      13292     346204
-/+ buffers/cache:     125416     371176
Swap:       102396          8     102388
