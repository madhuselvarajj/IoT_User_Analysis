  if (get_gpio_number(channel, &gpio))
     return 0;

  func = gpio_function(gpio);

  if (gpio_warnings &&                             // warnings enabled and
      ((func != 0 && func != 1) ||                 // (already one of the alt functions or
      (gpio_direction[gpio] == -1 && func == 1)))  // already an output not set from this program)
  {
     PyErr_WarnEx(NULL, "This channel is already in use, continuing anyway.  Use GPIO.setwarnings(False) to disable warnings.", 1);
  }
