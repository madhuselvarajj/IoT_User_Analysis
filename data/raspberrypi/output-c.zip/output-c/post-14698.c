while :
do
deluge-gtk #or whatever program you wish to run.
sleep 2
done
