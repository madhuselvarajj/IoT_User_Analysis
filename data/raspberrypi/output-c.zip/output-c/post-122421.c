#include "stdio.h"

extern int doit();

int main(){
        doit();
}
