#include "Logger.h"
#include <boost/log/core.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/sinks/text_file_backend.hpp>
#include <boost/log/utility/setup/file.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/utility/setup/console.hpp>
#include <fstream>
#include <boost/log/utility/setup/from_stream.hpp>
#include <stdlib.h>
#include <systemd/sd-daemon.h>

Logger* Logger::pInstance = nullptr;

Logger::Logger()
{

    boost::log::register_simple_filter_factory<boost::log::trivial::severity_level, char>("Severity");
    boost::log::register_simple_formatter_factory< boost::log::trivial::severity_level, char >("Severity");
    boost::log::core::get()->add_global_attribute("TimeStamp", boost::log::attributes::local_clock());

    std::string a_cwd = std::string(getcwd(NULL, 0));
    boost::log::add_common_attributes();
    std::ifstream file(a_cwd + "/log.ini");
    boost::log::init_from_stream(file);

}

Logger::~Logger()
{
}

Logger* Logger::instance()
{
    if (pInstance == nullptr) {
        pInstance = new Logger();
    }
    return pInstance;
}

void Logger::logInfo(std::string message)
{
    sd_notify(0, "WATCHDOG=1");
    BOOST_LOG_TRIVIAL(info) << message;
}

void Logger::logDebug(std::string message)
{
    sd_notify(0, "WATCHDOG=1");
    BOOST_LOG_TRIVIAL(debug) << message;
}

void Logger::logWarn(std::string message)
{
    sd_notify(0, "WATCHDOG=1");
    BOOST_LOG_TRIVIAL(warning) << message;
}

void Logger::logError(std::string message)
{
    BOOST_LOG_TRIVIAL(error) << message;
}

void Logger::logFatal(std::string message)
{
    BOOST_LOG_TRIVIAL(fatal) << message;
}
